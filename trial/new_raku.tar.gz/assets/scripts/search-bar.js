
            var items =
            [
  {
    "info": "<i>Mutable collection of distinct objects with integer weights</i>",
    "category": "Class",
    "url": "/type/BagHash",
    "value": "class BagHash"
  },
  {
    "value": "class Str",
    "info": "<i>String of characters</i>",
    "url": "/type/Str",
    "category": "Class"
  },
  {
    "value": "class X::Syntax::Regex::SolitaryQuantifier",
    "category": "Class",
    "url": "/type/X/Syntax/Regex/SolitaryQuantifier",
    "info": "<i>Compilation error due to a regex quantifier without prec</i> ... "
  },
  {
    "category": "Class",
    "value": "class CallFrame",
    "info": "<i>Captures the current frame state</i>",
    "url": "/type/CallFrame"
  },
  {
    "info": "<i>Running process (asynchronous interface)</i>",
    "value": "class Proc::Async",
    "category": "Class",
    "url": "/type/Proc/Async"
  },
  {
    "category": "Class",
    "url": "/native/int",
    "value": "class int",
    "info": "<i>Native integer</i>"
  },
  {
    "info": "<i>Parameter list pattern</i>",
    "category": "Class",
    "value": "class Signature",
    "url": "/type/Signature"
  },
  {
    "info": "<i>Object that can be treated as both a string and number</i>",
    "url": "/type/Cool",
    "value": "class Cool",
    "category": "Class"
  },
  {
    "info": "<i>Member variable</i>",
    "url": "/type/Attribute",
    "value": "class Attribute",
    "category": "Class"
  },
  {
    "info": "<i>Element of a Signature</i>",
    "category": "Class",
    "url": "/type/Parameter",
    "value": "class Parameter"
  },
  {
    "value": "class X::Proc::Unsuccessful",
    "category": "Class",
    "info": "<i>Exception thrown if a Proc object is sunk after the process it ran exit</i> ... ",
    "url": "/type/X/Proc/Unsuccessful"
  },
  {
    "info": "<i>Integer (arbitrary-precision)</i>",
    "url": "/type/Int",
    "value": "class Int",
    "category": "Class"
  },
  {
    "info": "<i>From: language/operators</i>",
    "url": "/routine/cmp",
    "value": "cmp",
    "category": "Composite"
  },
  {
    "url": "/syntax/%3A1st",
    "info": "<i>From: language/regexes</i>",
    "value": ":1st",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "category": "Composite",
    "value": "rand",
    "url": "/routine/rand"
  },
  {
    "value": "mkdir",
    "info": "<i>From: type/independent-routines</i>",
    "url": "/routine/mkdir",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "log10",
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/log10"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/control</i>",
    "value": "last",
    "url": "/syntax/last"
  },
  {
    "value": ":=",
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%3A%3D"
  },
  {
    "category": "Composite",
    "url": "/routine/subst-mutate",
    "info": "<i>From: type/Str</i>",
    "value": "subst-mutate"
  },
  {
    "url": "/routine/%E2%8A%84",
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": "⊄"
  },
  {
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%5Eff%5E",
    "value": "^ff^",
    "category": "Composite"
  },
  {
    "url": "/routine/msb",
    "value": "msb",
    "info": "<i>From: type/Int</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Baggy</i>",
    "value": "new-from-pairs",
    "url": "/routine/new-from-pairs"
  },
  {
    "category": "Composite",
    "url": "/routine/atan",
    "info": "<i>From: type/Cool</i>",
    "value": "atan"
  },
  {
    "info": "<i>From: type/Proc/Async</i>",
    "value": "started",
    "category": "Composite",
    "url": "/routine/started"
  },
  {
    "info": "<i>From: type/BagHash</i>",
    "url": "/routine/add",
    "category": "Composite",
    "value": "add"
  },
  {
    "url": "/routine/%7B%20%7D",
    "info": "<i>From: language/operators, language/operators</i>",
    "category": "Composite",
    "value": "{ }"
  },
  {
    "value": ".",
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/."
  },
  {
    "url": "/routine/capture",
    "category": "Composite",
    "value": "capture",
    "info": "<i>From: type/Parameter</i>"
  },
  {
    "url": "/routine/getc",
    "value": "getc",
    "category": "Composite",
    "info": "<i>From: type/independent-routines</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/%5Ct",
    "value": "\\t"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "category": "Composite",
    "value": "chrs",
    "url": "/routine/chrs"
  },
  {
    "info": "<i>From: language/operators, language/operators</i>",
    "value": "?^",
    "url": "/routine/%3F%5E",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Str, type/Baggy</i>",
    "category": "Composite",
    "value": "Bool",
    "url": "/routine/Bool"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/uniname",
    "value": "uniname"
  },
  {
    "category": "Composite",
    "url": "/routine/constant",
    "value": "constant",
    "info": "<i>From: language/variables</i>"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "whitespace",
    "category": "Composite",
    "url": "/syntax/whitespace"
  },
  {
    "info": "<i>From: language/operators, language/operators</i>",
    "category": "Composite",
    "value": "|",
    "url": "/routine/%7C"
  },
  {
    "info": "<i>From: type/Str</i>",
    "url": "/routine/NFKD",
    "category": "Composite",
    "value": "NFKD"
  },
  {
    "category": "Composite",
    "value": "Real",
    "url": "/routine/Real",
    "info": "<i>From: type/Cool</i>"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "value": "Autothreading",
    "url": "/syntax/Autothreading"
  },
  {
    "value": "single-quoted strings",
    "info": "<i>From: language/101-basics</i>",
    "url": "/syntax/single-quoted%20strings",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/does",
    "value": "does"
  },
  {
    "value": "Larry Wall",
    "category": "Composite",
    "url": "/syntax/Larry%20Wall",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "value": "repeat",
    "info": "<i>From: language/control</i>",
    "category": "Composite",
    "url": "/syntax/repeat"
  },
  {
    "value": "stdout",
    "info": "<i>From: type/Proc/Async</i>",
    "category": "Composite",
    "url": "/routine/stdout"
  },
  {
    "category": "Composite",
    "value": "indir",
    "url": "/routine/indir",
    "info": "<i>From: type/independent-routines</i>"
  },
  {
    "info": "<i>From: type/independent-routines</i>",
    "value": "append",
    "category": "Composite",
    "url": "/routine/append"
  },
  {
    "value": "Repository",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "url": "/syntax/Repository"
  },
  {
    "category": "Composite",
    "url": "/syntax/identifiers",
    "value": "identifiers",
    "info": "<i>From: language/syntax</i>"
  },
  {
    "url": "/routine/tanh",
    "info": "<i>From: type/Cool</i>",
    "value": "tanh",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%2B%26amp%3B",
    "value": "+&",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "value": "sech",
    "category": "Composite",
    "url": "/routine/sech"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/independent-routines</i>",
    "url": "/routine/chmod",
    "value": "chmod"
  },
  {
    "category": "Composite",
    "url": "/routine/Order",
    "info": "<i>From: type/Cool</i>",
    "value": "Order"
  },
  {
    "url": "/routine/%E2%8A%85",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "⊅"
  },
  {
    "url": "/routine/uninames",
    "info": "<i>From: type/Cool</i>",
    "category": "Composite",
    "value": "uninames"
  },
  {
    "info": "<i>From: type/Attribute</i>",
    "value": "package",
    "url": "/routine/package",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Str, type/Cool</i>",
    "category": "Composite",
    "url": "/routine/substr",
    "value": "substr"
  },
  {
    "url": "/syntax/blocks",
    "info": "<i>From: language/control</i>",
    "category": "Composite",
    "value": "blocks"
  },
  {
    "url": "/syntax/gather%20take",
    "value": "gather take",
    "info": "<i>From: language/control</i>",
    "category": "Composite"
  },
  {
    "url": "/syntax/Sigilless%20Variable",
    "value": "Sigilless Variable",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "category": "Composite",
    "value": "uniprops",
    "url": "/routine/uniprops",
    "info": "<i>From: type/Cool</i>"
  },
  {
    "value": "pop",
    "category": "Composite",
    "info": "<i>From: type/independent-routines</i>",
    "url": "/routine/pop"
  },
  {
    "url": "/syntax/do",
    "category": "Composite",
    "value": "do",
    "info": "<i>From: language/control</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Signature</i>",
    "value": "params",
    "url": "/routine/params"
  },
  {
    "category": "Composite",
    "url": "/syntax/UB",
    "value": "UB",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "info": "<i>From: type/Dateish</i>",
    "category": "Composite",
    "value": "yyyy-mm-dd",
    "url": "/routine/yyyy-mm-dd"
  },
  {
    "value": "squish",
    "info": "<i>From: type/independent-routines</i>",
    "url": "/routine/squish",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/Int",
    "info": "<i>From: type/Str, type/Cool</i>",
    "value": "Int"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/cosh",
    "category": "Composite",
    "value": "cosh"
  },
  {
    "url": "/routine/xx",
    "info": "<i>From: language/operators</i>",
    "value": "xx",
    "category": "Composite"
  },
  {
    "url": "/syntax/Pair%20literals",
    "info": "<i>From: language/syntax</i>",
    "value": "Pair literals",
    "category": "Composite"
  },
  {
    "value": "(>), infix ⊃",
    "url": "/routine/%28%26gt%3B%29%2C%20infix%20%E2%8A%83",
    "info": "<i>From: language/operators</i>",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "<<",
    "url": "/syntax/%3C%3C"
  },
  {
    "category": "Composite",
    "url": "/syntax/-%3E",
    "info": "<i>From: language/functions</i>",
    "value": "->"
  },
  {
    "url": "/routine/abs",
    "info": "<i>From: type/Cool</i>",
    "value": "abs",
    "category": "Composite"
  },
  {
    "url": "/routine/arity",
    "value": "arity",
    "category": "Composite",
    "info": "<i>From: type/Signature</i>"
  },
  {
    "info": "<i>From: type/Str</i>",
    "url": "/routine/starts-with",
    "value": "starts-with",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/chop",
    "category": "Composite",
    "value": "chop"
  },
  {
    "url": "/syntax/%3C%5B%20%5D%3E",
    "value": "<[ ]>",
    "category": "Composite",
    "info": "<i>From: language/regexes</i>"
  },
  {
    "category": "Composite",
    "url": "/syntax/role",
    "info": "<i>From: language/objects, language/glossary</i>",
    "value": "role"
  },
  {
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "url": "/routine/%3D%26gt%3B",
    "value": "=>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/nativecall</i>",
    "value": "nativesizeof",
    "url": "/routine/nativesizeof"
  },
  {
    "url": "/routine/EVALFILE",
    "info": "<i>From: type/independent-routines</i>",
    "value": "EVALFILE",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/syntax/is%20built%20%28Attribute%29",
    "value": "is built (Attribute)",
    "info": "<i>From: type/Attribute</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/Thunk",
    "value": "Thunk"
  },
  {
    "url": "/routine/Supply",
    "info": "<i>From: type/Proc/Async</i>",
    "value": "Supply",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "categorize-list",
    "url": "/routine/categorize-list",
    "info": "<i>From: type/Baggy</i>"
  },
  {
    "url": "/routine/uc",
    "value": "uc",
    "info": "<i>From: type/Str, type/Cool</i>",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/after",
    "category": "Composite",
    "value": "after"
  },
  {
    "info": "<i>From: language/operators, language/operators</i>",
    "url": "/routine/%2B",
    "value": "+",
    "category": "Composite"
  },
  {
    "value": "inheritance",
    "category": "Composite",
    "info": "<i>From: language/classtut</i>",
    "url": "/syntax/inheritance"
  },
  {
    "value": "^ff",
    "category": "Composite",
    "url": "/routine/%5Eff",
    "info": "<i>From: language/operators</i>"
  },
  {
    "category": "Composite",
    "value": "day-of-month",
    "info": "<i>From: type/Dateish</i>",
    "url": "/routine/day-of-month"
  },
  {
    "value": "= (list assignment)",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%3D%20%28list%20assignment%29",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/%2C",
    "info": "<i>From: language/operators</i>",
    "value": ","
  },
  {
    "value": "MAIN",
    "info": "<i>From: language/functions</i>",
    "category": "Composite",
    "url": "/routine/MAIN"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Cool, type/Dateish</i>",
    "url": "/routine/IO",
    "value": "IO"
  },
  {
    "value": "eqv",
    "url": "/routine/eqv",
    "info": "<i>From: language/operators</i>",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "Camelia",
    "category": "Composite",
    "url": "/syntax/Camelia"
  },
  {
    "category": "Composite",
    "url": "/routine/sec",
    "info": "<i>From: type/Cool</i>",
    "value": "sec"
  },
  {
    "info": "<i>From: language/operators</i>",
    "url": "/routine/x",
    "value": "x",
    "category": "Composite"
  },
  {
    "value": "variable interpolation (Basics)",
    "url": "/syntax/variable%20interpolation%20%28Basics%29",
    "category": "Composite",
    "info": "<i>From: language/101-basics</i>"
  },
  {
    "url": "/routine/chomp",
    "category": "Composite",
    "info": "<i>From: type/Str, type/Cool</i>",
    "value": "chomp"
  },
  {
    "url": "/syntax/%5Cv",
    "value": "\\v",
    "info": "<i>From: language/regexes</i>",
    "category": "Composite"
  },
  {
    "value": "Adverb",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/Adverb"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/%2A%2A",
    "value": "**",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "category": "Composite",
    "value": "+",
    "url": "/syntax/%2B"
  },
  {
    "value": ":exhaustive",
    "info": "<i>From: language/regexes</i>",
    "category": "Composite",
    "url": "/syntax/%3Aexhaustive"
  },
  {
    "url": "/routine/max",
    "info": "<i>From: language/operators</i>",
    "value": "max",
    "category": "Composite"
  },
  {
    "value": "days-in-month",
    "info": "<i>From: type/Dateish</i>",
    "category": "Composite",
    "url": "/routine/days-in-month"
  },
  {
    "info": "<i>From: type/Str</i>",
    "value": "pred",
    "url": "/routine/pred",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/operators, language/operators</i>",
    "category": "Composite",
    "value": "--",
    "url": "/routine/--"
  },
  {
    "info": "<i>From: language/101-basics</i>",
    "url": "/syntax/block%20%28Basics%29",
    "value": "block (Basics)",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "category": "Composite",
    "url": "/syntax/%3Acontinue",
    "value": ":continue"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": "=:=",
    "url": "/routine/%3D%3A%3D"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Str</i>",
    "url": "/routine/succ",
    "value": "succ"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Str, type/Cool</i>",
    "value": "wordcase",
    "url": "/routine/wordcase"
  },
  {
    "value": "Creating grammars",
    "category": "Composite",
    "info": "<i>From: language/grammars</i>",
    "url": "/syntax/Creating%20grammars"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Baggy</i>",
    "url": "/routine/total",
    "value": "total"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/Perl",
    "category": "Composite",
    "value": "Perl"
  },
  {
    "value": "&",
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/%26"
  },
  {
    "url": "/syntax/is%20rw%20%28Attribute%29",
    "info": "<i>From: type/Attribute</i>",
    "category": "Composite",
    "value": "is rw (Attribute)"
  },
  {
    "value": "regex",
    "url": "/syntax/regex",
    "info": "<i>From: language/regexes</i>",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/twine",
    "value": "twine",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/lc",
    "info": "<i>From: type/Str, type/Cool</i>",
    "value": "lc"
  },
  {
    "info": "<i>From: type/Proc/Async, type/Cool</i>",
    "value": "path",
    "category": "Composite",
    "url": "/routine/path"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "value": "Regex Interpolation",
    "category": "Composite",
    "url": "/syntax/Regex%20Interpolation"
  },
  {
    "url": "/syntax/%5E",
    "category": "Composite",
    "value": "^",
    "info": "<i>From: language/regexes</i>"
  },
  {
    "url": "/syntax/Z%20%28zip%20metaoperator%29",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "Z (zip metaoperator)"
  },
  {
    "info": "<i>From: type/Signature</i>",
    "category": "Composite",
    "value": "count",
    "url": "/routine/count"
  },
  {
    "value": "Perl 6",
    "category": "Composite",
    "url": "/syntax/Perl%C2%A06",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "value": "twigil",
    "url": "/routine/twigil",
    "info": "<i>From: type/Parameter</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/%3D%3D%3D%2C%20infix%20%E2%A9%B6",
    "info": "<i>From: language/operators</i>",
    "value": "===, infix ⩶"
  },
  {
    "category": "Composite",
    "value": "has_accessor",
    "url": "/routine/has_accessor",
    "info": "<i>From: type/Attribute</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "value": ":global",
    "url": "/syntax/%3Aglobal"
  },
  {
    "info": "<i>From: type/Parameter</i>",
    "category": "Composite",
    "url": "/routine/slurpy",
    "value": "slurpy"
  },
  {
    "url": "/routine/polymod",
    "value": "polymod",
    "category": "Composite",
    "info": "<i>From: type/Int</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": ".=",
    "url": "/routine/.%3D"
  },
  {
    "value": "sprintf",
    "category": "Composite",
    "url": "/routine/sprintf",
    "info": "<i>From: type/Cool, type/independent-routines</i>"
  },
  {
    "url": "/syntax/Invocant",
    "info": "<i>From: language/glossary</i>",
    "value": "Invocant",
    "category": "Composite"
  },
  {
    "url": "/syntax/Spesh",
    "info": "<i>From: language/glossary</i>",
    "value": "Spesh",
    "category": "Composite"
  },
  {
    "value": "named_names",
    "info": "<i>From: type/Parameter</i>",
    "category": "Composite",
    "url": "/routine/named_names"
  },
  {
    "info": "<i>From: type/Str</i>",
    "url": "/routine/encode",
    "value": "encode",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "value": "iffy",
    "url": "/syntax/iffy"
  },
  {
    "url": "/routine/%25",
    "info": "<i>From: language/operators</i>",
    "value": "%",
    "category": "Composite"
  },
  {
    "value": "return-rw",
    "url": "/syntax/return-rw",
    "category": "Composite",
    "info": "<i>From: language/control</i>"
  },
  {
    "category": "Composite",
    "url": "/syntax/Value%20type",
    "value": "Value type",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "value": "acosech",
    "category": "Composite",
    "url": "/routine/acosech"
  },
  {
    "category": "Composite",
    "url": "/syntax/with",
    "info": "<i>From: language/control</i>",
    "value": "with"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Cool, type/Int</i>",
    "url": "/routine/chr",
    "value": "chr"
  },
  {
    "category": "Composite",
    "url": "/syntax/%3F",
    "value": "?",
    "info": "<i>From: language/regexes</i>"
  },
  {
    "value": ":samecase",
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/%3Asamecase",
    "category": "Composite"
  },
  {
    "value": "Niecza",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "url": "/syntax/Niecza"
  },
  {
    "url": "/routine/start",
    "value": "start",
    "info": "<i>From: type/Proc/Async</i>",
    "category": "Composite"
  },
  {
    "value": "or",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/or",
    "category": "Composite"
  },
  {
    "url": "/routine/explicitly-manage",
    "info": "<i>From: language/nativecall</i>",
    "value": "explicitly-manage",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/Rat",
    "info": "<i>From: type/Str, type/Cool</i>",
    "value": "Rat"
  },
  {
    "info": "<i>From: language/operators</i>",
    "value": "ge",
    "category": "Composite",
    "url": "/routine/ge"
  },
  {
    "info": "<i>From: type/Parameter, type/Baggy</i>",
    "url": "/routine/default",
    "category": "Composite",
    "value": "default"
  },
  {
    "value": "callwith",
    "url": "/syntax/callwith",
    "info": "<i>From: language/functions</i>",
    "category": "Composite"
  },
  {
    "url": "/routine/later",
    "value": "later",
    "category": "Composite",
    "info": "<i>From: type/Dateish</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/variables</i>",
    "value": "anon",
    "url": "/syntax/anon"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/independent-routines</i>",
    "url": "/routine/done",
    "value": "done"
  },
  {
    "value": "...",
    "url": "/routine/...",
    "category": "Composite",
    "info": "<i>From: language/operators, language/operators</i>"
  },
  {
    "url": "/syntax/fail",
    "value": "fail",
    "info": "<i>From: language/control</i>",
    "category": "Composite"
  },
  {
    "url": "/routine/suffix",
    "category": "Composite",
    "info": "<i>From: type/Parameter</i>",
    "value": "suffix"
  },
  {
    "url": "/routine/.",
    "info": "<i>From: language/operators</i>",
    "value": ".",
    "category": "Composite"
  },
  {
    "url": "/syntax/Operator",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "value": "Operator"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/cotanh",
    "value": "cotanh",
    "category": "Composite"
  },
  {
    "value": "MoarVM",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/MoarVM",
    "category": "Composite"
  },
  {
    "url": "/routine/%E2%88%89",
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": "∉"
  },
  {
    "value": "sub_signature",
    "url": "/routine/sub_signature",
    "category": "Composite",
    "info": "<i>From: type/Parameter</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "PERL",
    "url": "/syntax/PERL"
  },
  {
    "url": "/syntax/recursive",
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "value": "recursive"
  },
  {
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%2B%7C",
    "value": "+|",
    "category": "Composite"
  },
  {
    "url": "/routine/%28%2B%29%2C%20infix%20%E2%8A%8E",
    "value": "(+), infix ⊎",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "info": "<i>From: language/operators</i>",
    "url": "/routine/gt",
    "category": "Composite",
    "value": "gt"
  },
  {
    "value": "split",
    "category": "Composite",
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/split"
  },
  {
    "url": "/routine/~%26amp%3B",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "~&"
  },
  {
    "category": "Composite",
    "value": "substr-rw",
    "url": "/routine/substr-rw",
    "info": "<i>From: type/Str, type/Cool</i>"
  },
  {
    "url": "/routine/%28cont%29%2C%20infix%20%E2%88%8B",
    "value": "(cont), infix ∋",
    "info": "<i>From: language/operators</i>",
    "category": "Composite"
  },
  {
    "value": "++",
    "info": "<i>From: language/operators, language/operators</i>",
    "category": "Composite",
    "url": "/routine/%2B%2B"
  },
  {
    "value": "NYI",
    "category": "Composite",
    "url": "/syntax/NYI",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "url": "/syntax/Number%20literals",
    "category": "Composite",
    "info": "<i>From: language/syntax</i>",
    "value": "Number literals"
  },
  {
    "category": "Composite",
    "value": "month",
    "url": "/routine/month",
    "info": "<i>From: type/Dateish</i>"
  },
  {
    "category": "Composite",
    "value": "flip",
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/flip"
  },
  {
    "info": "<i>From: language/operators</i>",
    "url": "/syntax/X%20%28cross%20metaoperator%29",
    "value": "X (cross metaoperator)",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "url": "/routine/%5Efff%5E",
    "value": "^fff^"
  },
  {
    "url": "/routine/cosech",
    "category": "Composite",
    "value": "cosech",
    "info": "<i>From: type/Cool</i>"
  },
  {
    "info": "<i>From: language/operators</i>",
    "url": "/routine/notandthen",
    "category": "Composite",
    "value": "notandthen"
  },
  {
    "value": "[ ]",
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/%5B%20%5D",
    "category": "Composite"
  },
  {
    "url": "/routine/roll",
    "value": "roll",
    "category": "Composite",
    "info": "<i>From: type/Baggy</i>"
  },
  {
    "info": "<i>From: type/Str</i>",
    "category": "Composite",
    "value": "parse-names",
    "url": "/routine/parse-names"
  },
  {
    "value": "indices",
    "url": "/routine/indices",
    "category": "Composite",
    "info": "<i>From: type/Str</i>"
  },
  {
    "value": "returns",
    "url": "/routine/returns",
    "info": "<i>From: type/Signature</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "Variable Interpolation",
    "url": "/syntax/Variable%20Interpolation"
  },
  {
    "category": "Composite",
    "url": "/routine/unique",
    "value": "unique",
    "info": "<i>From: type/independent-routines</i>"
  },
  {
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/uniparse",
    "category": "Composite",
    "value": "uniparse"
  },
  {
    "url": "/routine/push",
    "value": "push",
    "category": "Composite",
    "info": "<i>From: type/independent-routines</i>"
  },
  {
    "info": "<i>From: language/5to6-perlvar</i>",
    "category": "Composite",
    "value": "@_ (Perl)",
    "url": "/syntax/%40_%20%28Perl%29"
  },
  {
    "category": "Composite",
    "url": "/routine/temp",
    "value": "temp",
    "info": "<i>From: language/variables, language/operators</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "value": ":x",
    "url": "/syntax/%3Ax"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/Symbol",
    "value": "Symbol"
  },
  {
    "info": "<i>From: type/Str</i>",
    "category": "Composite",
    "value": "NFD",
    "url": "/routine/NFD"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "value": "\\d",
    "category": "Composite",
    "url": "/syntax/%5Cd"
  },
  {
    "url": "/routine/le",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "le"
  },
  {
    "category": "Composite",
    "url": "/routine/kv",
    "value": "kv",
    "info": "<i>From: type/Baggy</i>"
  },
  {
    "value": "log",
    "category": "Composite",
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/log"
  },
  {
    "url": "/syntax/redo",
    "category": "Composite",
    "value": "redo",
    "info": "<i>From: language/control</i>"
  },
  {
    "value": "log2",
    "info": "<i>From: type/Cool</i>",
    "category": "Composite",
    "url": "/routine/log2"
  },
  {
    "category": "Composite",
    "value": "non-string keys",
    "info": "<i>From: language/hashmap</i>",
    "url": "/syntax/non-string%20keys"
  },
  {
    "info": "<i>From: language/operators</i>",
    "value": "! (negation metaoperator)",
    "category": "Composite",
    "url": "/syntax/%21%20%28negation%20metaoperator%29"
  },
  {
    "info": "<i>From: language/operators</i>",
    "value": "lcm",
    "url": "/routine/lcm",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Str</i>",
    "url": "/routine/Date",
    "category": "Composite",
    "value": "Date"
  },
  {
    "url": "/routine/%2F",
    "value": "/",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": "!",
    "url": "/routine/%21"
  },
  {
    "url": "/routine/callframe",
    "category": "Composite",
    "info": "<i>From: type/CallFrame</i>",
    "value": "callframe"
  },
  {
    "url": "/syntax/once",
    "category": "Composite",
    "info": "<i>From: language/control</i>",
    "value": "once"
  },
  {
    "value": "\\",
    "category": "Composite",
    "info": "<i>From: language/syntax</i>",
    "url": "/syntax/%5C"
  },
  {
    "value": "∌",
    "category": "Composite",
    "url": "/routine/%E2%88%8C",
    "info": "<i>From: language/operators</i>"
  },
  {
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": ">",
    "url": "/routine/%26gt%3B"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "category": "Composite",
    "url": "/syntax/%3Aoverlap",
    "value": ":overlap"
  },
  {
    "category": "Composite",
    "url": "/routine/acos",
    "value": "acos",
    "info": "<i>From: type/Cool</i>"
  },
  {
    "info": "<i>From: language/objects</i>",
    "url": "/syntax/Type%20objects",
    "category": "Composite",
    "value": "Type objects"
  },
  {
    "category": "Composite",
    "url": "/routine/grabpairs",
    "info": "<i>From: type/Baggy</i>",
    "value": "grabpairs"
  },
  {
    "value": "(-), infix ∖",
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%28-%29%2C%20infix%20%E2%88%96"
  },
  {
    "value": "Complex",
    "category": "Composite",
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/Complex"
  },
  {
    "category": "Composite",
    "url": "/routine/positional",
    "info": "<i>From: type/Parameter</i>",
    "value": "positional"
  },
  {
    "category": "Composite",
    "url": "/routine/~%26gt%3B",
    "value": "~>",
    "info": "<i>From: language/operators</i>"
  },
  {
    "value": "sinh",
    "category": "Composite",
    "url": "/routine/sinh",
    "info": "<i>From: type/Cool</i>"
  },
  {
    "url": "/syntax/nextsame",
    "category": "Composite",
    "info": "<i>From: language/functions</i>",
    "value": "nextsame"
  },
  {
    "value": "multi-method",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/multi-method",
    "category": "Composite"
  },
  {
    "value": "(.), infix ⊍",
    "url": "/routine/%28.%29%2C%20infix%20%E2%8A%8D",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "url": "/syntax/statement%20%28Basics%29",
    "value": "statement (Basics)",
    "info": "<i>From: language/101-basics</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": "« »",
    "url": "/routine/%C2%AB%20%C2%BB"
  },
  {
    "url": "/syntax/POV",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "POV"
  },
  {
    "info": "<i>From: language/operators, language/operators</i>",
    "category": "Composite",
    "url": "/routine/%5B%20%5D",
    "value": "[ ]"
  },
  {
    "info": "<i>From: type/Dateish</i>",
    "url": "/routine/week-number",
    "category": "Composite",
    "value": "week-number"
  },
  {
    "info": "<i>From: type/Dateish</i>",
    "category": "Composite",
    "value": "dd-mm-yyyy",
    "url": "/routine/dd-mm-yyyy"
  },
  {
    "value": "start",
    "info": "<i>From: language/control</i>",
    "url": "/syntax/start",
    "category": "Composite"
  },
  {
    "value": "rvalue",
    "url": "/syntax/rvalue",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/syntax/Constructor",
    "info": "<i>From: language/classtut</i>",
    "value": "Constructor"
  },
  {
    "value": "augment",
    "url": "/syntax/augment",
    "category": "Composite",
    "info": "<i>From: language/variables</i>"
  },
  {
    "url": "/routine/rindex",
    "category": "Composite",
    "info": "<i>From: type/Str, type/Cool</i>",
    "value": "rindex"
  },
  {
    "info": "<i>From: language/control</i>",
    "url": "/syntax/while%20until",
    "category": "Composite",
    "value": "while until"
  },
  {
    "url": "/routine/%28%26amp%3B%29%2C%20infix%20%E2%88%A9",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "(&), infix ∩"
  },
  {
    "value": "Regex adverbs",
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/Regex%20adverbs"
  },
  {
    "info": "<i>From: type/Str, type/Cool</i>",
    "category": "Composite",
    "value": "ord",
    "url": "/routine/ord"
  },
  {
    "value": "daycount",
    "category": "Composite",
    "url": "/routine/daycount",
    "info": "<i>From: type/Dateish</i>"
  },
  {
    "value": "day",
    "category": "Composite",
    "info": "<i>From: type/Dateish</i>",
    "url": "/routine/day"
  },
  {
    "value": "Community",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "url": "/syntax/Community"
  },
  {
    "info": "<i>From: type/Parameter</i>",
    "value": "usage-name",
    "url": "/routine/usage-name",
    "category": "Composite"
  },
  {
    "value": "SAP",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "url": "/syntax/SAP"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "category": "Composite",
    "url": "/routine/fmt",
    "value": "fmt"
  },
  {
    "info": "<i>From: type/Proc/Async</i>",
    "value": "pid",
    "category": "Composite",
    "url": "/routine/pid"
  },
  {
    "url": "/syntax/PAST",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "PAST"
  },
  {
    "url": "/syntax/given",
    "category": "Composite",
    "info": "<i>From: language/control</i>",
    "value": "given"
  },
  {
    "url": "/routine/pickpairs",
    "value": "pickpairs",
    "info": "<i>From: type/Baggy</i>",
    "category": "Composite"
  },
  {
    "url": "/syntax/Synopsis",
    "info": "<i>From: language/glossary</i>",
    "value": "Synopsis",
    "category": "Composite"
  },
  {
    "url": "/syntax/%26%26",
    "info": "<i>From: language/regexes</i>",
    "value": "&&",
    "category": "Composite"
  },
  {
    "url": "/routine/match",
    "info": "<i>From: type/Str, type/Cool</i>",
    "value": "match",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Cool, type/independent-routines</i>",
    "url": "/routine/printf",
    "category": "Composite",
    "value": "printf"
  },
  {
    "category": "Composite",
    "value": "Parameter",
    "url": "/syntax/Parameter",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "value": "copy",
    "info": "<i>From: type/Parameter</i>",
    "url": "/routine/copy",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/syntax/%24%21",
    "value": "$!",
    "info": "<i>From: language/variables</i>"
  },
  {
    "category": "Composite",
    "value": "&*chdir",
    "info": "<i>From: type/independent-routines</i>",
    "url": "/routine/%26amp%3B%2Achdir"
  },
  {
    "value": "comb",
    "category": "Composite",
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/comb"
  },
  {
    "info": "<i>From: language/operators</i>",
    "value": "min",
    "category": "Composite",
    "url": "/routine/min"
  },
  {
    "info": "<i>From: type/Str</i>",
    "url": "/routine/Numeric",
    "category": "Composite",
    "value": "Numeric"
  },
  {
    "value": "gcd",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/gcd",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/5to6-perlvar</i>",
    "url": "/syntax/%40INC%20%28Perl%29",
    "value": "@INC (Perl)"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "url": "/syntax/STD",
    "value": "STD"
  },
  {
    "category": "Composite",
    "url": "/routine/acotan",
    "info": "<i>From: type/Cool</i>",
    "value": "acotan"
  },
  {
    "url": "/syntax/%3C%3Aproperty%3E",
    "info": "<i>From: language/regexes</i>",
    "value": "<:property>",
    "category": "Composite"
  },
  {
    "value": "&",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%26amp%3B",
    "category": "Composite"
  },
  {
    "value": "pick",
    "info": "<i>From: type/Baggy</i>",
    "url": "/routine/pick",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/name",
    "info": "<i>From: type/Parameter, type/Attribute</i>",
    "value": "name"
  },
  {
    "url": "/routine/repl",
    "category": "Composite",
    "info": "<i>From: type/independent-routines</i>",
    "value": "repl"
  },
  {
    "category": "Composite",
    "value": "<=>",
    "url": "/routine/%26lt%3B%3D%26gt%3B",
    "info": "<i>From: language/operators</i>"
  },
  {
    "value": "my",
    "url": "/routine/my",
    "info": "<i>From: type/CallFrame</i>",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Baggy</i>",
    "url": "/routine/kxxv",
    "value": "kxxv",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/coll",
    "info": "<i>From: language/operators</i>",
    "value": "coll"
  },
  {
    "url": "/routine/antipairs",
    "value": "antipairs",
    "category": "Composite",
    "info": "<i>From: type/Baggy</i>"
  },
  {
    "value": "sigil",
    "info": "<i>From: type/Parameter</i>",
    "url": "/routine/sigil",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Cool</i>",
    "value": "sin",
    "url": "/routine/sin"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "category": "Composite",
    "value": "|",
    "url": "/syntax/%7C"
  },
  {
    "info": "<i>From: language/functions</i>",
    "url": "/syntax/Argument",
    "value": "Argument",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "words",
    "url": "/routine/words",
    "info": "<i>From: type/Str, type/Cool</i>"
  },
  {
    "value": "S",
    "category": "Composite",
    "url": "/syntax/S",
    "info": "<i>From: language/operators</i>"
  },
  {
    "value": "ff",
    "url": "/routine/ff",
    "info": "<i>From: language/operators</i>",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/operators, language/operators</i>",
    "value": "~",
    "url": "/routine/~",
    "category": "Composite"
  },
  {
    "value": "R",
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "url": "/syntax/R"
  },
  {
    "info": "<i>From: type/independent-routines</i>",
    "value": "shift",
    "category": "Composite",
    "url": "/routine/shift"
  },
  {
    "url": "/syntax/FQN",
    "value": "FQN",
    "category": "Composite",
    "info": "<i>From: language/classtut</i>"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/%5Cs",
    "category": "Composite",
    "value": "\\s"
  },
  {
    "url": "/syntax/is%20default%20%28Attribute%29",
    "value": "is default (Attribute)",
    "category": "Composite",
    "info": "<i>From: type/Attribute</i>"
  },
  {
    "info": "<i>From: type/Proc/Async, type/independent-routines</i>",
    "url": "/routine/say",
    "category": "Composite",
    "value": "say"
  },
  {
    "category": "Composite",
    "value": "values",
    "info": "<i>From: type/Baggy</i>",
    "url": "/routine/values"
  },
  {
    "category": "Composite",
    "url": "/routine/stderr",
    "value": "stderr",
    "info": "<i>From: type/Proc/Async</i>"
  },
  {
    "category": "Composite",
    "url": "/routine/%3F",
    "value": "?",
    "info": "<i>From: language/operators</i>"
  },
  {
    "category": "Composite",
    "url": "/routine/truncate",
    "info": "<i>From: type/Cool</i>",
    "value": "truncate"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/control</i>",
    "value": "if",
    "url": "/syntax/if"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Proc/Async, type/independent-routines</i>",
    "value": "print",
    "url": "/routine/print"
  },
  {
    "category": "Composite",
    "value": "Mainline",
    "url": "/syntax/Mainline",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "value": "RHS",
    "url": "/syntax/RHS",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Str</i>",
    "value": "substr-eq",
    "url": "/routine/substr-eq"
  },
  {
    "value": "supply emit",
    "info": "<i>From: language/control</i>",
    "category": "Composite",
    "url": "/syntax/supply%20emit"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/tclc",
    "value": "tclc"
  },
  {
    "url": "/syntax/fiddly",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "fiddly"
  },
  {
    "value": "keys",
    "info": "<i>From: type/Baggy</i>",
    "url": "/routine/keys",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/syntax/Mayspec",
    "info": "<i>From: language/glossary</i>",
    "value": "Mayspec"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Int</i>",
    "value": "Bridge",
    "url": "/routine/Bridge"
  },
  {
    "url": "/syntax/Variable",
    "value": "Variable",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite"
  },
  {
    "value": "Range",
    "url": "/routine/Range",
    "info": "<i>From: type/Int</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/classtut, language/objects</i>",
    "url": "/syntax/class",
    "value": "class"
  },
  {
    "info": "<i>From: language/variables</i>",
    "url": "/syntax/has",
    "category": "Composite",
    "value": "has"
  },
  {
    "url": "/syntax/%3Asamemark",
    "value": ":samemark",
    "info": "<i>From: language/regexes</i>",
    "category": "Composite"
  },
  {
    "url": "/routine/%2A%2A",
    "category": "Composite",
    "value": "**",
    "info": "<i>From: language/operators</i>"
  },
  {
    "url": "/routine/o%2C%20infix%20%E2%88%98",
    "value": "o, infix ∘",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/tan",
    "value": "tan",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/shell",
    "value": "shell",
    "info": "<i>From: type/independent-routines</i>"
  },
  {
    "category": "Composite",
    "url": "/routine/open",
    "info": "<i>From: type/independent-routines</i>",
    "value": "open"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "value": "positive lookaround assertion <?>",
    "url": "/syntax/positive%20lookaround%20assertion%20%3C%3F%3E",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "Num",
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/Num"
  },
  {
    "value": "Z",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/Z",
    "category": "Composite"
  },
  {
    "url": "/syntax/Parse%20Tree",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "Parse Tree"
  },
  {
    "value": "Interface",
    "url": "/syntax/Interface",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "value": "IRC lingo",
    "url": "/syntax/IRC%20lingo",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/decont",
    "value": "decont",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "value": ":samespace",
    "url": "/syntax/%3Asamespace",
    "category": "Composite"
  },
  {
    "value": "for",
    "info": "<i>From: language/control</i>",
    "category": "Composite",
    "url": "/syntax/for"
  },
  {
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "url": "/routine/%3D%3D%2C%20infix%20%E2%A9%B5",
    "value": "==, infix ⩵"
  },
  {
    "value": "LHS",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/LHS",
    "category": "Composite"
  },
  {
    "value": "conj",
    "url": "/routine/conj",
    "category": "Composite",
    "info": "<i>From: type/Cool</i>"
  },
  {
    "url": "/routine/unival",
    "value": "unival",
    "info": "<i>From: type/Str, type/Int</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/functions</i>",
    "value": "multi",
    "url": "/syntax/multi"
  },
  {
    "info": "<i>From: type/Str</i>",
    "category": "Composite",
    "url": "/routine/univals",
    "value": "univals"
  },
  {
    "info": "<i>From: language/operators</i>",
    "value": "^..",
    "url": "/routine/%5E..",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/nativecast",
    "info": "<i>From: language/nativecall</i>",
    "value": "nativecast"
  },
  {
    "category": "Composite",
    "value": "@_",
    "info": "<i>From: language/functions</i>",
    "url": "/syntax/%40_"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "category": "Composite",
    "url": "/routine/exp",
    "value": "exp"
  },
  {
    "value": "*",
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/%2A",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/%26lt%3B",
    "info": "<i>From: language/operators</i>",
    "value": "<"
  },
  {
    "category": "Composite",
    "url": "/syntax/nextwith",
    "info": "<i>From: language/functions</i>",
    "value": "nextwith"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%28elem%29%2C%20infix%20%E2%88%88",
    "value": "(elem), infix ∈"
  },
  {
    "info": "<i>From: language/operators, language/operators</i>",
    "category": "Composite",
    "value": "+^",
    "url": "/routine/%2B%5E"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "category": "Composite",
    "value": "atan2",
    "url": "/routine/atan2"
  },
  {
    "url": "/routine/%2B%26gt%3B",
    "value": "+>",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "info": "<i>From: type/Proc/Async</i>",
    "category": "Composite",
    "value": "close-stdin",
    "url": "/routine/close-stdin"
  },
  {
    "url": "/routine/%2C%3D",
    "category": "Composite",
    "value": ",=",
    "info": "<i>From: language/operators</i>"
  },
  {
    "value": "raw",
    "category": "Composite",
    "url": "/routine/raw",
    "info": "<i>From: type/Parameter</i>"
  },
  {
    "info": "<i>From: type/Dateish</i>",
    "category": "Composite",
    "value": "day-of-week",
    "url": "/routine/day-of-week"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "Lexing",
    "url": "/syntax/Lexing"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/cosec",
    "value": "cosec",
    "category": "Composite"
  },
  {
    "value": "emit",
    "category": "Composite",
    "info": "<i>From: type/independent-routines</i>",
    "url": "/routine/emit"
  },
  {
    "url": "/syntax/%28%20%29",
    "info": "<i>From: language/regexes</i>",
    "category": "Composite",
    "value": "( )"
  },
  {
    "value": "^^",
    "url": "/routine/%5E%5E",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "value": "is-prime",
    "info": "<i>From: type/Int</i>",
    "url": "/routine/is-prime",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/%3F%7C",
    "info": "<i>From: language/operators</i>",
    "value": "?|"
  },
  {
    "category": "Composite",
    "value": "weekday-of-month",
    "info": "<i>From: type/Dateish</i>",
    "url": "/routine/weekday-of-month"
  },
  {
    "category": "Composite",
    "url": "/routine/~%5E",
    "info": "<i>From: language/operators, language/operators</i>",
    "value": "~^"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/independent-routines</i>",
    "url": "/routine/chdir",
    "value": "chdir"
  },
  {
    "category": "Composite",
    "url": "/syntax/rakudoc",
    "value": "rakudoc",
    "info": "<i>From: programs/02-reading-docs</i>"
  },
  {
    "url": "/routine/%28%7C%29%2C%20infix%20%E2%88%AA",
    "value": "(|), infix ∪",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "opcode",
    "category": "Composite",
    "url": "/syntax/opcode"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "NFG",
    "url": "/syntax/NFG"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/andthen",
    "value": "andthen"
  },
  {
    "url": "/routine/DateTime",
    "value": "DateTime",
    "category": "Composite",
    "info": "<i>From: type/Str</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/regexes, language/regexes</i>",
    "value": "s/ / /",
    "url": "/syntax/s%2F%20%2F%20%2F"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/lvalue",
    "value": "lvalue"
  },
  {
    "value": "\\w",
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/%5Cw"
  },
  {
    "category": "Composite",
    "value": "repeated",
    "info": "<i>From: type/independent-routines</i>",
    "url": "/routine/repeated"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/variables</i>",
    "value": "$_",
    "url": "/syntax/%24_"
  },
  {
    "info": "<i>From: type/independent-routines</i>",
    "value": "spurt",
    "url": "/routine/spurt",
    "category": "Composite"
  },
  {
    "url": "/syntax/Phasers",
    "info": "<i>From: language/control</i>",
    "value": "Phasers",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/variables</i>",
    "url": "/syntax/my",
    "category": "Composite",
    "value": "my"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Dateish</i>",
    "url": "/routine/year",
    "value": "year"
  },
  {
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/trim",
    "category": "Composite",
    "value": "trim"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%26lt%3B%26gt%3B",
    "value": "<>"
  },
  {
    "url": "/routine/named",
    "category": "Composite",
    "info": "<i>From: type/Parameter</i>",
    "value": "named"
  },
  {
    "value": "nextcallee",
    "info": "<i>From: language/functions</i>",
    "category": "Composite",
    "url": "/syntax/nextcallee"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Cool, type/independent-routines</i>",
    "value": "unpolar",
    "url": "/routine/unpolar"
  },
  {
    "value": "roots",
    "category": "Composite",
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/roots"
  },
  {
    "info": "<i>From: language/functions</i>",
    "url": "/syntax/callsame",
    "value": "callsame",
    "category": "Composite"
  },
  {
    "value": "%INC (Perl)",
    "category": "Composite",
    "info": "<i>From: language/5to6-perlvar</i>",
    "url": "/syntax/%25INC%20%28Perl%29"
  },
  {
    "value": "Not Quite Perl",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/Not%20Quite%20Perl",
    "category": "Composite"
  },
  {
    "value": "Sigil",
    "category": "Composite",
    "url": "/syntax/Sigil",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "value": "acotanh",
    "url": "/routine/acotanh",
    "info": "<i>From: type/Cool</i>",
    "category": "Composite"
  },
  {
    "url": "/syntax/%3C%7Cw%3E",
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "value": "<|w>"
  },
  {
    "category": "Composite",
    "url": "/syntax/ASCII%20operator",
    "info": "<i>From: language/glossary</i>",
    "value": "ASCII operator"
  },
  {
    "value": "X",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "url": "/routine/X"
  },
  {
    "category": "Composite",
    "value": "SetHash",
    "url": "/routine/SetHash",
    "info": "<i>From: type/Baggy</i>"
  },
  {
    "info": "<i>From: language/classtut</i>",
    "value": "attributes",
    "category": "Composite",
    "url": "/syntax/attributes"
  },
  {
    "url": "/routine/ends-with",
    "value": "ends-with",
    "category": "Composite",
    "info": "<i>From: type/Str</i>"
  },
  {
    "value": "formatter",
    "category": "Composite",
    "info": "<i>From: type/Dateish</i>",
    "url": "/routine/formatter"
  },
  {
    "url": "/routine/div",
    "value": "div",
    "info": "<i>From: type/Int, language/operators</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Cool</i>",
    "value": "Failure",
    "url": "/routine/Failure"
  },
  {
    "value": "sign",
    "info": "<i>From: type/Cool</i>",
    "category": "Composite",
    "url": "/routine/sign"
  },
  {
    "category": "Composite",
    "value": "acosh",
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/acosh"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/TheDamian",
    "value": "TheDamian",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": "and",
    "url": "/routine/and"
  },
  {
    "url": "/routine/%21%21%21",
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": "!!!"
  },
  {
    "value": "rw",
    "url": "/routine/rw",
    "category": "Composite",
    "info": "<i>From: type/Parameter, type/Attribute</i>"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "Arity",
    "url": "/syntax/Arity",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "Multi-Dispatch",
    "category": "Composite",
    "url": "/syntax/Multi-Dispatch"
  },
  {
    "category": "Composite",
    "url": "/routine/proc",
    "info": "<i>From: type/X/Proc/Unsuccessful</i>",
    "value": "proc"
  },
  {
    "url": "/syntax/sub",
    "category": "Composite",
    "info": "<i>From: language/functions</i>",
    "value": "sub"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Str</i>",
    "value": "val",
    "url": "/routine/val"
  },
  {
    "value": "(==), infix ≡",
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%28%3D%3D%29%2C%20infix%20%E2%89%A1"
  },
  {
    "category": "Composite",
    "url": "/syntax/Type%20Objects",
    "info": "<i>From: language/glossary</i>",
    "value": "Type Objects"
  },
  {
    "info": "<i>From: type/Parameter</i>",
    "category": "Composite",
    "url": "/routine/coerce_type",
    "value": "coerce_type"
  },
  {
    "value": "$?DISTRIBUTION",
    "info": "<i>From: language/variables</i>",
    "url": "/syntax/%24%3FDISTRIBUTION",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "earlier",
    "url": "/routine/earlier",
    "info": "<i>From: type/Dateish</i>"
  },
  {
    "url": "/syntax/%5Ch",
    "info": "<i>From: language/regexes</i>",
    "category": "Composite",
    "value": "\\h"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "url": "/syntax/Virtual%20Machine",
    "value": "Virtual Machine"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/Anonymous",
    "category": "Composite",
    "value": "Anonymous"
  },
  {
    "info": "<i>From: type/Dateish</i>",
    "url": "/routine/is-leap-year",
    "value": "is-leap-year",
    "category": "Composite"
  },
  {
    "value": "< >",
    "category": "Composite",
    "url": "/routine/%26lt%3B%20%26gt%3B",
    "info": "<i>From: language/operators, language/operators</i>"
  },
  {
    "info": "<i>From: type/independent-routines</i>",
    "value": "slurp",
    "category": "Composite",
    "url": "/routine/slurp"
  },
  {
    "category": "Composite",
    "value": "contains",
    "url": "/routine/contains",
    "info": "<i>From: type/Str, type/Cool</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/but",
    "value": "but"
  },
  {
    "url": "/syntax/N%C3%A9e",
    "category": "Composite",
    "value": "Née",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "url": "/routine/ne",
    "info": "<i>From: language/operators</i>",
    "value": "ne",
    "category": "Composite"
  },
  {
    "url": "/routine/expmod",
    "value": "expmod",
    "info": "<i>From: type/Int</i>",
    "category": "Composite"
  },
  {
    "value": "cglobal",
    "category": "Composite",
    "url": "/routine/cglobal",
    "info": "<i>From: language/nativecall</i>"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "IRC",
    "category": "Composite",
    "url": "/syntax/IRC"
  },
  {
    "url": "/routine/%26gt%3B%3D%2C%20infix%20%E2%89%A5",
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": ">=, infix ≥"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/variables</i>",
    "url": "/syntax/%24%2F",
    "value": "$/"
  },
  {
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "url": "/routine/%26lt%3B%3D%2C%20infix%20%E2%89%A4",
    "value": "<=, infix ≤"
  },
  {
    "url": "/routine/parse-base",
    "category": "Composite",
    "value": "parse-base",
    "info": "<i>From: type/Str</i>"
  },
  {
    "url": "/syntax/invocant%20%28Basics%29",
    "value": "invocant (Basics)",
    "info": "<i>From: language/101-basics</i>",
    "category": "Composite"
  },
  {
    "url": "/syntax/our",
    "category": "Composite",
    "info": "<i>From: language/variables</i>",
    "value": "our"
  },
  {
    "category": "Composite",
    "url": "/routine/asech",
    "value": "asech",
    "info": "<i>From: type/Cool</i>"
  },
  {
    "info": "<i>From: language/classtut</i>",
    "category": "Composite",
    "value": "Overriding default gist method",
    "url": "/syntax/Overriding%20default%20gist%20method"
  },
  {
    "url": "/syntax/Type%20Smiley",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "Type Smiley"
  },
  {
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/ords",
    "category": "Composite",
    "value": "ords"
  },
  {
    "url": "/routine/samemark",
    "info": "<i>From: type/Str</i>",
    "value": "samemark",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/atanh",
    "category": "Composite",
    "value": "atanh"
  },
  {
    "info": "<i>From: language/syntax</i>",
    "url": "/routine/term%3A%26lt%3B%26gt%3B",
    "value": "term:<>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%2A",
    "value": "*"
  },
  {
    "info": "<i>From: language/operators</i>",
    "value": "fff^",
    "category": "Composite",
    "url": "/routine/fff%5E"
  },
  {
    "info": "<i>From: type/Dateish</i>",
    "category": "Composite",
    "url": "/routine/week",
    "value": "week"
  },
  {
    "url": "/routine/%7C%7C",
    "value": "||",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "value": "block",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/block"
  },
  {
    "info": "<i>From: language/control</i>",
    "value": "statements",
    "url": "/syntax/statements",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/lines",
    "value": "lines"
  },
  {
    "info": "<i>From: language/variables, language/operators</i>",
    "url": "/routine/let",
    "category": "Composite",
    "value": "let"
  },
  {
    "value": "ready",
    "category": "Composite",
    "info": "<i>From: type/Proc/Async</i>",
    "url": "/routine/ready"
  },
  {
    "value": "mod",
    "url": "/routine/mod",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "value": "when",
    "category": "Composite",
    "info": "<i>From: language/control</i>",
    "url": "/syntax/when"
  },
  {
    "info": "<i>From: language/operators</i>",
    "value": "before",
    "category": "Composite",
    "url": "/routine/before"
  },
  {
    "info": "<i>From: type/Baggy</i>",
    "value": "classify-list",
    "category": "Composite",
    "url": "/routine/classify-list"
  },
  {
    "info": "<i>From: language/5to6-perlvar</i>",
    "category": "Composite",
    "value": "$0 (Perl)",
    "url": "/syntax/%240%20%28Perl%29"
  },
  {
    "url": "/routine/~%26lt%3B",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "~<"
  },
  {
    "url": "/routine/~~",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "~~"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/subst",
    "value": "subst"
  },
  {
    "value": ":pos",
    "info": "<i>From: language/regexes</i>",
    "category": "Composite",
    "url": "/syntax/%3Apos"
  },
  {
    "category": "Composite",
    "url": "/routine/%5Efff",
    "value": "^fff",
    "info": "<i>From: language/operators</i>"
  },
  {
    "url": "/syntax/tilde",
    "value": "tilde",
    "category": "Composite",
    "info": "<i>From: language/regexes</i>"
  },
  {
    "url": "/syntax/topic%20variable%20%28Basics%29",
    "info": "<i>From: language/101-basics</i>",
    "category": "Composite",
    "value": "topic variable (Basics)"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "value",
    "url": "/syntax/value",
    "category": "Composite"
  },
  {
    "value": "ff^",
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/ff%5E"
  },
  {
    "url": "/routine/%3D%20%28item%20assignment%29",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "= (item assignment)"
  },
  {
    "url": "/routine/fc",
    "info": "<i>From: type/Str, type/Cool</i>",
    "value": "fc",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Baggy</i>",
    "value": "Set",
    "url": "/routine/Set"
  },
  {
    "url": "/routine/%3A%3A%3D",
    "value": "::=",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "url": "/routine/not",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "not"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/asin",
    "category": "Composite",
    "value": "asin"
  },
  {
    "value": "samewith",
    "url": "/syntax/samewith",
    "category": "Composite",
    "info": "<i>From: language/functions</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Dateish</i>",
    "url": "/routine/week-year",
    "value": "week-year"
  },
  {
    "category": "Composite",
    "url": "/routine/%21%3D%2C%20infix%20%E2%89%A0",
    "value": "!=, infix ≠",
    "info": "<i>From: language/operators</i>"
  },
  {
    "category": "Composite",
    "url": "/syntax/Exegesis",
    "value": "Exegesis",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "value": "import",
    "info": "<i>From: language/module-packages, language/glossary</i>",
    "url": "/syntax/import",
    "category": "Composite"
  },
  {
    "url": "/syntax/Literal",
    "value": "Literal",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "category": "Composite",
    "url": "/syntax/token",
    "info": "<i>From: language/grammars</i>",
    "value": "token"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "Token",
    "url": "/syntax/Token",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/variables</i>",
    "url": "/syntax/%26%3FROUTINE",
    "value": "&?ROUTINE"
  },
  {
    "category": "Composite",
    "url": "/routine/%26amp%3B%26amp%3B",
    "value": "&&",
    "info": "<i>From: language/operators</i>"
  },
  {
    "info": "<i>From: language/5to6-perlvar</i>",
    "value": "$_ (Perl)",
    "category": "Composite",
    "url": "/syntax/%24_%20%28Perl%29"
  },
  {
    "url": "/syntax/Abstract%20Class",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "value": "Abstract Class"
  },
  {
    "value": "<==",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%26lt%3B%3D%3D",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/classtut</i>",
    "url": "/syntax/type%20object",
    "category": "Composite",
    "value": "type object"
  },
  {
    "category": "Composite",
    "value": "TimToady",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/TimToady"
  },
  {
    "value": "property",
    "category": "Composite",
    "url": "/syntax/property",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "value": "\\x",
    "url": "/syntax/%5Cx",
    "info": "<i>From: language/regexes</i>",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Proc/Async</i>",
    "category": "Composite",
    "value": "write",
    "url": "/routine/write"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "Rakudo",
    "category": "Composite",
    "url": "/syntax/Rakudo"
  },
  {
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "xor",
    "url": "/routine/xor"
  },
  {
    "value": "instance",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/instance"
  },
  {
    "url": "/routine/%3F%3F%3F",
    "info": "<i>From: language/operators</i>",
    "value": "???",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/QAST",
    "value": "QAST"
  },
  {
    "value": "FatRat",
    "category": "Composite",
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/FatRat"
  },
  {
    "category": "Composite",
    "value": "Pull request",
    "url": "/syntax/Pull%20request",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "url": "/syntax/%7C%7C",
    "value": "||",
    "category": "Composite",
    "info": "<i>From: language/regexes</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "value": "<( )>",
    "url": "/syntax/%3C%28%20%29%3E"
  },
  {
    "value": "asec",
    "url": "/routine/asec",
    "info": "<i>From: type/Cool</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "Actions",
    "info": "<i>From: language/grammars</i>",
    "url": "/syntax/Actions"
  },
  {
    "value": "leg",
    "url": "/routine/leg",
    "info": "<i>From: language/operators</i>",
    "category": "Composite"
  },
  {
    "url": "/syntax/closures",
    "category": "Composite",
    "info": "<i>From: language/functions</i>",
    "value": "closures"
  },
  {
    "value": "unit",
    "category": "Composite",
    "info": "<i>From: language/syntax</i>",
    "url": "/syntax/unit"
  },
  {
    "value": "Allomorph",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "url": "/syntax/Allomorph"
  },
  {
    "url": "/routine/day-of-year",
    "info": "<i>From: type/Dateish</i>",
    "value": "day-of-year",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "url": "/syntax/API",
    "value": "API"
  },
  {
    "value": "command",
    "info": "<i>From: type/Proc/Async</i>",
    "category": "Composite",
    "url": "/routine/command"
  },
  {
    "category": "Composite",
    "url": "/routine/get",
    "value": "get",
    "info": "<i>From: type/independent-routines</i>"
  },
  {
    "info": "<i>From: language/operators, language/operators</i>",
    "url": "/routine/%5E",
    "value": "^",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "url": "/routine/hash",
    "value": "hash",
    "info": "<i>From: type/Baggy</i>"
  },
  {
    "url": "/routine/EVAL",
    "info": "<i>From: type/Cool, type/independent-routines</i>",
    "category": "Composite",
    "value": "EVAL"
  },
  {
    "category": "Composite",
    "url": "/syntax/Parrot",
    "value": "Parrot",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/Colon%20Pair",
    "value": "Colon Pair",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Dateish</i>",
    "url": "/routine/days-in-year",
    "value": "days-in-year",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Parameter</i>",
    "url": "/routine/invocant",
    "category": "Composite",
    "value": "invocant"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "url": "/syntax/Propspec",
    "value": "Propspec"
  },
  {
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%E2%89%A2",
    "value": "≢",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/operators, language/operators</i>",
    "url": "/routine/-",
    "category": "Composite",
    "value": "-"
  },
  {
    "info": "<i>From: language/variables</i>",
    "url": "/syntax/%26%3FBLOCK",
    "value": "&?BLOCK",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Baggy</i>",
    "value": "grab",
    "category": "Composite",
    "url": "/routine/grab"
  },
  {
    "value": "asinh",
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/asinh",
    "category": "Composite"
  },
  {
    "url": "/routine/so",
    "info": "<i>From: language/operators</i>",
    "value": "so",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/independent-routines</i>",
    "value": "undefine",
    "category": "Composite",
    "url": "/routine/undefine"
  },
  {
    "value": "prompt",
    "url": "/routine/prompt",
    "info": "<i>From: type/independent-routines</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "file",
    "url": "/routine/file",
    "info": "<i>From: type/CallFrame</i>"
  },
  {
    "category": "Composite",
    "url": "/routine/bind-stderr",
    "info": "<i>From: type/Proc/Async</i>",
    "value": "bind-stderr"
  },
  {
    "category": "Composite",
    "url": "/routine/unimatch",
    "info": "<i>From: type/Cool</i>",
    "value": "unimatch"
  },
  {
    "info": "<i>From: language/variables</i>",
    "category": "Composite",
    "url": "/syntax/Twigil",
    "value": "Twigil"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "Advent Calendar",
    "url": "/syntax/Advent%20Calendar",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "bind-stdout",
    "url": "/routine/bind-stdout",
    "info": "<i>From: type/Proc/Async</i>"
  },
  {
    "url": "/routine/%3D%3D%26gt%3B",
    "value": "==>",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "url": "/routine/ACCEPTS",
    "info": "<i>From: type/Signature, type/Str, type/Baggy</i>",
    "category": "Composite",
    "value": "ACCEPTS"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "category": "Composite",
    "url": "/routine/cos",
    "value": "cos"
  },
  {
    "category": "Composite",
    "url": "/routine/trans",
    "info": "<i>From: type/Str, type/Cool</i>",
    "value": "trans"
  },
  {
    "info": "<i>From: type/Parameter, type/Attribute</i>",
    "value": "readonly",
    "category": "Composite",
    "url": "/routine/readonly"
  },
  {
    "url": "/syntax/state",
    "info": "<i>From: language/variables</i>",
    "category": "Composite",
    "value": "state"
  },
  {
    "value": "chars",
    "info": "<i>From: type/Str, type/Cool</i>",
    "category": "Composite",
    "url": "/routine/chars"
  },
  {
    "url": "/routine/UInt",
    "category": "Composite",
    "info": "<i>From: type/Cool</i>",
    "value": "UInt"
  },
  {
    "info": "<i>From: type/Baggy</i>",
    "url": "/routine/pairs",
    "category": "Composite",
    "value": "pairs"
  },
  {
    "category": "Composite",
    "value": "sqrt",
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/sqrt"
  },
  {
    "value": "Huffmanize",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "url": "/syntax/Huffmanize"
  },
  {
    "url": "/syntax/Reify",
    "value": "Reify",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite"
  },
  {
    "value": "after",
    "url": "/routine/after",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "url": "/routine/%28%26lt%3B%3D%29%2C%20infix%20%E2%8A%86",
    "info": "<i>From: language/operators</i>",
    "value": "(<=), infix ⊆",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/CallFrame</i>",
    "url": "/routine/line",
    "value": "line",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": "(^), infix ⊖",
    "url": "/routine/%28%5E%29%2C%20infix%20%E2%8A%96"
  },
  {
    "url": "/syntax/next",
    "info": "<i>From: language/control</i>",
    "category": "Composite",
    "value": "next"
  },
  {
    "category": "Composite",
    "url": "/routine/type",
    "value": "type",
    "info": "<i>From: type/Parameter, type/Attribute</i>"
  },
  {
    "value": "\\c",
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/%5Cc"
  },
  {
    "url": "/syntax/test%20suite",
    "value": "test suite",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite"
  },
  {
    "url": "/routine/get_value",
    "info": "<i>From: type/Attribute</i>",
    "value": "get_value",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "is DEPRECATED (Attribute)",
    "info": "<i>From: type/Attribute</i>",
    "url": "/syntax/is%20DEPRECATED%20%28Attribute%29"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "pugs",
    "url": "/syntax/pugs"
  },
  {
    "info": "<i>From: language/101-basics</i>",
    "value": "hash (Basics)",
    "url": "/syntax/hash%20%28Basics%29",
    "category": "Composite"
  },
  {
    "url": "/routine/new",
    "value": "new",
    "category": "Composite",
    "info": "<i>From: type/Proc/Async, type/Int</i>"
  },
  {
    "value": "roast",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/roast"
  },
  {
    "url": "/routine/%25%25",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "%%"
  },
  {
    "url": "/routine/set_value",
    "value": "set_value",
    "info": "<i>From: type/Attribute</i>",
    "category": "Composite"
  },
  {
    "value": "loop",
    "category": "Composite",
    "url": "/syntax/loop",
    "info": "<i>From: language/control</i>"
  },
  {
    "url": "/syntax/%24%24%20%28Perl%29",
    "value": "$$ (Perl)",
    "category": "Composite",
    "info": "<i>From: language/5to6-perlvar</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/independent-routines</i>",
    "value": "flat",
    "url": "/routine/flat"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/independent-routines</i>",
    "url": "/routine/exit",
    "value": "exit"
  },
  {
    "value": "Named captures",
    "category": "Composite",
    "url": "/syntax/Named%20captures",
    "info": "<i>From: language/regexes</i>"
  },
  {
    "value": "wrapped routines",
    "info": "<i>From: language/functions</i>",
    "url": "/syntax/wrapped%20routines",
    "category": "Composite"
  },
  {
    "url": "/routine/lt",
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "lt"
  },
  {
    "url": "/routine/%3F%3F%20%21%21",
    "value": "?? !!",
    "info": "<i>From: language/operators</i>",
    "category": "Composite"
  },
  {
    "url": "/routine/w",
    "value": "w",
    "info": "<i>From: type/Proc/Async</i>",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Signature, type/Str, type/Int</i>",
    "value": "Capture",
    "category": "Composite",
    "url": "/routine/Capture"
  },
  {
    "url": "/syntax/diffy",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "diffy"
  },
  {
    "value": "elems",
    "url": "/routine/elems",
    "category": "Composite",
    "info": "<i>From: type/Baggy</i>"
  },
  {
    "value": "run",
    "url": "/routine/run",
    "category": "Composite",
    "info": "<i>From: type/independent-routines</i>"
  },
  {
    "url": "/syntax/S%2F%2F%2F%20non-destructive%20substitution",
    "info": "<i>From: language/regexes</i>",
    "value": "S/// non-destructive substitution",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "Tight",
    "url": "/syntax/Tight"
  },
  {
    "value": "prefix",
    "info": "<i>From: type/Parameter</i>",
    "category": "Composite",
    "url": "/routine/prefix"
  },
  {
    "url": "/syntax/Backtracking",
    "value": "Backtracking",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "category": "Composite",
    "value": "=~=",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/%3D~%3D"
  },
  {
    "url": "/syntax/Stub",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "value": "Stub"
  },
  {
    "info": "<i>From: language/5to6-perlvar</i>",
    "category": "Composite",
    "url": "/syntax/%24%22%20%28Perl%29",
    "value": "$\" (Perl)"
  },
  {
    "category": "Composite",
    "value": "\\n",
    "url": "/syntax/%5Cn",
    "info": "<i>From: language/regexes</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Proc/Async</i>",
    "value": "args",
    "url": "/routine/args"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": "~|",
    "url": "/routine/~%7C"
  },
  {
    "url": "/routine/%28%26gt%3B%3D%29%2C%20infix%20%E2%8A%87",
    "value": "(>=), infix ⊇",
    "info": "<i>From: language/operators</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "6model",
    "url": "/syntax/6model",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "value": "kill",
    "url": "/routine/kill",
    "info": "<i>From: type/Proc/Async</i>",
    "category": "Composite"
  },
  {
    "url": "/routine/%5E..%5E",
    "info": "<i>From: language/operators</i>",
    "value": "^..^",
    "category": "Composite"
  },
  {
    "info": "<i>From: language/operators, language/operators</i>",
    "category": "Composite",
    "value": "( )",
    "url": "/routine/%28%20%29"
  },
  {
    "value": "unicmp",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/unicmp",
    "category": "Composite"
  },
  {
    "url": "/syntax/Damian%20Conway",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "value": "Damian Conway"
  },
  {
    "url": "/routine/..",
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": ".."
  },
  {
    "category": "Composite",
    "url": "/routine/%E2%8A%88",
    "value": "⊈",
    "info": "<i>From: language/operators</i>"
  },
  {
    "info": "<i>From: type/Str, type/Cool</i>",
    "value": "index",
    "category": "Composite",
    "url": "/routine/index"
  },
  {
    "category": "Composite",
    "value": "%",
    "info": "<i>From: language/regexes</i>",
    "url": "/syntax/%25"
  },
  {
    "url": "/routine/NFC",
    "value": "NFC",
    "info": "<i>From: type/Str</i>",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/independent-routines</i>",
    "url": "/routine/note",
    "category": "Composite",
    "value": "note"
  },
  {
    "url": "/syntax/NQP",
    "category": "Composite",
    "value": "NQP",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "url": "/routine/code",
    "category": "Composite",
    "info": "<i>From: type/CallFrame</i>",
    "value": "code"
  },
  {
    "value": "orelse",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/orelse",
    "category": "Composite"
  },
  {
    "url": "/routine/constraints",
    "value": "constraints",
    "category": "Composite",
    "info": "<i>From: type/Parameter</i>"
  },
  {
    "info": "<i>From: language/regexes</i>",
    "category": "Composite",
    "url": "/syntax/%3F%20%28quantifier%29",
    "value": "? (quantifier)"
  },
  {
    "url": "/syntax/Adverbial%20Pair",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "value": "Adverbial Pair"
  },
  {
    "value": "round",
    "url": "/routine/round",
    "info": "<i>From: type/Cool</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/POD",
    "value": "POD"
  },
  {
    "category": "Composite",
    "value": "bind-stdin",
    "info": "<i>From: type/Proc/Async</i>",
    "url": "/routine/bind-stdin"
  },
  {
    "url": "/routine/type_captures",
    "value": "type_captures",
    "info": "<i>From: type/Parameter</i>",
    "category": "Composite"
  },
  {
    "url": "/syntax/%5E%5E",
    "info": "<i>From: language/regexes</i>",
    "value": "^^",
    "category": "Composite"
  },
  {
    "value": "ceiling",
    "info": "<i>From: type/Cool</i>",
    "category": "Composite",
    "url": "/routine/ceiling"
  },
  {
    "category": "Composite",
    "url": "/routine/tc",
    "value": "tc",
    "info": "<i>From: type/Str, type/Cool</i>"
  },
  {
    "value": "Version",
    "category": "Composite",
    "url": "/routine/Version",
    "info": "<i>From: type/Str</i>"
  },
  {
    "value": "binder",
    "url": "/syntax/binder",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>"
  },
  {
    "url": "/syntax/before",
    "category": "Composite",
    "info": "<i>From: language/regexes</i>",
    "value": "before"
  },
  {
    "category": "Composite",
    "url": "/routine/floor",
    "value": "floor",
    "info": "<i>From: type/Cool</i>"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Proc/Async, type/independent-routines</i>",
    "value": "put",
    "url": "/routine/put"
  },
  {
    "category": "Composite",
    "value": "optional",
    "url": "/routine/optional",
    "info": "<i>From: type/Parameter</i>"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "value": "cotan",
    "url": "/routine/cotan",
    "category": "Composite"
  },
  {
    "value": "Handle",
    "info": "<i>From: language/glossary</i>",
    "category": "Composite",
    "url": "/syntax/Handle"
  },
  {
    "url": "/routine/mm-dd-yyyy",
    "value": "mm-dd-yyyy",
    "category": "Composite",
    "info": "<i>From: type/Dateish</i>"
  },
  {
    "value": "bytecode",
    "category": "Composite",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/bytecode"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "category": "Composite",
    "value": "acosec",
    "url": "/routine/acosec"
  },
  {
    "url": "/routine/%2B%26lt%3B",
    "info": "<i>From: language/operators</i>",
    "value": "+<",
    "category": "Composite"
  },
  {
    "value": "required",
    "url": "/routine/required",
    "category": "Composite",
    "info": "<i>From: type/Attribute</i>"
  },
  {
    "url": "/syntax/for%20%28Basics%29",
    "value": "for (Basics)",
    "category": "Composite",
    "info": "<i>From: language/101-basics</i>"
  },
  {
    "info": "<i>From: type/Int</i>",
    "url": "/routine/lsb",
    "category": "Composite",
    "value": "lsb"
  },
  {
    "category": "Composite",
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/trim-trailing",
    "value": "trim-trailing"
  },
  {
    "category": "Composite",
    "value": "is tighter",
    "info": "<i>From: language/functions</i>",
    "url": "/syntax/is%20tighter"
  },
  {
    "info": "<i>From: type/independent-routines</i>",
    "value": "lastcall",
    "url": "/routine/lastcall",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "annotations",
    "url": "/routine/annotations",
    "info": "<i>From: type/CallFrame</i>"
  },
  {
    "category": "Composite",
    "value": "NFKC",
    "url": "/routine/NFKC",
    "info": "<i>From: type/Str</i>"
  },
  {
    "category": "Composite",
    "value": "eq",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/eq"
  },
  {
    "info": "<i>From: type/Str</i>",
    "value": "indent",
    "url": "/routine/indent",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "url": "/routine/cis",
    "category": "Composite",
    "value": "cis"
  },
  {
    "category": "Composite",
    "url": "/syntax/DESTROY",
    "value": "DESTROY",
    "info": "<i>From: language/classtut</i>"
  },
  {
    "info": "<i>From: language/operators</i>",
    "category": "Composite",
    "value": "?&",
    "url": "/routine/%3F%26amp%3B"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "value": "codes",
    "url": "/routine/codes",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": "..^",
    "url": "/routine/..%5E"
  },
  {
    "category": "Composite",
    "info": "<i>From: language/operators</i>",
    "value": "⊉",
    "url": "/routine/%E2%8A%89"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "Semilist",
    "category": "Composite",
    "url": "/syntax/Semilist"
  },
  {
    "value": "(<), infix ⊂",
    "url": "/routine/%28%26lt%3B%29%2C%20infix%20%E2%8A%82",
    "category": "Composite",
    "info": "<i>From: language/operators</i>"
  },
  {
    "info": "<i>From: type/BagHash</i>",
    "url": "/routine/remove",
    "value": "remove",
    "category": "Composite"
  },
  {
    "url": "/routine/gist",
    "category": "Composite",
    "info": "<i>From: type/Attribute</i>",
    "value": "gist"
  },
  {
    "url": "/routine/minmax",
    "value": "minmax",
    "info": "<i>From: language/operators</i>",
    "category": "Composite"
  },
  {
    "category": "Composite",
    "value": "fff",
    "info": "<i>From: language/operators</i>",
    "url": "/routine/fff"
  },
  {
    "category": "Composite",
    "value": "//",
    "info": "<i>From: language/operators, language/operators</i>",
    "url": "/routine/%2F%2F"
  },
  {
    "category": "Composite",
    "value": "unless",
    "url": "/syntax/unless",
    "info": "<i>From: language/control</i>"
  },
  {
    "info": "<i>From: language/operators</i>",
    "value": ":",
    "category": "Composite",
    "url": "/routine/%3A"
  },
  {
    "value": "trim-leading",
    "category": "Composite",
    "info": "<i>From: type/Str, type/Cool</i>",
    "url": "/routine/trim-leading"
  },
  {
    "value": "is required (Attribute)",
    "url": "/syntax/is%20required%20%28Attribute%29",
    "category": "Composite",
    "info": "<i>From: type/Attribute</i>"
  },
  {
    "info": "<i>From: language/glossary</i>",
    "value": "Apocalypse",
    "url": "/syntax/Apocalypse",
    "category": "Composite"
  },
  {
    "info": "<i>From: type/Cool</i>",
    "value": "uniprop",
    "category": "Composite",
    "url": "/routine/uniprop"
  },
  {
    "info": "<i>From: language/control</i>",
    "url": "/syntax/return",
    "category": "Composite",
    "value": "return"
  },
  {
    "info": "<i>From: type/Baggy</i>",
    "category": "Composite",
    "value": "invert",
    "url": "/routine/invert"
  },
  {
    "value": "samecase",
    "category": "Composite",
    "url": "/routine/samecase",
    "info": "<i>From: type/Str, type/Cool</i>"
  },
  {
    "category": "Composite",
    "value": "Syntax Analysis",
    "info": "<i>From: language/glossary</i>",
    "url": "/syntax/Syntax%20Analysis"
  },
  {
    "value": "Module packages",
    "url": "/language/module-packages",
    "info": "<i>Creating module packages for code reuse</i>",
    "category": "Language"
  },
  {
    "category": "Language",
    "url": "/type/independent-routines",
    "info": "<i>Routines not defined within any class or role.</i>",
    "value": "Independent routines"
  },
  {
    "info": "<i>A Raku slang for documenting Raku software to aid development and use.</i>",
    "url": "/language/rakudoc",
    "value": "RakuDoc",
    "category": "Language"
  },
  {
    "value": "Operators",
    "category": "Language",
    "info": "<i>Common Raku infixes, prefixes, postfixes, and more!</i>",
    "url": "/language/operators"
  },
  {
    "category": "Language",
    "value": "A file to test blocks",
    "info": "<i>This is not a part of official Raku documentation</i>",
    "url": "/test"
  },
  {
    "info": "<i>Valid, invalid, and unexpected tables</i>",
    "category": "Language",
    "value": "Pod6 tables",
    "url": "/language/tables"
  },
  {
    "category": "Language",
    "info": "<i>Information about the people working on and using Raku</i>",
    "url": "/language/community",
    "value": "Community"
  },
  {
    "category": "Language",
    "info": "<i>Parsing and interpreting text</i>",
    "value": "Grammars",
    "url": "/language/grammars"
  },
  {
    "value": "Ruby to Raku - nutshell",
    "category": "Language",
    "info": "<i>Learning Raku from Ruby, in a nutshell: what do I already know?</i>",
    "url": "/language/rb-nutshell"
  },
  {
    "info": "<i>A tutorial about creating and using classes in Raku</i>",
    "value": "Classes and objects",
    "url": "/language/classtut",
    "category": "Language"
  },
  {
    "url": "/language/structures",
    "category": "Language",
    "value": "Data structures",
    "info": "<i>How Raku deals with data structures and what we can expect from them</i>"
  },
  {
    "info": "<i>An easy-to-use markup language for documenting Raku modules and programs</i>",
    "value": "Rakudoc - formerly POD6",
    "category": "Language",
    "url": "/language/pod-v2"
  },
  {
    "url": "/language/numerics",
    "info": "<i>Numeric types available in Raku</i>",
    "value": "Numerics",
    "category": "Language"
  },
  {
    "info": "<i>A basic introductory example of a Raku program</i>",
    "url": "/language/101-basics",
    "value": "Raku by example 101",
    "category": "Language"
  },
  {
    "value": "Native calling interface",
    "url": "/language/nativecall",
    "info": "<i>Call into dynamic libraries that follow the C calling convention</i>",
    "category": "Language"
  },
  {
    "info": "<i>General rules of Raku syntax</i>",
    "category": "Language",
    "value": "Syntax",
    "url": "/language/syntax"
  },
  {
    "category": "Language",
    "info": "<i>Input methods for unicode characters in terminals, the shell, and editors</i>",
    "url": "/language/unicode_entry",
    "value": "Entering unicode characters"
  },
  {
    "category": "Language",
    "value": "Variables",
    "url": "/language/variables",
    "info": "<i>Variables in Raku</i>"
  },
  {
    "value": "Glossary",
    "category": "Language",
    "url": "/language/glossary",
    "info": "<i>Glossary of Raku terminology</i>"
  },
  {
    "url": "/language/control",
    "info": "<i>Statements used to control the flow of execution</i>",
    "category": "Language",
    "value": "Control flow"
  },
  {
    "info": "<i>Object orientation in Raku</i>",
    "url": "/language/objects",
    "category": "Language",
    "value": "Object orientation"
  },
  {
    "value": "Pod6",
    "category": "Language",
    "info": "<i>An easy-to-use markup language for documenting Raku modules and programs</i>",
    "url": "/language/pod"
  },
  {
    "url": "/language/faq",
    "info": "<i>Frequently asked questions about Raku</i>",
    "category": "Language",
    "value": "FAQ"
  },
  {
    "info": "<i>Working with associative arrays/dictionaries/hashes</i>",
    "url": "/language/hashmap",
    "value": "Hashes and maps",
    "category": "Language"
  },
  {
    "value": "System interaction",
    "info": "<i>Working with the underlying operating system and running applications</i>",
    "url": "/language/system",
    "category": "Language"
  },
  {
    "category": "Language",
    "info": "<i>Pattern matching against strings</i>",
    "value": "Regexes",
    "url": "/language/regexes"
  },
  {
    "url": "/language/5to6-perlvar",
    "category": "Language",
    "info": "<i>A comparison of special variables in Perl and Raku</i>",
    "value": "Perl to Raku guide - special variables"
  },
  {
    "url": "/language/functions",
    "category": "Language",
    "info": "<i>Functions and functional programming in Raku</i>",
    "value": "Functions"
  },
  {
    "url": "/programs/02-reading-docs",
    "value": "Reading the docs",
    "category": "Programs",
    "info": "<i>rakudoc - the Raku pod reader</i>"
  },
  {
    "category": "Programs",
    "url": "/programs/01-debugging",
    "info": "<i>Modules and applications used to debug Raku programs</i>",
    "value": "Debugging"
  },
  {
    "category": "Programs",
    "url": "/programs/03-environment-variables",
    "value": "Environment variables used by the raku command line",
    "info": "<i>How to run Rakudo, a Raku implementation, and m</i> ... "
  },
  {
    "category": "Programs",
    "info": "<i>How to run Rakudo, a Raku implementation, and the command line options you can use wit</i> ... ",
    "url": "/programs/04-running-raku",
    "value": "Running Raku"
  },
  {
    "info": "<i>Collection of distinct weighted objects</i>",
    "category": "Role",
    "url": "/type/Baggy",
    "value": "role Baggy"
  },
  {
    "url": "/type/Dateish",
    "category": "Role",
    "value": "role Dateish",
    "info": "<i>Object that can be treated as a date</i>"
  },
  {
    "url": "/routine/cmp#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>cmp</b>"
  },
  {
    "url": "/syntax/%3A1st#language/regexessyntax:1st",
    "category": "Heading",
    "value": "In language/regexes",
    "info": ": section in <b>:1st</b>"
  },
  {
    "url": "/routine/rand#type/Coolroutinemethod",
    "info": ": section in <b>rand</b>",
    "category": "Heading",
    "value": "In type/Cool"
  },
  {
    "url": "/routine/mkdir#type/independent-routinesroutinesub",
    "info": ": section in <b>mkdir</b>",
    "category": "Heading",
    "value": "In type/independent-routines"
  },
  {
    "url": "/routine/log10#type/Coolroutineroutine",
    "info": ": section in <b>log10</b>",
    "value": "In type/Cool",
    "category": "Heading"
  },
  {
    "info": ": section in <b>last</b>",
    "value": "In language/control",
    "url": "/syntax/last#language/controlsyntaxlast",
    "category": "Heading"
  },
  {
    "url": "/routine/%3A%3D#language/operatorsroutineinfix",
    "category": "Heading",
    "info": ": section in <b>:=</b>",
    "value": "In language/operators"
  },
  {
    "info": ": section in <b>subst-mutate</b>",
    "url": "/routine/subst-mutate#type/Strroutinemethod",
    "category": "Heading",
    "value": "In type/Str"
  },
  {
    "url": "/routine/%E2%8A%84#language/operatorsroutineinfix",
    "info": ": section in <b>⊄</b>",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "info": ": section in <b>^ff^</b>",
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/%5Eff%5E#language/operatorsroutineinfix"
  },
  {
    "value": "In type/Int",
    "url": "/routine/msb#type/Introutineroutine",
    "info": ": section in <b>msb</b>",
    "category": "Heading"
  },
  {
    "url": "/routine/new-from-pairs#type/Baggyroutinemethod",
    "value": "In type/Baggy",
    "category": "Heading",
    "info": ": section in <b>new-from-pairs</b>"
  },
  {
    "value": "In type/Cool",
    "category": "Heading",
    "info": ": section in <b>atan</b>",
    "url": "/routine/atan#type/Coolroutineroutine"
  },
  {
    "info": ": section in <b>started</b>",
    "value": "In type/Proc/Async",
    "category": "Heading",
    "url": "/routine/started#type/Proc/Asyncroutinemethod"
  },
  {
    "url": "/language/module-packages#What_are_modules%3F",
    "value": "What are modules?",
    "category": "Heading",
    "info": ": section in <b>Module packages</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Module packages</b>",
    "value": "When to use modules",
    "url": "/language/module-packages#When_to_use_modules"
  },
  {
    "value": "Working with modules",
    "url": "/language/module-packages#Working_with_modules",
    "info": ": section in <b>Module packages</b>",
    "category": "Heading"
  },
  {
    "url": "/language/module-packages#Modules_on_disk",
    "category": "Heading",
    "value": "Modules on disk",
    "info": ": section in <b>Module packages</b>"
  },
  {
    "url": "/language/module-packages#File_and_module_naming",
    "info": ": section in <b>Module packages</b>",
    "value": "File and module naming",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Module packages</b>",
    "value": "The unit keyword",
    "category": "Heading",
    "url": "/language/module-packages#The_unit_keyword"
  },
  {
    "url": "/language/module-packages#What_happens_if_I_omit_module%3F",
    "info": ": section in <b>Module packages</b>",
    "category": "Heading",
    "value": "What happens if I omit module?"
  },
  {
    "info": ": section in <b>Module packages</b>",
    "category": "Heading",
    "url": "/language/module-packages#Lexical_aliasing_and_safety",
    "value": "Lexical aliasing and safety"
  },
  {
    "url": "/routine/add#type/BagHashroutinemethod",
    "category": "Heading",
    "value": "In type/BagHash",
    "info": ": section in <b>add</b>"
  },
  {
    "value": "In language/operators",
    "url": "/routine/%7B%20%7D#language/operatorsroutineterm",
    "category": "Heading",
    "info": ": section in <b>{ }</b>"
  },
  {
    "category": "Heading",
    "url": "/routine/%7B%20%7D#language/operatorsroutinepostcircumfix",
    "info": ": section in <b>{ }</b>",
    "value": "In language/operators"
  },
  {
    "category": "Heading",
    "info": ": section in <b>.</b>",
    "value": "In language/regexes",
    "url": "/syntax/.#language/regexessyntax."
  },
  {
    "info": ": section in <b>capture</b>",
    "url": "/routine/capture#type/Parameterroutinemethod",
    "value": "In type/Parameter",
    "category": "Heading"
  },
  {
    "info": ": section in <b>getc</b>",
    "category": "Heading",
    "value": "In type/independent-routines",
    "url": "/routine/getc#type/independent-routinesroutinesub"
  },
  {
    "category": "Heading",
    "url": "/syntax/%5Ct#language/regexessyntax%5Ct",
    "info": ": section in <b>\\t</b>",
    "value": "In language/regexes"
  },
  {
    "category": "Heading",
    "info": ": section in <b>chrs</b>",
    "url": "/routine/chrs#type/Coolroutineroutine",
    "value": "In type/Cool"
  },
  {
    "value": "In language/operators",
    "url": "/routine/%3F%5E#language/operatorsroutineprefix",
    "category": "Heading",
    "info": ": section in <b>?^</b>"
  },
  {
    "info": ": section in <b>?^</b>",
    "url": "/routine/%3F%5E#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Bool</b>",
    "url": "/routine/Bool#type/Strroutinemethod",
    "value": "In type/Str"
  },
  {
    "value": "In type/Baggy",
    "category": "Heading",
    "url": "/routine/Bool#type/Baggyroutinemethod",
    "info": ": section in <b>Bool</b>"
  },
  {
    "info": ": section in <b>uniname</b>",
    "value": "In type/Cool",
    "url": "/routine/uniname#type/Coolroutineroutine",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/routine/constant#language/variablesroutineprefix",
    "info": ": section in <b>constant</b>",
    "value": "In language/variables"
  },
  {
    "url": "/syntax/whitespace#language/glossarysyntaxwhitespace",
    "category": "Heading",
    "info": ": section in <b>whitespace</b>",
    "value": "In language/glossary"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/%7C#language/operatorsroutineprefix",
    "info": ": section in <b>|</b>"
  },
  {
    "category": "Heading",
    "url": "/routine/%7C#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>|</b>"
  },
  {
    "url": "/routine/NFKD#type/Strroutinemethod",
    "info": ": section in <b>NFKD</b>",
    "value": "In type/Str",
    "category": "Heading"
  },
  {
    "url": "/routine/Real#type/Coolroutinemethod",
    "category": "Heading",
    "value": "In type/Cool",
    "info": ": section in <b>Real</b>"
  },
  {
    "info": ": section in <b>Autothreading</b>",
    "value": "In language/glossary",
    "category": "Heading",
    "url": "/syntax/Autothreading#language/glossarysyntaxAutothreading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>single-quoted strings</b>",
    "url": "/syntax/single-quoted%20strings#language/101-basicssyntaxsingle-quoted strings",
    "value": "In language/101-basics"
  },
  {
    "url": "/routine/does#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>does</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/syntax/Larry%20Wall#language/glossarysyntaxLarry Wall",
    "value": "In language/glossary",
    "info": ": section in <b>Larry Wall</b>"
  },
  {
    "value": "In language/control",
    "url": "/syntax/repeat#language/controlsyntaxrepeat",
    "category": "Heading",
    "info": ": section in <b>repeat</b>"
  },
  {
    "value": "In type/Proc/Async",
    "url": "/routine/stdout#type/Proc/Asyncroutinemethod",
    "info": ": section in <b>stdout</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>indir</b>",
    "category": "Heading",
    "url": "/routine/indir#type/independent-routinesroutinesub",
    "value": "In type/independent-routines"
  },
  {
    "category": "Heading",
    "value": "In type/independent-routines",
    "info": ": section in <b>append</b>",
    "url": "/routine/append#type/independent-routinesroutinesub"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Repository</b>",
    "value": "In language/glossary",
    "url": "/syntax/Repository#language/glossarysyntaxRepository"
  },
  {
    "value": "In language/syntax",
    "category": "Heading",
    "url": "/syntax/identifiers#language/syntaxsyntaxidentifiers",
    "info": ": section in <b>identifiers</b>"
  },
  {
    "value": "In type/Cool",
    "info": ": section in <b>tanh</b>",
    "url": "/routine/tanh#type/Coolroutineroutine",
    "category": "Heading"
  },
  {
    "info": ": section in <b>+&</b>",
    "category": "Heading",
    "url": "/routine/%2B%26amp%3B#language/operatorsroutineinfix",
    "value": "In language/operators"
  },
  {
    "url": "/routine/sech#type/Coolroutineroutine",
    "category": "Heading",
    "info": ": section in <b>sech</b>",
    "value": "In type/Cool"
  },
  {
    "url": "/routine/chmod#type/independent-routinesroutinesub",
    "info": ": section in <b>chmod</b>",
    "value": "In type/independent-routines",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Order</b>",
    "category": "Heading",
    "url": "/routine/Order#type/Coolroutinemethod",
    "value": "In type/Cool"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class BagHash</b>",
    "value": "Creating BagHash objects",
    "url": "/type/BagHash#Creating_BagHash_objects"
  },
  {
    "value": "Updating BagHash Objects",
    "url": "/type/BagHash#Updating_BagHash_Objects",
    "category": "Heading",
    "info": ": section in <b>class BagHash</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class BagHash</b>",
    "value": "Operators",
    "url": "/type/BagHash#Operators"
  },
  {
    "category": "Heading",
    "value": "Note on reverse and ordering.",
    "url": "/type/BagHash#Note_on_reverse_and_ordering.",
    "info": ": section in <b>class BagHash</b>"
  },
  {
    "url": "/type/BagHash#method_add",
    "info": ": section in <b>class BagHash</b>",
    "value": "method add",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/type/BagHash#method_remove",
    "value": "method remove",
    "info": ": section in <b>class BagHash</b>"
  },
  {
    "info": ": section in <b>class BagHash</b>",
    "value": "See Also",
    "url": "/type/BagHash#See_Also",
    "category": "Heading"
  },
  {
    "info": ": section in <b>⊅</b>",
    "url": "/routine/%E2%8A%85#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "url": "/routine/uninames#type/Coolroutineroutine",
    "info": ": section in <b>uninames</b>",
    "category": "Heading",
    "value": "In type/Cool"
  },
  {
    "value": "In type/Attribute",
    "url": "/routine/package#type/Attributeroutinemethod",
    "category": "Heading",
    "info": ": section in <b>package</b>"
  },
  {
    "info": ": section in <b>substr</b>",
    "category": "Heading",
    "url": "/routine/substr#type/Strroutineroutine",
    "value": "In type/Str"
  },
  {
    "value": "In type/Cool",
    "info": ": section in <b>substr</b>",
    "url": "/routine/substr#type/Coolroutineroutine",
    "category": "Heading"
  },
  {
    "info": ": section in <b>blocks</b>",
    "category": "Heading",
    "url": "/syntax/blocks#language/controlsyntaxblocks",
    "value": "In language/control"
  },
  {
    "value": "In language/control",
    "info": ": section in <b>gather take</b>",
    "category": "Heading",
    "url": "/syntax/gather%20take#language/controlsyntaxgather take"
  },
  {
    "info": ": section in <b>Sigilless Variable</b>",
    "value": "In language/glossary",
    "url": "/syntax/Sigilless%20Variable#language/glossarysyntaxSigilless Variable",
    "category": "Heading"
  },
  {
    "info": ": section in <b>uniprops</b>",
    "category": "Heading",
    "value": "In type/Cool",
    "url": "/routine/uniprops#type/Coolroutinesub"
  },
  {
    "url": "/routine/pop#type/independent-routinesroutinesub",
    "info": ": section in <b>pop</b>",
    "value": "In type/independent-routines",
    "category": "Heading"
  },
  {
    "value": "In language/control",
    "info": ": section in <b>do</b>",
    "url": "/syntax/do#language/controlsyntaxdo",
    "category": "Heading"
  },
  {
    "url": "/routine/params#type/Signatureroutinemethod",
    "category": "Heading",
    "value": "In type/Signature",
    "info": ": section in <b>params</b>"
  },
  {
    "value": "In language/glossary",
    "url": "/syntax/UB#language/glossarysyntaxUB",
    "info": ": section in <b>UB</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In type/Dateish",
    "info": ": section in <b>yyyy-mm-dd</b>",
    "url": "/routine/yyyy-mm-dd#type/Dateishroutinemethod"
  },
  {
    "info": ": section in <b>squish</b>",
    "value": "In type/independent-routines",
    "category": "Heading",
    "url": "/routine/squish#type/independent-routinesroutineroutine"
  },
  {
    "url": "/routine/Int#type/Strroutinemethod",
    "info": ": section in <b>Int</b>",
    "value": "In type/Str",
    "category": "Heading"
  },
  {
    "value": "In type/Cool",
    "info": ": section in <b>Int</b>",
    "category": "Heading",
    "url": "/routine/Int#type/Coolroutinemethod"
  },
  {
    "category": "Heading",
    "url": "/routine/cosh#type/Coolroutineroutine",
    "value": "In type/Cool",
    "info": ": section in <b>cosh</b>"
  },
  {
    "info": ": section in <b>xx</b>",
    "url": "/routine/xx#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "url": "/syntax/Pair%20literals#language/syntaxsyntaxPair literals",
    "info": ": section in <b>Pair literals</b>",
    "category": "Heading",
    "value": "In language/syntax"
  },
  {
    "url": "/routine/%28%26gt%3B%29%2C%20infix%20%E2%8A%83#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>(>), infix ⊃</b>"
  },
  {
    "value": "In language/operators",
    "url": "/syntax/%3C%3C#language/operatorssyntax<<",
    "info": ": section in <b><<</b>",
    "category": "Heading"
  },
  {
    "url": "/syntax/-%3E#language/functionssyntax->",
    "value": "In language/functions",
    "category": "Heading",
    "info": ": section in <b>-></b>"
  },
  {
    "url": "/type/Str#Methods",
    "value": "Methods",
    "category": "Heading",
    "info": ": section in <b>class Str</b>"
  },
  {
    "value": "routine chop",
    "url": "/type/Str#routine_chop",
    "info": ": section in <b>class Str</b>",
    "category": "Heading"
  },
  {
    "value": "routine chomp",
    "url": "/type/Str#routine_chomp",
    "category": "Heading",
    "info": ": section in <b>class Str</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#method_contains",
    "value": "method contains"
  },
  {
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#routine_lc",
    "value": "routine lc",
    "category": "Heading"
  },
  {
    "value": "routine uc",
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "url": "/type/Str#routine_uc"
  },
  {
    "value": "routine fc",
    "url": "/type/Str#routine_fc",
    "info": ": section in <b>class Str</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Str</b>",
    "value": "routine tc",
    "category": "Heading",
    "url": "/type/Str#routine_tc"
  },
  {
    "value": "routine tclc",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#routine_tclc",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "routine wordcase",
    "url": "/type/Str#routine_wordcase",
    "info": ": section in <b>class Str</b>"
  },
  {
    "value": "method unival",
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "url": "/type/Str#method_unival"
  },
  {
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "value": "method univals",
    "url": "/type/Str#method_univals"
  },
  {
    "url": "/type/Str#routine_chars",
    "value": "routine chars",
    "info": ": section in <b>class Str</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "method encode",
    "url": "/type/Str#method_encode",
    "info": ": section in <b>class Str</b>"
  },
  {
    "url": "/type/Str#method_index",
    "value": "method index",
    "info": ": section in <b>class Str</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "value": "routine rindex",
    "url": "/type/Str#routine_rindex"
  },
  {
    "url": "/type/Str#method_indices",
    "value": "method indices",
    "info": ": section in <b>class Str</b>",
    "category": "Heading"
  },
  {
    "url": "/type/Str#method_match",
    "category": "Heading",
    "value": "method match",
    "info": ": section in <b>class Str</b>"
  },
  {
    "value": "method Numeric",
    "url": "/type/Str#method_Numeric",
    "category": "Heading",
    "info": ": section in <b>class Str</b>"
  },
  {
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "value": "method Num",
    "url": "/type/Str#method_Num"
  },
  {
    "value": "method Int",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#method_Int",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/type/Str#method_Rat",
    "info": ": section in <b>class Str</b>",
    "value": "method Rat"
  },
  {
    "url": "/type/Str#method_Bool",
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "value": "method Bool"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Str</b>",
    "value": "routine parse-base",
    "url": "/type/Str#routine_parse-base"
  },
  {
    "value": "routine parse-names",
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "url": "/type/Str#routine_parse-names"
  },
  {
    "value": "routine uniparse",
    "url": "/type/Str#routine_uniparse",
    "category": "Heading",
    "info": ": section in <b>class Str</b>"
  },
  {
    "url": "/type/Str#method_samecase",
    "value": "method samecase",
    "category": "Heading",
    "info": ": section in <b>class Str</b>"
  },
  {
    "category": "Heading",
    "value": "routine split",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#routine_split"
  },
  {
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "url": "/type/Str#routine_comb",
    "value": "routine comb"
  },
  {
    "value": "routine lines",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#routine_lines",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/type/Str#routine_words",
    "value": "routine words",
    "info": ": section in <b>class Str</b>"
  },
  {
    "value": "routine flip",
    "url": "/type/Str#routine_flip",
    "info": ": section in <b>class Str</b>",
    "category": "Heading"
  },
  {
    "url": "/type/Str#method_starts-with",
    "value": "method starts-with",
    "info": ": section in <b>class Str</b>",
    "category": "Heading"
  },
  {
    "value": "method ends-with",
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "url": "/type/Str#method_ends-with"
  },
  {
    "value": "method subst",
    "url": "/type/Str#method_subst",
    "category": "Heading",
    "info": ": section in <b>class Str</b>"
  },
  {
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#Literal_replacement_substitution",
    "category": "Heading",
    "value": "Literal replacement substitution"
  },
  {
    "info": ": section in <b>class Str</b>",
    "value": "Callable",
    "url": "/type/Str#Callable",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#Adverbs",
    "value": "Adverbs"
  },
  {
    "category": "Heading",
    "url": "/type/Str#More_Examples",
    "value": "More Examples",
    "info": ": section in <b>class Str</b>"
  },
  {
    "url": "/type/Str#method_subst-mutate",
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "value": "method subst-mutate"
  },
  {
    "category": "Heading",
    "value": "routine substr",
    "url": "/type/Str#routine_substr",
    "info": ": section in <b>class Str</b>"
  },
  {
    "url": "/type/Str#method_substr-eq",
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "value": "method substr-eq"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Str</b>",
    "value": "method substr-rw",
    "url": "/type/Str#method_substr-rw"
  },
  {
    "category": "Heading",
    "url": "/type/Str#routine_samemark",
    "info": ": section in <b>class Str</b>",
    "value": "routine samemark"
  },
  {
    "category": "Heading",
    "value": "method succ",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#method_succ"
  },
  {
    "value": "method pred",
    "category": "Heading",
    "url": "/type/Str#method_pred",
    "info": ": section in <b>class Str</b>"
  },
  {
    "category": "Heading",
    "value": "routine ord",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#routine_ord"
  },
  {
    "url": "/type/Str#method_ords",
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "value": "method ords"
  },
  {
    "value": "method trans",
    "category": "Heading",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#method_trans"
  },
  {
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "value": "method indent",
    "url": "/type/Str#method_indent"
  },
  {
    "category": "Heading",
    "value": "method trim",
    "url": "/type/Str#method_trim",
    "info": ": section in <b>class Str</b>"
  },
  {
    "info": ": section in <b>class Str</b>",
    "value": "method trim-trailing",
    "url": "/type/Str#method_trim-trailing",
    "category": "Heading"
  },
  {
    "value": "method trim-leading",
    "category": "Heading",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#method_trim-leading"
  },
  {
    "url": "/type/Str#method_NFC",
    "category": "Heading",
    "info": ": section in <b>class Str</b>",
    "value": "method NFC"
  },
  {
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "url": "/type/Str#method_NFD",
    "value": "method NFD"
  },
  {
    "category": "Heading",
    "value": "method NFKC",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#method_NFKC"
  },
  {
    "url": "/type/Str#method_NFKD",
    "value": "method NFKD",
    "info": ": section in <b>class Str</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#method_ACCEPTS",
    "value": "method ACCEPTS"
  },
  {
    "url": "/type/Str#method_Capture",
    "value": "method Capture",
    "category": "Heading",
    "info": ": section in <b>class Str</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Str</b>",
    "value": "routine val",
    "url": "/type/Str#routine_val"
  },
  {
    "url": "/type/Str#method_Version",
    "category": "Heading",
    "value": "method Version",
    "info": ": section in <b>class Str</b>"
  },
  {
    "info": ": section in <b>class Str</b>",
    "url": "/type/Str#method_Date",
    "value": "method Date",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Str</b>",
    "category": "Heading",
    "url": "/type/Str#method_DateTime",
    "value": "method DateTime"
  },
  {
    "info": ": section in <b>abs</b>",
    "value": "In type/Cool",
    "category": "Heading",
    "url": "/routine/abs#type/Coolroutineroutine"
  },
  {
    "info": ": section in <b>arity</b>",
    "category": "Heading",
    "url": "/routine/arity#type/Signatureroutinemethod",
    "value": "In type/Signature"
  },
  {
    "category": "Heading",
    "value": "In type/Str",
    "info": ": section in <b>starts-with</b>",
    "url": "/routine/starts-with#type/Strroutinemethod"
  },
  {
    "value": "In type/Str",
    "info": ": section in <b>chop</b>",
    "category": "Heading",
    "url": "/routine/chop#type/Strroutineroutine"
  },
  {
    "value": "In type/Cool",
    "category": "Heading",
    "info": ": section in <b>chop</b>",
    "url": "/routine/chop#type/Coolroutineroutine"
  },
  {
    "info": ": section in <b><[ ]></b>",
    "url": "/syntax/%3C%5B%20%5D%3E#language/regexessyntax<[ ]>",
    "value": "In language/regexes",
    "category": "Heading"
  },
  {
    "value": "In language/objects",
    "category": "Heading",
    "info": ": section in <b>role</b>",
    "url": "/syntax/role#language/objectssyntaxrole"
  },
  {
    "info": ": section in <b>role</b>",
    "value": "In language/glossary",
    "url": "/syntax/role#language/glossarysyntaxrole",
    "category": "Heading"
  },
  {
    "info": ": section in <b>=></b>",
    "url": "/routine/%3D%26gt%3B#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "info": ": section in <b>nativesizeof</b>",
    "url": "/routine/nativesizeof#language/nativecallroutinesub",
    "value": "In language/nativecall",
    "category": "Heading"
  },
  {
    "url": "/type/CallFrame#Methods",
    "category": "Heading",
    "info": ": section in <b>class CallFrame</b>",
    "value": "Methods"
  },
  {
    "value": "method code",
    "url": "/type/CallFrame#method_code",
    "info": ": section in <b>class CallFrame</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/type/CallFrame#method_file",
    "info": ": section in <b>class CallFrame</b>",
    "value": "method file"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class CallFrame</b>",
    "value": "method line",
    "url": "/type/CallFrame#method_line"
  },
  {
    "value": "method annotations",
    "category": "Heading",
    "info": ": section in <b>class CallFrame</b>",
    "url": "/type/CallFrame#method_annotations"
  },
  {
    "info": ": section in <b>class CallFrame</b>",
    "url": "/type/CallFrame#method_my",
    "value": "method my",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class CallFrame</b>",
    "category": "Heading",
    "value": "Routines",
    "url": "/type/CallFrame#Routines"
  },
  {
    "info": ": section in <b>class CallFrame</b>",
    "value": "sub callframe",
    "category": "Heading",
    "url": "/type/CallFrame#sub_callframe"
  },
  {
    "value": "In type/independent-routines",
    "category": "Heading",
    "url": "/routine/EVALFILE#type/independent-routinesroutinesub",
    "info": ": section in <b>EVALFILE</b>"
  },
  {
    "url": "/syntax/is%20built%20%28Attribute%29#type/Attributesyntaxis built (Attribute)",
    "category": "Heading",
    "info": ": section in <b>is built (Attribute)</b>",
    "value": "In type/Attribute"
  },
  {
    "value": "In language/glossary",
    "info": ": section in <b>Thunk</b>",
    "url": "/syntax/Thunk#language/glossarysyntaxThunk",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/routine/Supply#type/Proc/Asyncroutinemethod",
    "value": "In type/Proc/Async",
    "info": ": section in <b>Supply</b>"
  },
  {
    "category": "Heading",
    "value": "In type/Baggy",
    "info": ": section in <b>categorize-list</b>",
    "url": "/routine/categorize-list#type/Baggyroutinemethod"
  },
  {
    "value": "In type/Str",
    "category": "Heading",
    "info": ": section in <b>uc</b>",
    "url": "/routine/uc#type/Strroutineroutine"
  },
  {
    "info": ": section in <b>uc</b>",
    "value": "In type/Cool",
    "category": "Heading",
    "url": "/routine/uc#type/Coolroutineroutine"
  },
  {
    "value": "In language/regexes",
    "category": "Heading",
    "info": ": section in <b>after</b>",
    "url": "/syntax/after#language/regexessyntaxafter"
  },
  {
    "url": "/routine/%2B#language/operatorsroutineprefix",
    "info": ": section in <b>+</b>",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/%2B#language/operatorsroutineinfix",
    "info": ": section in <b>+</b>"
  },
  {
    "value": "In language/classtut",
    "info": ": section in <b>inheritance</b>",
    "url": "/syntax/inheritance#language/classtutsyntaxinheritance",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/routine/%5Eff#language/operatorsroutineinfix",
    "info": ": section in <b>^ff</b>",
    "value": "In language/operators"
  },
  {
    "value": "In type/Dateish",
    "url": "/routine/day-of-month#type/Dateishroutinemethod",
    "info": ": section in <b>day-of-month</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>= (list assignment)</b>",
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/%3D%20%28list%20assignment%29#language/operatorsroutineinfix"
  },
  {
    "url": "/routine/%2C#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>,</b>"
  },
  {
    "info": ": section in <b>MAIN</b>",
    "category": "Heading",
    "url": "/routine/MAIN#language/functionsroutinesub",
    "value": "In language/functions"
  },
  {
    "category": "Heading",
    "info": ": section in <b>IO</b>",
    "url": "/routine/IO#type/Coolroutinemethod",
    "value": "In type/Cool"
  },
  {
    "info": ": section in <b>IO</b>",
    "category": "Heading",
    "url": "/routine/IO#type/Dateishroutinemethod",
    "value": "In type/Dateish"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>eqv</b>",
    "category": "Heading",
    "url": "/routine/eqv#language/operatorsroutineinfix"
  },
  {
    "url": "/syntax/Camelia#language/glossarysyntaxCamelia",
    "category": "Heading",
    "value": "In language/glossary",
    "info": ": section in <b>Camelia</b>"
  },
  {
    "value": "In type/Cool",
    "url": "/routine/sec#type/Coolroutineroutine",
    "info": ": section in <b>sec</b>",
    "category": "Heading"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>x</b>",
    "url": "/routine/x#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "url": "/syntax/variable%20interpolation%20%28Basics%29#language/101-basicssyntaxvariable interpolation (Basics)",
    "category": "Heading",
    "value": "In language/101-basics",
    "info": ": section in <b>variable interpolation (Basics)</b>"
  },
  {
    "info": ": section in <b>chomp</b>",
    "category": "Heading",
    "url": "/routine/chomp#type/Strroutineroutine",
    "value": "In type/Str"
  },
  {
    "value": "In type/Cool",
    "info": ": section in <b>chomp</b>",
    "url": "/routine/chomp#type/Coolroutineroutine",
    "category": "Heading"
  },
  {
    "value": "In language/regexes",
    "category": "Heading",
    "url": "/syntax/%5Cv#language/regexessyntax%5Cv",
    "info": ": section in <b>\\v</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Adverb</b>",
    "value": "In language/glossary",
    "url": "/syntax/Adverb#language/glossarysyntaxAdverb"
  },
  {
    "info": ": section in <b>**</b>",
    "value": "In language/regexes",
    "url": "/syntax/%2A%2A#language/regexessyntax**",
    "category": "Heading"
  },
  {
    "url": "/syntax/%2B#language/regexessyntax+",
    "value": "In language/regexes",
    "info": ": section in <b>+</b>",
    "category": "Heading"
  },
  {
    "value": "In language/regexes",
    "url": "/syntax/%3Aexhaustive#language/regexessyntax:exhaustive",
    "category": "Heading",
    "info": ": section in <b>:exhaustive</b>"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>max</b>",
    "url": "/routine/max#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In type/Dateish",
    "url": "/routine/days-in-month#type/Dateishroutinemethod",
    "info": ": section in <b>days-in-month</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>pred</b>",
    "url": "/routine/pred#type/Strroutinemethod",
    "value": "In type/Str"
  },
  {
    "info": ": section in <b>--</b>",
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/--#language/operatorsroutineprefix"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>--</b>",
    "url": "/routine/--#language/operatorsroutinepostfix"
  },
  {
    "url": "/syntax/block%20%28Basics%29#language/101-basicssyntaxblock (Basics)",
    "info": ": section in <b>block (Basics)</b>",
    "category": "Heading",
    "value": "In language/101-basics"
  },
  {
    "category": "Heading",
    "value": "In language/regexes",
    "url": "/syntax/%3Acontinue#language/regexessyntax:continue",
    "info": ": section in <b>:continue</b>"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>=:=</b>",
    "url": "/routine/%3D%3A%3D#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "value": "In type/Str",
    "category": "Heading",
    "url": "/routine/succ#type/Strroutinemethod",
    "info": ": section in <b>succ</b>"
  },
  {
    "category": "Heading",
    "url": "/routine/wordcase#type/Strroutineroutine",
    "value": "In type/Str",
    "info": ": section in <b>wordcase</b>"
  },
  {
    "info": ": section in <b>wordcase</b>",
    "category": "Heading",
    "url": "/routine/wordcase#type/Coolroutineroutine",
    "value": "In type/Cool"
  },
  {
    "info": ": section in <b>Creating grammars</b>",
    "category": "Heading",
    "value": "In language/grammars",
    "url": "/syntax/Creating%20grammars#language/grammarssyntaxCreating grammars"
  },
  {
    "category": "Heading",
    "url": "/routine/total#type/Baggyroutinemethod",
    "value": "In type/Baggy",
    "info": ": section in <b>total</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Perl</b>",
    "url": "/syntax/Perl#language/glossarysyntaxPerl",
    "value": "In language/glossary"
  },
  {
    "url": "/syntax/%26#language/regexessyntax&",
    "value": "In language/regexes",
    "info": ": section in <b>&</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>is rw (Attribute)</b>",
    "value": "In type/Attribute",
    "category": "Heading",
    "url": "/syntax/is%20rw%20%28Attribute%29#type/Attributesyntaxis rw (Attribute)"
  },
  {
    "category": "Heading",
    "info": ": section in <b>regex</b>",
    "value": "In language/regexes",
    "url": "/syntax/regex#language/regexessyntaxregex"
  },
  {
    "info": ": section in <b>twine</b>",
    "category": "Heading",
    "url": "/syntax/twine#language/glossarysyntaxtwine",
    "value": "In language/glossary"
  },
  {
    "info": ": section in <b>lc</b>",
    "category": "Heading",
    "url": "/routine/lc#type/Strroutineroutine",
    "value": "In type/Str"
  },
  {
    "value": "In type/Cool",
    "info": ": section in <b>lc</b>",
    "url": "/routine/lc#type/Coolroutineroutine",
    "category": "Heading"
  },
  {
    "url": "/routine/path#type/Proc/Asyncroutinemethod",
    "value": "In type/Proc/Async",
    "category": "Heading",
    "info": ": section in <b>path</b>"
  },
  {
    "url": "/routine/path#type/Coolroutinemethod",
    "value": "In type/Cool",
    "category": "Heading",
    "info": ": section in <b>path</b>"
  },
  {
    "value": "In language/regexes",
    "category": "Heading",
    "info": ": section in <b>Regex Interpolation</b>",
    "url": "/syntax/Regex%20Interpolation#language/regexessyntaxRegex Interpolation"
  },
  {
    "category": "Heading",
    "value": "In language/regexes",
    "url": "/syntax/%5E#language/regexessyntax^",
    "info": ": section in <b>^</b>"
  },
  {
    "value": "In language/operators",
    "url": "/syntax/Z%20%28zip%20metaoperator%29#language/operatorssyntaxZ (zip metaoperator)",
    "category": "Heading",
    "info": ": section in <b>Z (zip metaoperator)</b>"
  },
  {
    "category": "Heading",
    "url": "/routine/count#type/Signatureroutinemethod",
    "value": "In type/Signature",
    "info": ": section in <b>count</b>"
  },
  {
    "info": ": section in <b>Perl 6</b>",
    "url": "/syntax/Perl%C2%A06#language/glossarysyntaxPerl 6",
    "category": "Heading",
    "value": "In language/glossary"
  },
  {
    "value": "In type/Parameter",
    "category": "Heading",
    "url": "/routine/twigil#type/Parameterroutinemethod",
    "info": ": section in <b>twigil</b>"
  },
  {
    "info": ": section in <b>===, infix ⩶</b>",
    "value": "In language/operators",
    "url": "/routine/%3D%3D%3D%2C%20infix%20%E2%A9%B6#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "value": "In type/Attribute",
    "info": ": section in <b>has_accessor</b>",
    "url": "/routine/has_accessor#type/Attributeroutinemethod",
    "category": "Heading"
  },
  {
    "info": ": section in <b>:global</b>",
    "category": "Heading",
    "url": "/syntax/%3Aglobal#language/regexessyntax:global",
    "value": "In language/regexes"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "value": "routine EVAL",
    "url": "/type/independent-routines#routine_EVAL",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#sub_EVALFILE",
    "value": "sub EVALFILE",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "value": "sub repl",
    "url": "/type/independent-routines#sub_repl",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "category": "Heading",
    "value": "sub get",
    "url": "/type/independent-routines#sub_get"
  },
  {
    "category": "Heading",
    "url": "/type/independent-routines#sub_getc",
    "value": "sub getc",
    "info": ": section in <b>Independent routines</b>"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "value": "sub mkdir",
    "url": "/type/independent-routines#sub_mkdir",
    "category": "Heading"
  },
  {
    "value": "sub chdir",
    "info": ": section in <b>Independent routines</b>",
    "category": "Heading",
    "url": "/type/independent-routines#sub_chdir"
  },
  {
    "url": "/type/independent-routines#sub_&*chdir",
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "value": "sub &*chdir"
  },
  {
    "value": "sub chmod",
    "info": ": section in <b>Independent routines</b>",
    "category": "Heading",
    "url": "/type/independent-routines#sub_chmod"
  },
  {
    "category": "Heading",
    "url": "/type/independent-routines#sub_indir",
    "value": "sub indir",
    "info": ": section in <b>Independent routines</b>"
  },
  {
    "url": "/type/independent-routines#sub_print",
    "info": ": section in <b>Independent routines</b>",
    "value": "sub print",
    "category": "Heading"
  },
  {
    "value": "sub put",
    "info": ": section in <b>Independent routines</b>",
    "category": "Heading",
    "url": "/type/independent-routines#sub_put"
  },
  {
    "category": "Heading",
    "value": "sub say",
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#sub_say"
  },
  {
    "category": "Heading",
    "url": "/type/independent-routines#routine_note",
    "info": ": section in <b>Independent routines</b>",
    "value": "routine note"
  },
  {
    "url": "/type/independent-routines#sub_prompt",
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "value": "sub prompt"
  },
  {
    "value": "sub open",
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#sub_open",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#sub_slurp",
    "value": "sub slurp"
  },
  {
    "url": "/type/independent-routines#sub_spurt",
    "value": "sub spurt",
    "info": ": section in <b>Independent routines</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#Options",
    "category": "Heading",
    "value": "Options"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#Examples",
    "value": "Examples"
  },
  {
    "url": "/type/independent-routines#sub_run",
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "value": "sub run"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "category": "Heading",
    "value": "sub shell",
    "url": "/type/independent-routines#sub_shell"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#routine_unpolar",
    "category": "Heading",
    "value": "routine unpolar"
  },
  {
    "url": "/type/independent-routines#routine_printf",
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "value": "routine printf"
  },
  {
    "url": "/type/independent-routines#routine_sprintf",
    "category": "Heading",
    "value": "routine sprintf",
    "info": ": section in <b>Independent routines</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#Directives",
    "value": "Directives"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#Modifiers",
    "value": "Modifiers",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "NYI Format parameter index using the '$' symbol",
    "url": "/type/independent-routines#NYI_Format_parameter_index_using_the_'$'_symbol",
    "info": ": section in <b>Independent routines</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#Without_index:",
    "value": "Without index:"
  },
  {
    "value": "NYI With index:",
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#NYI_With_index:",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#Flags",
    "value": "Flags"
  },
  {
    "url": "/type/independent-routines#Vector_flag_'v'",
    "value": "Vector flag 'v'",
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>"
  },
  {
    "value": "Width (minimum)",
    "category": "Heading",
    "url": "/type/independent-routines#Width_(minimum)",
    "info": ": section in <b>Independent routines</b>"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#Precision,_or_maximum_width",
    "category": "Heading",
    "value": "Precision, or maximum width"
  },
  {
    "url": "/type/independent-routines#Size",
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "value": "Size"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "value": "Order of arguments",
    "url": "/type/independent-routines#Order_of_arguments"
  },
  {
    "value": "sub flat",
    "category": "Heading",
    "url": "/type/independent-routines#sub_flat",
    "info": ": section in <b>Independent routines</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#routine_unique",
    "value": "routine unique"
  },
  {
    "category": "Heading",
    "value": "routine repeated",
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#routine_repeated"
  },
  {
    "category": "Heading",
    "url": "/type/independent-routines#routine_squish",
    "info": ": section in <b>Independent routines</b>",
    "value": "routine squish"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "value": "sub emit",
    "url": "/type/independent-routines#sub_emit",
    "category": "Heading"
  },
  {
    "url": "/type/independent-routines#sub_undefine",
    "value": "sub undefine",
    "info": ": section in <b>Independent routines</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "value": "Array manipulation",
    "category": "Heading",
    "url": "/type/independent-routines#Array_manipulation"
  },
  {
    "category": "Heading",
    "value": "sub pop",
    "url": "/type/independent-routines#sub_pop",
    "info": ": section in <b>Independent routines</b>"
  },
  {
    "info": ": section in <b>Independent routines</b>",
    "category": "Heading",
    "url": "/type/independent-routines#sub_shift",
    "value": "sub shift"
  },
  {
    "url": "/type/independent-routines#sub_push",
    "value": "sub push",
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "value": "sub append",
    "url": "/type/independent-routines#sub_append"
  },
  {
    "value": "Control routines",
    "info": ": section in <b>Independent routines</b>",
    "category": "Heading",
    "url": "/type/independent-routines#Control_routines"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "url": "/type/independent-routines#sub_exit",
    "value": "sub exit"
  },
  {
    "category": "Heading",
    "url": "/type/independent-routines#sub_done",
    "info": ": section in <b>Independent routines</b>",
    "value": "sub done"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Independent routines</b>",
    "value": "sub lastcall",
    "url": "/type/independent-routines#sub_lastcall"
  },
  {
    "info": ": section in <b>slurpy</b>",
    "value": "In type/Parameter",
    "url": "/routine/slurpy#type/Parameterroutinemethod",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In type/Int",
    "info": ": section in <b>polymod</b>",
    "url": "/routine/polymod#type/Introutinemethod"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>.=</b>",
    "url": "/routine/.%3D#language/operatorsroutineinfix"
  },
  {
    "info": ": section in <b>sprintf</b>",
    "category": "Heading",
    "url": "/routine/sprintf#type/Coolroutinemethod",
    "value": "In type/Cool"
  },
  {
    "value": "In type/independent-routines",
    "info": ": section in <b>sprintf</b>",
    "url": "/routine/sprintf#type/independent-routinesroutineroutine",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Invocant</b>",
    "url": "/syntax/Invocant#language/glossarysyntaxInvocant",
    "value": "In language/glossary"
  },
  {
    "url": "/syntax/Spesh#language/glossarysyntaxSpesh",
    "category": "Heading",
    "value": "In language/glossary",
    "info": ": section in <b>Spesh</b>"
  },
  {
    "info": ": section in <b>named_names</b>",
    "category": "Heading",
    "url": "/routine/named_names#type/Parameterroutinemethod",
    "value": "In type/Parameter"
  },
  {
    "url": "/routine/encode#type/Strroutinemethod",
    "info": ": section in <b>encode</b>",
    "value": "In type/Str",
    "category": "Heading"
  },
  {
    "info": ": section in <b>iffy</b>",
    "category": "Heading",
    "url": "/syntax/iffy#language/glossarysyntaxiffy",
    "value": "In language/glossary"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/%25#language/operatorsroutineinfix",
    "info": ": section in <b>%</b>"
  },
  {
    "url": "/programs/02-reading-docs#INTRODUCTION",
    "info": ": section in <b>Reading the docs</b>",
    "value": "INTRODUCTION",
    "category": "Heading"
  },
  {
    "value": "SYNOPSIS",
    "info": ": section in <b>Reading the docs</b>",
    "url": "/programs/02-reading-docs#SYNOPSIS",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/programs/02-reading-docs#DESCRIPTION",
    "value": "DESCRIPTION",
    "info": ": section in <b>Reading the docs</b>"
  },
  {
    "value": "LIMITATIONS",
    "category": "Heading",
    "url": "/programs/02-reading-docs#LIMITATIONS",
    "info": ": section in <b>Reading the docs</b>"
  },
  {
    "info": ": section in <b>return-rw</b>",
    "value": "In language/control",
    "url": "/syntax/return-rw#language/controlsyntaxreturn-rw",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Value type</b>",
    "category": "Heading",
    "url": "/syntax/Value%20type#language/glossarysyntaxValue type",
    "value": "In language/glossary"
  },
  {
    "info": ": section in <b>acosech</b>",
    "value": "In type/Cool",
    "category": "Heading",
    "url": "/routine/acosech#type/Coolroutineroutine"
  },
  {
    "value": "In language/control",
    "category": "Heading",
    "url": "/syntax/with#language/controlsyntaxwith",
    "info": ": section in <b>with</b>"
  },
  {
    "value": "In type/Cool",
    "category": "Heading",
    "info": ": section in <b>chr</b>",
    "url": "/routine/chr#type/Coolroutineroutine"
  },
  {
    "value": "In type/Int",
    "info": ": section in <b>chr</b>",
    "url": "/routine/chr#type/Introutineroutine",
    "category": "Heading"
  },
  {
    "url": "/syntax/%3F#language/regexessyntax%3F",
    "category": "Heading",
    "info": ": section in <b>?</b>",
    "value": "In language/regexes"
  },
  {
    "url": "/syntax/%3Asamecase#language/regexessyntax:samecase",
    "value": "In language/regexes",
    "info": ": section in <b>:samecase</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Niecza</b>",
    "url": "/syntax/Niecza#language/glossarysyntaxNiecza",
    "value": "In language/glossary",
    "category": "Heading"
  },
  {
    "value": "In type/Proc/Async",
    "category": "Heading",
    "info": ": section in <b>start</b>",
    "url": "/routine/start#type/Proc/Asyncroutinemethod"
  },
  {
    "category": "Heading",
    "info": ": section in <b>or</b>",
    "value": "In language/operators",
    "url": "/routine/or#language/operatorsroutineinfix"
  },
  {
    "info": ": section in <b>explicitly-manage</b>",
    "category": "Heading",
    "value": "In language/nativecall",
    "url": "/routine/explicitly-manage#language/nativecallroutinesub"
  },
  {
    "info": ": section in <b>Rat</b>",
    "category": "Heading",
    "url": "/routine/Rat#type/Strroutinemethod",
    "value": "In type/Str"
  },
  {
    "info": ": section in <b>Rat</b>",
    "category": "Heading",
    "value": "In type/Cool",
    "url": "/routine/Rat#type/Coolroutinemethod"
  },
  {
    "info": ": section in <b>ge</b>",
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/ge#language/operatorsroutineinfix"
  },
  {
    "info": ": section in <b>default</b>",
    "value": "In type/Parameter",
    "url": "/routine/default#type/Parameterroutinemethod",
    "category": "Heading"
  },
  {
    "value": "In type/Baggy",
    "url": "/routine/default#type/Baggyroutinemethod",
    "category": "Heading",
    "info": ": section in <b>default</b>"
  },
  {
    "value": "In language/functions",
    "info": ": section in <b>callwith</b>",
    "url": "/syntax/callwith#language/functionssyntaxcallwith",
    "category": "Heading"
  },
  {
    "value": "In type/Dateish",
    "category": "Heading",
    "url": "/routine/later#type/Dateishroutinemethod",
    "info": ": section in <b>later</b>"
  },
  {
    "value": "In language/variables",
    "url": "/syntax/anon#language/variablessyntaxdeclarator",
    "info": ": section in <b>anon</b>",
    "category": "Heading"
  },
  {
    "value": "In type/independent-routines",
    "info": ": section in <b>done</b>",
    "url": "/routine/done#type/independent-routinesroutinesub",
    "category": "Heading"
  },
  {
    "info": ": section in <b>...</b>",
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/...#language/operatorsroutineinfix"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>...</b>",
    "url": "/routine/...#language/operatorsroutinelistop"
  },
  {
    "url": "/syntax/fail#language/controlsyntaxfail",
    "value": "In language/control",
    "info": ": section in <b>fail</b>",
    "category": "Heading"
  },
  {
    "value": "In type/Parameter",
    "category": "Heading",
    "info": ": section in <b>suffix</b>",
    "url": "/routine/suffix#type/Parameterroutinemethod"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>.</b>",
    "category": "Heading",
    "url": "/routine/.#language/operatorsroutineinfix"
  },
  {
    "url": "/syntax/Operator#language/glossarysyntaxOperator",
    "info": ": section in <b>Operator</b>",
    "category": "Heading",
    "value": "In language/glossary"
  },
  {
    "value": "In type/Cool",
    "info": ": section in <b>cotanh</b>",
    "category": "Heading",
    "url": "/routine/cotanh#type/Coolroutineroutine"
  },
  {
    "url": "/syntax/MoarVM#language/glossarysyntaxMoarVM",
    "value": "In language/glossary",
    "info": ": section in <b>MoarVM</b>",
    "category": "Heading"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>∉</b>",
    "url": "/routine/%E2%88%89#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "value": "In type/Parameter",
    "url": "/routine/sub_signature#type/Parameterroutinemethod",
    "info": ": section in <b>sub_signature</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>PERL</b>",
    "value": "In language/glossary",
    "category": "Heading",
    "url": "/syntax/PERL#language/glossarysyntaxPERL"
  },
  {
    "category": "Heading",
    "url": "/syntax/recursive#language/regexessyntaxrecursive",
    "value": "In language/regexes",
    "info": ": section in <b>recursive</b>"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "url": "/language/rakudoc#SYNOPSIS",
    "value": "SYNOPSIS"
  },
  {
    "category": "Heading",
    "value": "Case 1: You are writing internal documentation to aid software design",
    "url": "/language/rakudoc#Case_1:_You_are_writing_internal_documentation_to_aid_software_design",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "value": "Case2: You are writing external documentation to accompany some software",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "url": "/language/rakudoc#Case2:_You_are_writing_external_documentation_to_accompany_some_software"
  },
  {
    "value": "Introduction",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "url": "/language/rakudoc#Introduction"
  },
  {
    "value": "Two use cases for RakuDoc",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Two_use_cases_for_RakuDoc"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "url": "/language/rakudoc#Components",
    "value": "Components"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Directive_syntax",
    "category": "Heading",
    "value": "Directive syntax"
  },
  {
    "url": "/language/rakudoc#Block_syntax",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "value": "Block syntax"
  },
  {
    "value": "Markup instruction syntax",
    "url": "/language/rakudoc#Markup_instruction_syntax",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading"
  },
  {
    "value": "Metadata syntax",
    "url": "/language/rakudoc#Metadata_syntax",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading"
  },
  {
    "url": "/language/rakudoc#Directives",
    "category": "Heading",
    "value": "Directives",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Aliases",
    "value": "Aliases",
    "category": "Heading"
  },
  {
    "value": "Block specifiers",
    "category": "Heading",
    "url": "/language/rakudoc#Block_specifiers",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Config",
    "category": "Heading",
    "value": "Config"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "url": "/language/rakudoc#Document_termination",
    "value": "Document termination"
  },
  {
    "category": "Heading",
    "url": "/language/rakudoc#Table_constructors",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Table constructors"
  },
  {
    "category": "Heading",
    "value": "Code-oriented RakuDoc",
    "url": "/language/rakudoc#Code-oriented_RakuDoc",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "value": "Declarator blocks",
    "url": "/language/rakudoc#Declarator_blocks",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading"
  },
  {
    "url": "/language/rakudoc#Data_blocks",
    "category": "Heading",
    "value": "Data blocks",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "category": "Heading",
    "url": "/language/rakudoc#Text-oriented_RakuDoc",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Text-oriented RakuDoc"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Headings",
    "value": "Headings",
    "category": "Heading"
  },
  {
    "value": "Numbered headings",
    "url": "/language/rakudoc#Numbered_headings",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading"
  },
  {
    "url": "/language/rakudoc#Block_scope",
    "value": "Block scope",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "url": "/language/rakudoc#Sections",
    "value": "Sections",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "category": "Heading",
    "value": "Document scope",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Document_scope"
  },
  {
    "value": "Ordinary paragraphs",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Ordinary_paragraphs",
    "category": "Heading"
  },
  {
    "url": "/language/rakudoc#Nesting_or_indenting_a_block",
    "value": "Nesting or indenting a block",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Verbatim blocks",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Verbatim_blocks"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "value": "Code blocks",
    "url": "/language/rakudoc#Code_blocks"
  },
  {
    "value": "Preprocessing and postprocessing of code",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Preprocessing_and_postprocessing_of_code",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/rakudoc#I/O_blocks",
    "value": "I/O blocks",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "url": "/language/rakudoc#Markup_within_verbatim_blocks",
    "value": "Markup within verbatim blocks",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Lists",
    "url": "/language/rakudoc#Lists",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "url": "/language/rakudoc#Unordered_lists",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Unordered lists"
  },
  {
    "url": "/language/rakudoc#Multi-level_lists",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "value": "Multi-level lists"
  },
  {
    "category": "Heading",
    "url": "/language/rakudoc#Multi-paragraph_lists",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Multi-paragraph lists"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "value": "Ordered lists",
    "category": "Heading",
    "url": "/language/rakudoc#Ordered_lists"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Definition_lists",
    "category": "Heading",
    "value": "Definition lists"
  },
  {
    "url": "/language/rakudoc#Numbered_definitions",
    "value": "Numbered definitions",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "url": "/language/rakudoc#Tables",
    "value": "Tables",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading"
  },
  {
    "value": "Visual description of simple tables",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Visual_description_of_simple_tables"
  },
  {
    "value": "Valid tables",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Valid_tables"
  },
  {
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Invalid tables",
    "url": "/language/rakudoc#Invalid_tables"
  },
  {
    "category": "Heading",
    "url": "/language/rakudoc#Unexpected_tables",
    "value": "Unexpected tables",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "value": "Procedural description of tables",
    "category": "Heading",
    "url": "/language/rakudoc#Procedural_description_of_tables",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#RakuDoc_comments",
    "category": "Heading",
    "value": "RakuDoc comments"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "value": "Semantic blocks",
    "category": "Heading",
    "url": "/language/rakudoc#Semantic_blocks"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#User-defined_blocks",
    "value": "User-defined blocks",
    "category": "Heading"
  },
  {
    "url": "/language/rakudoc#Naming_rules",
    "value": "Naming rules",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading"
  },
  {
    "value": "Implied code and indentation",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Implied_code_and_indentation",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Metadata",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Metadata"
  },
  {
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Anchors",
    "url": "/language/rakudoc#Anchors"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "value": "Table of Contents and Index",
    "url": "/language/rakudoc#Table_of_Contents_and_Index",
    "category": "Heading"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "value": "Developer or delta notes",
    "url": "/language/rakudoc#Developer_or_delta_notes"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Markup_instructions",
    "value": "Markup instructions",
    "category": "Heading"
  },
  {
    "value": "Formatting codes",
    "url": "/language/rakudoc#Formatting_codes",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Instructions with side effects",
    "url": "/language/rakudoc#Instructions_with_side_effects"
  },
  {
    "url": "/language/rakudoc#Links",
    "value": "Links",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "url": "/language/rakudoc#Examples",
    "category": "Heading",
    "value": "Examples",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "url": "/language/rakudoc#Placement_links",
    "value": "Placement links"
  },
  {
    "value": "Alias placement",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Alias_placement"
  },
  {
    "url": "/language/rakudoc#Graphic_placement",
    "value": "Graphic placement",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading"
  },
  {
    "url": "/language/rakudoc#Inline_definitions",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Inline definitions"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Space-preserving_text",
    "category": "Heading",
    "value": "Space-preserving text"
  },
  {
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Comments",
    "url": "/language/rakudoc#Comments"
  },
  {
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Notes",
    "url": "/language/rakudoc#Notes"
  },
  {
    "category": "Heading",
    "url": "/language/rakudoc#Keyboard_input",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Keyboard input"
  },
  {
    "value": "Replaceable",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "url": "/language/rakudoc#Replaceable"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Terminal_output",
    "category": "Heading",
    "value": "Terminal output"
  },
  {
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Unicode_and_HTML_references",
    "value": "Unicode and HTML references"
  },
  {
    "url": "/language/rakudoc#Verbatim_text",
    "info": ": section in <b>RakuDoc</b>",
    "value": "Verbatim text",
    "category": "Heading"
  },
  {
    "url": "/language/rakudoc#Indexing_terms",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "value": "Indexing terms"
  },
  {
    "value": "Markup extras",
    "url": "/language/rakudoc#Markup_extras",
    "category": "Heading",
    "info": ": section in <b>RakuDoc</b>"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#AUTHORS",
    "category": "Heading",
    "value": "AUTHORS"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Summary",
    "value": "Summary",
    "category": "Heading"
  },
  {
    "url": "/language/rakudoc#Blocks",
    "info": ": section in <b>RakuDoc</b>",
    "category": "Heading",
    "value": "Blocks"
  },
  {
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#Metadata_options",
    "category": "Heading",
    "value": "Metadata options"
  },
  {
    "value": "LICENSE",
    "info": ": section in <b>RakuDoc</b>",
    "url": "/language/rakudoc#LICENSE",
    "category": "Heading"
  },
  {
    "url": "/routine/%2B%7C#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>+|</b>"
  },
  {
    "info": ": section in <b>(+), infix ⊎</b>",
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/%28%2B%29%2C%20infix%20%E2%8A%8E#language/operatorsroutineinfix"
  },
  {
    "url": "/routine/gt#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>gt</b>"
  },
  {
    "info": ": section in <b>split</b>",
    "value": "In type/Str",
    "category": "Heading",
    "url": "/routine/split#type/Strroutineroutine"
  },
  {
    "value": "In type/Cool",
    "url": "/routine/split#type/Coolroutineroutine",
    "info": ": section in <b>split</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>~&</b>",
    "url": "/routine/~%26amp%3B#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "url": "/routine/substr-rw#type/Strroutinemethod",
    "info": ": section in <b>substr-rw</b>",
    "category": "Heading",
    "value": "In type/Str"
  },
  {
    "value": "In type/Cool",
    "url": "/routine/substr-rw#type/Coolroutineroutine",
    "info": ": section in <b>substr-rw</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>(cont), infix ∋</b>",
    "category": "Heading",
    "url": "/routine/%28cont%29%2C%20infix%20%E2%88%8B#language/operatorsroutineinfix",
    "value": "In language/operators"
  },
  {
    "url": "/language/operators#Operator_precedence",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "Operator precedence"
  },
  {
    "value": "Operator associativity",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#Operator_associativity"
  },
  {
    "value": "Operator classification",
    "url": "/language/operators#Operator_classification",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "value": "Substitution operators",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Substitution_operators",
    "category": "Heading"
  },
  {
    "value": "s/// in-place substitution",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#s///_in-place_substitution",
    "category": "Heading"
  },
  {
    "url": "/language/operators#S///_non-destructive_substitution",
    "value": "S/// non-destructive substitution",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#tr///_in-place_transliteration",
    "value": "tr/// in-place transliteration",
    "category": "Heading"
  },
  {
    "value": "TR/// non-destructive transliteration",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#TR///_non-destructive_transliteration",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/operators#Assignment_operators",
    "info": ": section in <b>Operators</b>",
    "value": "Assignment operators"
  },
  {
    "value": "Metaoperators",
    "url": "/language/operators#Metaoperators",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Negated_relational_operators",
    "value": "Negated relational operators"
  },
  {
    "value": "Reversed operators",
    "category": "Heading",
    "url": "/language/operators#Reversed_operators",
    "info": ": section in <b>Operators</b>"
  },
  {
    "url": "/language/operators#Hyper_operators",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "Hyper operators"
  },
  {
    "value": "Reduction metaoperators",
    "url": "/language/operators#Reduction_metaoperators",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "value": "Cross metaoperators",
    "url": "/language/operators#Cross_metaoperators",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "url": "/language/operators#Zip_metaoperator",
    "category": "Heading",
    "value": "Zip metaoperator",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "Sequential operators",
    "url": "/language/operators#Sequential_operators"
  },
  {
    "value": "Nesting of metaoperators",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#Nesting_of_metaoperators"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "Term precedence",
    "url": "/language/operators#Term_precedence"
  },
  {
    "category": "Heading",
    "value": "term < >",
    "url": "/language/operators#term_<_>",
    "info": ": section in <b>Operators</b>"
  },
  {
    "url": "/language/operators#term_(_)",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "term ( )"
  },
  {
    "value": "term { }",
    "url": "/language/operators#term_{_}",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "circumfix [ ]",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#circumfix_[_]"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "Terms",
    "url": "/language/operators#Terms"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Method_postfix_precedence",
    "category": "Heading",
    "value": "Method postfix precedence"
  },
  {
    "url": "/language/operators#postcircumfix_[_]",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "postcircumfix [ ]"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "postcircumfix { }",
    "category": "Heading",
    "url": "/language/operators#postcircumfix_{_}"
  },
  {
    "category": "Heading",
    "url": "/language/operators#postcircumfix_<>",
    "value": "postcircumfix <>",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "postcircumfix < >",
    "category": "Heading",
    "url": "/language/operators#postcircumfix_<_>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#postcircumfix_«_»",
    "category": "Heading",
    "value": "postcircumfix « »"
  },
  {
    "value": "postcircumfix ( )",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#postcircumfix_(_)"
  },
  {
    "category": "Heading",
    "url": "/language/operators#methodop_.",
    "info": ": section in <b>Operators</b>",
    "value": "methodop ."
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "methodop .&",
    "url": "/language/operators#methodop_.&"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#methodop_.=",
    "value": "methodop .=",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/operators#methodop_.^",
    "value": "methodop .^",
    "info": ": section in <b>Operators</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#methodop_.%3F",
    "value": "methodop .?"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "methodop .+",
    "url": "/language/operators#methodop_.+"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "methodop .*",
    "url": "/language/operators#methodop_.*"
  },
  {
    "url": "/language/operators#methodop_»._/_methodop_>>.",
    "category": "Heading",
    "value": "methodop ». / methodop >>.",
    "info": ": section in <b>Operators</b>"
  },
  {
    "value": "methodop .postfix / .postcircumfix",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#methodop_.postfix_/_.postcircumfix"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "methodop .:<prefix operator>",
    "url": "/language/operators#methodop_.:<prefix_operator>"
  },
  {
    "url": "/language/operators#methodop_.::",
    "value": "methodop .::",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "postfix ,=",
    "url": "/language/operators#postfix_,="
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Autoincrement_precedence",
    "value": "Autoincrement precedence",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "prefix ++",
    "url": "/language/operators#prefix_++",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "prefix --",
    "url": "/language/operators#prefix_--",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "postfix ++",
    "url": "/language/operators#postfix_++"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "postfix --",
    "url": "/language/operators#postfix_--",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/operators#Exponentiation_precedence",
    "info": ": section in <b>Operators</b>",
    "value": "Exponentiation precedence"
  },
  {
    "value": "infix **",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_**",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/operators#Symbolic_unary_precedence",
    "value": "Symbolic unary precedence",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "prefix ?",
    "url": "/language/operators#prefix_%3F",
    "category": "Heading"
  },
  {
    "url": "/language/operators#prefix_!",
    "info": ": section in <b>Operators</b>",
    "value": "prefix !",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "prefix //",
    "category": "Heading",
    "url": "/language/operators#prefix_//"
  },
  {
    "url": "/language/operators#prefix_+",
    "category": "Heading",
    "value": "prefix +",
    "info": ": section in <b>Operators</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "prefix -",
    "url": "/language/operators#prefix_-"
  },
  {
    "category": "Heading",
    "value": "prefix ~",
    "url": "/language/operators#prefix_~",
    "info": ": section in <b>Operators</b>"
  },
  {
    "url": "/language/operators#prefix_|",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "prefix |"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "prefix +^",
    "url": "/language/operators#prefix_+^"
  },
  {
    "category": "Heading",
    "value": "prefix ~^",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#prefix_~^"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "prefix ?^",
    "category": "Heading",
    "url": "/language/operators#prefix_%3F^"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#prefix_^",
    "value": "prefix ^"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Dotty_infix_precedence",
    "value": "Dotty infix precedence",
    "category": "Heading"
  },
  {
    "value": "infix .=",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#infix_.="
  },
  {
    "value": "infix .",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#infix_."
  },
  {
    "value": "Multiplicative precedence",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Multiplicative_precedence"
  },
  {
    "value": "infix *",
    "url": "/language/operators#infix_*",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "infix /",
    "url": "/language/operators#infix_/"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "infix div",
    "category": "Heading",
    "url": "/language/operators#infix_div"
  },
  {
    "url": "/language/operators#infix_%",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix %"
  },
  {
    "category": "Heading",
    "url": "/language/operators#infix_%%",
    "value": "infix %%",
    "info": ": section in <b>Operators</b>"
  },
  {
    "url": "/language/operators#infix_mod",
    "value": "infix mod",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_+&",
    "category": "Heading",
    "value": "infix +&"
  },
  {
    "url": "/language/operators#infix_+<",
    "info": ": section in <b>Operators</b>",
    "value": "infix +<",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_+>",
    "value": "infix +>",
    "category": "Heading"
  },
  {
    "value": "infix ~&",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_~&",
    "category": "Heading"
  },
  {
    "url": "/language/operators#infix_~<",
    "info": ": section in <b>Operators</b>",
    "value": "infix ~<",
    "category": "Heading"
  },
  {
    "url": "/language/operators#infix_~>",
    "category": "Heading",
    "value": "infix ~>",
    "info": ": section in <b>Operators</b>"
  },
  {
    "url": "/language/operators#infix_%3F&",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix ?&"
  },
  {
    "value": "infix gcd",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_gcd",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_lcm",
    "category": "Heading",
    "value": "infix lcm"
  },
  {
    "url": "/language/operators#Additive_precedence",
    "value": "Additive precedence",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "infix +",
    "category": "Heading",
    "url": "/language/operators#infix_+"
  },
  {
    "category": "Heading",
    "value": "infix -",
    "url": "/language/operators#infix_-",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "infix +|",
    "category": "Heading",
    "url": "/language/operators#infix_+|"
  },
  {
    "value": "infix +^",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_+^",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#infix_~|",
    "value": "infix ~|"
  },
  {
    "value": "infix ~^",
    "url": "/language/operators#infix_~^",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "value": "infix ?^",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_%3F^"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "infix ?|",
    "category": "Heading",
    "url": "/language/operators#infix_%3F|"
  },
  {
    "url": "/language/operators#Replication_precedence",
    "category": "Heading",
    "value": "Replication precedence",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_x",
    "category": "Heading",
    "value": "infix x"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "infix xx",
    "category": "Heading",
    "url": "/language/operators#infix_xx"
  },
  {
    "category": "Heading",
    "url": "/language/operators#Concatenation",
    "info": ": section in <b>Operators</b>",
    "value": "Concatenation"
  },
  {
    "category": "Heading",
    "value": "infix ~",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_~"
  },
  {
    "value": "infix o, infix ∘",
    "category": "Heading",
    "url": "/language/operators#infix_o,_infix_∘",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Junctive_AND_(all)_precedence",
    "value": "Junctive AND (all) precedence",
    "category": "Heading"
  },
  {
    "url": "/language/operators#infix_&",
    "value": "infix &",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/operators#infix_(&),_infix_∩",
    "info": ": section in <b>Operators</b>",
    "value": "infix (&), infix ∩"
  },
  {
    "value": "infix (.), infix ⊍",
    "url": "/language/operators#infix_(.),_infix_⊍",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "value": "Junctive OR (any) precedence",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Junctive_OR_(any)_precedence",
    "category": "Heading"
  },
  {
    "url": "/language/operators#infix_|",
    "value": "infix |",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_(|),_infix_∪",
    "value": "infix (|), infix ∪",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix (+), infix ⊎",
    "url": "/language/operators#infix_(+),_infix_⊎"
  },
  {
    "value": "infix (-), infix ∖",
    "category": "Heading",
    "url": "/language/operators#infix_(-),_infix_∖",
    "info": ": section in <b>Operators</b>"
  },
  {
    "category": "Heading",
    "value": "infix ^",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_^"
  },
  {
    "url": "/language/operators#infix_(^),_infix_⊖",
    "category": "Heading",
    "value": "infix (^), infix ⊖",
    "info": ": section in <b>Operators</b>"
  },
  {
    "value": "Named unary precedence",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Named_unary_precedence"
  },
  {
    "url": "/language/operators#prefix_temp",
    "value": "prefix temp",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#prefix_let",
    "value": "prefix let"
  },
  {
    "category": "Heading",
    "value": "Nonchaining binary precedence",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Nonchaining_binary_precedence"
  },
  {
    "url": "/language/operators#infix_does",
    "category": "Heading",
    "value": "infix does",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_but",
    "value": "infix but",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/operators#infix_cmp",
    "info": ": section in <b>Operators</b>",
    "value": "infix cmp"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#infix_coll",
    "value": "infix coll"
  },
  {
    "url": "/language/operators#infix_unicmp",
    "category": "Heading",
    "value": "infix unicmp",
    "info": ": section in <b>Operators</b>"
  },
  {
    "category": "Heading",
    "url": "/language/operators#infix_leg",
    "info": ": section in <b>Operators</b>",
    "value": "infix leg"
  },
  {
    "category": "Heading",
    "value": "infix <=>",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_<=>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_..",
    "value": "infix ..",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "infix ..^",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_..^"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix ^..",
    "url": "/language/operators#infix_^.."
  },
  {
    "url": "/language/operators#infix_^..^",
    "value": "infix ^..^",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "url": "/language/operators#Chaining_binary_precedence",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "Chaining binary precedence"
  },
  {
    "url": "/language/operators#infix_==,_infix_⩵",
    "value": "infix ==, infix ⩵",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/operators#infix_!=,_infix_≠",
    "value": "infix !=, infix ≠",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_<",
    "value": "infix <",
    "category": "Heading"
  },
  {
    "value": "infix <=, infix ≤",
    "url": "/language/operators#infix_<=,_infix_≤",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "url": "/language/operators#infix_>",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix >"
  },
  {
    "url": "/language/operators#infix_>=,_infix_≥",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix >=, infix ≥"
  },
  {
    "value": "infix eq",
    "url": "/language/operators#infix_eq",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "category": "Heading",
    "value": "infix ne",
    "url": "/language/operators#infix_ne",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_gt",
    "category": "Heading",
    "value": "infix gt"
  },
  {
    "category": "Heading",
    "value": "infix ge",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_ge"
  },
  {
    "value": "infix lt",
    "url": "/language/operators#infix_lt",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "value": "infix le",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_le"
  },
  {
    "value": "infix before",
    "category": "Heading",
    "url": "/language/operators#infix_before",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_after",
    "value": "infix after",
    "category": "Heading"
  },
  {
    "url": "/language/operators#infix_eqv",
    "value": "infix eqv",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "infix ===, infix ⩶",
    "url": "/language/operators#infix_===,_infix_⩶"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "infix =:=",
    "url": "/language/operators#infix_=:=",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_~~",
    "value": "infix ~~",
    "category": "Heading"
  },
  {
    "url": "/language/operators#infix_=~=",
    "info": ": section in <b>Operators</b>",
    "value": "infix =~=",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "infix (elem), infix ∈",
    "url": "/language/operators#infix_(elem),_infix_∈",
    "category": "Heading"
  },
  {
    "value": "infix ∉",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_∉",
    "category": "Heading"
  },
  {
    "value": "infix (==), infix ≡",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_(==),_infix_≡"
  },
  {
    "value": "infix ≢",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_≢"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_(cont),_infix_∋",
    "category": "Heading",
    "value": "infix (cont), infix ∋"
  },
  {
    "value": "infix ∌",
    "url": "/language/operators#infix_∌",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "value": "infix (<), infix ⊂",
    "url": "/language/operators#infix_(<),_infix_⊂",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#infix_⊄",
    "value": "infix ⊄"
  },
  {
    "url": "/language/operators#infix_(<=),_infix_⊆",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix (<=), infix ⊆"
  },
  {
    "url": "/language/operators#infix_⊈",
    "category": "Heading",
    "value": "infix ⊈",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "infix (>), infix ⊃",
    "url": "/language/operators#infix_(>),_infix_⊃"
  },
  {
    "category": "Heading",
    "url": "/language/operators#infix_⊅",
    "info": ": section in <b>Operators</b>",
    "value": "infix ⊅"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix (>=), infix ⊇",
    "url": "/language/operators#infix_(>=),_infix_⊇"
  },
  {
    "url": "/language/operators#infix_⊉",
    "info": ": section in <b>Operators</b>",
    "value": "infix ⊉",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Tight AND precedence",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Tight_AND_precedence"
  },
  {
    "value": "infix &&",
    "url": "/language/operators#infix_&&",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "Tight OR precedence",
    "category": "Heading",
    "url": "/language/operators#Tight_OR_precedence"
  },
  {
    "category": "Heading",
    "url": "/language/operators#infix_||",
    "value": "infix ||",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "infix ^^",
    "url": "/language/operators#infix_^^",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_//",
    "value": "infix //",
    "category": "Heading"
  },
  {
    "url": "/language/operators#infix_min",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "infix min"
  },
  {
    "category": "Heading",
    "value": "infix max",
    "url": "/language/operators#infix_max",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "value": "infix minmax",
    "category": "Heading",
    "url": "/language/operators#infix_minmax"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#Conditional_operator_precedence",
    "value": "Conditional operator precedence"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_%3F%3F_!!",
    "category": "Heading",
    "value": "infix ?? !!"
  },
  {
    "value": "infix ff",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_ff",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_^ff",
    "value": "infix ^ff",
    "category": "Heading"
  },
  {
    "value": "infix ff^",
    "url": "/language/operators#infix_ff^",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/operators#infix_^ff^",
    "info": ": section in <b>Operators</b>",
    "value": "infix ^ff^"
  },
  {
    "value": "infix fff",
    "url": "/language/operators#infix_fff",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "value": "infix ^fff",
    "category": "Heading",
    "url": "/language/operators#infix_^fff",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "url": "/language/operators#infix_fff^",
    "value": "infix fff^"
  },
  {
    "value": "infix ^fff^",
    "category": "Heading",
    "url": "/language/operators#infix_^fff^",
    "info": ": section in <b>Operators</b>"
  },
  {
    "value": "Item assignment precedence",
    "url": "/language/operators#Item_assignment_precedence",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "url": "/language/operators#infix_=_(item_assignment)",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix = (item assignment)"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_=>",
    "value": "infix =>"
  },
  {
    "value": "Loose unary precedence",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Loose_unary_precedence",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#prefix_not",
    "category": "Heading",
    "value": "prefix not"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#prefix_so",
    "category": "Heading",
    "value": "prefix so"
  },
  {
    "url": "/language/operators#Comma_operator_precedence",
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "Comma operator precedence"
  },
  {
    "url": "/language/operators#infix_,",
    "value": "infix ,",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "value": "infix :",
    "url": "/language/operators#infix_:",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "category": "Heading",
    "url": "/language/operators#List_infix_precedence",
    "info": ": section in <b>Operators</b>",
    "value": "List infix precedence"
  },
  {
    "url": "/language/operators#infix_Z",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix Z"
  },
  {
    "url": "/language/operators#infix_X",
    "value": "infix X",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "infix ...",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_..."
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "List prefix precedence",
    "url": "/language/operators#List_prefix_precedence"
  },
  {
    "url": "/language/operators#infix_=_(list_assignment)",
    "value": "infix = (list assignment)",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_:=",
    "value": "infix :="
  },
  {
    "category": "Heading",
    "value": "infix ::=",
    "url": "/language/operators#infix_::=",
    "info": ": section in <b>Operators</b>"
  },
  {
    "value": "listop ...",
    "url": "/language/operators#listop_...",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "url": "/language/operators#listop_!!!",
    "value": "listop !!!",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "category": "Heading",
    "value": "listop ???",
    "url": "/language/operators#listop_%3F%3F%3F"
  },
  {
    "value": "Reduction operators",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Reduction_operators",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Loose AND precedence",
    "url": "/language/operators#Loose_AND_precedence",
    "info": ": section in <b>Operators</b>"
  },
  {
    "value": "infix and",
    "url": "/language/operators#infix_and",
    "category": "Heading",
    "info": ": section in <b>Operators</b>"
  },
  {
    "url": "/language/operators#infix_andthen",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix andthen"
  },
  {
    "value": "infix notandthen",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_notandthen",
    "category": "Heading"
  },
  {
    "value": "Loose OR precedence",
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#Loose_OR_precedence"
  },
  {
    "value": "infix or",
    "url": "/language/operators#infix_or",
    "info": ": section in <b>Operators</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "infix orelse",
    "url": "/language/operators#infix_orelse",
    "info": ": section in <b>Operators</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Operators</b>",
    "value": "infix xor",
    "url": "/language/operators#infix_xor"
  },
  {
    "value": "Sequencer precedence",
    "category": "Heading",
    "url": "/language/operators#Sequencer_precedence",
    "info": ": section in <b>Operators</b>"
  },
  {
    "info": ": section in <b>Operators</b>",
    "url": "/language/operators#infix_==>",
    "category": "Heading",
    "value": "infix ==>"
  },
  {
    "category": "Heading",
    "value": "infix <==",
    "url": "/language/operators#infix_<==",
    "info": ": section in <b>Operators</b>"
  },
  {
    "category": "Heading",
    "value": "Identity",
    "url": "/language/operators#Identity",
    "info": ": section in <b>Operators</b>"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>++</b>",
    "url": "/routine/%2B%2B#language/operatorsroutineprefix"
  },
  {
    "url": "/routine/%2B%2B#language/operatorsroutinepostfix",
    "category": "Heading",
    "info": ": section in <b>++</b>",
    "value": "In language/operators"
  },
  {
    "url": "/test#this_is_a_heading",
    "value": "this is a heading",
    "info": ": section in <b>A file to test blocks</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>A file to test blocks</b>",
    "url": "/test#Numitem2",
    "value": "Numitem2",
    "category": "Heading"
  },
  {
    "value": "Numitem",
    "url": "/test#Numitem",
    "info": ": section in <b>A file to test blocks</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>A file to test blocks</b>",
    "value": "Numdefn",
    "url": "/test#Numdefn"
  },
  {
    "info": ": section in <b>NYI</b>",
    "category": "Heading",
    "value": "In language/glossary",
    "url": "/syntax/NYI#language/glossarysyntaxNYI"
  },
  {
    "info": ": section in <b>Number literals</b>",
    "url": "/syntax/Number%20literals#language/syntaxsyntaxNumber literals",
    "value": "In language/syntax",
    "category": "Heading"
  },
  {
    "info": ": section in <b>month</b>",
    "url": "/routine/month#type/Dateishroutinemethod",
    "value": "In type/Dateish",
    "category": "Heading"
  },
  {
    "value": "In type/Str",
    "url": "/routine/flip#type/Strroutineroutine",
    "category": "Heading",
    "info": ": section in <b>flip</b>"
  },
  {
    "info": ": section in <b>flip</b>",
    "category": "Heading",
    "url": "/routine/flip#type/Coolroutineroutine",
    "value": "In type/Cool"
  },
  {
    "value": "Restrictions",
    "url": "/language/tables#Restrictions",
    "category": "Heading",
    "info": ": section in <b>Pod6 tables</b>"
  },
  {
    "url": "/language/tables#Best_practices",
    "info": ": section in <b>Pod6 tables</b>",
    "category": "Heading",
    "value": "Best practices"
  },
  {
    "value": "Valid tables",
    "info": ": section in <b>Pod6 tables</b>",
    "category": "Heading",
    "url": "/language/tables#Valid_tables"
  },
  {
    "url": "/language/tables#Invalid_tables",
    "category": "Heading",
    "info": ": section in <b>Pod6 tables</b>",
    "value": "Invalid tables"
  },
  {
    "url": "/language/tables#Unexpected_tables",
    "info": ": section in <b>Pod6 tables</b>",
    "value": "Unexpected tables",
    "category": "Heading"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "url": "/syntax/X%20%28cross%20metaoperator%29#language/operatorssyntaxX (cross metaoperator)",
    "info": ": section in <b>X (cross metaoperator)</b>"
  },
  {
    "info": ": section in <b>^fff^</b>",
    "url": "/routine/%5Efff%5E#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "info": ": section in <b>cosech</b>",
    "value": "In type/Cool",
    "url": "/routine/cosech#type/Coolroutineroutine",
    "category": "Heading"
  },
  {
    "url": "/routine/notandthen#language/operatorsroutineinfix",
    "info": ": section in <b>notandthen</b>",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "category": "Heading",
    "value": "In language/regexes",
    "info": ": section in <b>[ ]</b>",
    "url": "/syntax/%5B%20%5D#language/regexessyntax[ ]"
  },
  {
    "url": "/routine/roll#type/Baggyroutinemethod",
    "category": "Heading",
    "info": ": section in <b>roll</b>",
    "value": "In type/Baggy"
  },
  {
    "value": "In type/Str",
    "category": "Heading",
    "url": "/routine/parse-names#type/Strroutineroutine",
    "info": ": section in <b>parse-names</b>"
  },
  {
    "url": "/routine/indices#type/Strroutinemethod",
    "category": "Heading",
    "value": "In type/Str",
    "info": ": section in <b>indices</b>"
  },
  {
    "value": "In type/Signature",
    "info": ": section in <b>returns</b>",
    "category": "Heading",
    "url": "/routine/returns#type/Signatureroutinemethod"
  },
  {
    "info": ": section in <b>Variable Interpolation</b>",
    "category": "Heading",
    "value": "In language/glossary",
    "url": "/syntax/Variable%20Interpolation#language/glossarysyntaxVariable Interpolation"
  },
  {
    "category": "Heading",
    "url": "/routine/unique#type/independent-routinesroutineroutine",
    "value": "In type/independent-routines",
    "info": ": section in <b>unique</b>"
  },
  {
    "value": "In type/Str",
    "category": "Heading",
    "url": "/routine/uniparse#type/Strroutineroutine",
    "info": ": section in <b>uniparse</b>"
  },
  {
    "value": "In type/Cool",
    "category": "Heading",
    "info": ": section in <b>uniparse</b>",
    "url": "/routine/uniparse#type/Coolroutinemethod"
  },
  {
    "url": "/routine/push#type/independent-routinesroutinesub",
    "value": "In type/independent-routines",
    "info": ": section in <b>push</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>@_ (Perl)</b>",
    "value": "In language/5to6-perlvar",
    "category": "Heading",
    "url": "/syntax/%40_%20%28Perl%29#language/5to6-perlvarsyntax@_ (Perl)"
  },
  {
    "info": ": section in <b>temp</b>",
    "category": "Heading",
    "url": "/routine/temp#language/variablesroutineprefix",
    "value": "In language/variables"
  },
  {
    "category": "Heading",
    "info": ": section in <b>temp</b>",
    "url": "/routine/temp#language/operatorsroutineprefix",
    "value": "In language/operators"
  },
  {
    "info": ": section in <b>Community</b>",
    "url": "/language/community#Overview",
    "value": "Overview",
    "category": "Heading"
  },
  {
    "url": "/language/community#The_Raku_community",
    "category": "Heading",
    "value": "The Raku community",
    "info": ": section in <b>Community</b>"
  },
  {
    "value": "Online communities",
    "category": "Heading",
    "url": "/language/community#Online_communities",
    "info": ": section in <b>Community</b>"
  },
  {
    "url": "/language/community#Offline_communities",
    "value": "Offline communities",
    "info": ": section in <b>Community</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Community</b>",
    "value": "Other resources",
    "url": "/language/community#Other_resources"
  },
  {
    "url": "/language/community#Rakudo_Weekly",
    "info": ": section in <b>Community</b>",
    "category": "Heading",
    "value": "Rakudo Weekly"
  },
  {
    "info": ": section in <b>Community</b>",
    "url": "/language/community#Raku_Advent_calendar",
    "value": "Raku Advent calendar",
    "category": "Heading"
  },
  {
    "url": "/syntax/%3Ax#language/regexessyntax:x",
    "value": "In language/regexes",
    "category": "Heading",
    "info": ": section in <b>:x</b>"
  },
  {
    "value": "In language/glossary",
    "category": "Heading",
    "url": "/syntax/Symbol#language/glossarysyntaxSymbol",
    "info": ": section in <b>Symbol</b>"
  },
  {
    "category": "Heading",
    "url": "/routine/NFD#type/Strroutinemethod",
    "info": ": section in <b>NFD</b>",
    "value": "In type/Str"
  },
  {
    "category": "Heading",
    "info": ": section in <b>\\d</b>",
    "value": "In language/regexes",
    "url": "/syntax/%5Cd#language/regexessyntax%5Cd"
  },
  {
    "url": "/routine/le#language/operatorsroutineinfix",
    "info": ": section in <b>le</b>",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "value": "In type/Baggy",
    "url": "/routine/kv#type/Baggyroutinemethod",
    "category": "Heading",
    "info": ": section in <b>kv</b>"
  },
  {
    "category": "Heading",
    "value": "In type/Cool",
    "info": ": section in <b>log</b>",
    "url": "/routine/log#type/Coolroutineroutine"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Debugging</b>",
    "value": "Core debugging features",
    "url": "/programs/01-debugging#Core_debugging_features"
  },
  {
    "value": "The trace pragma",
    "category": "Heading",
    "url": "/programs/01-debugging#The_trace_pragma",
    "info": ": section in <b>Debugging</b>"
  },
  {
    "info": ": section in <b>Debugging</b>",
    "category": "Heading",
    "url": "/programs/01-debugging#Dumper_function_(dd)",
    "value": "Dumper function (dd)"
  },
  {
    "url": "/programs/01-debugging#Using_backtraces",
    "info": ": section in <b>Debugging</b>",
    "category": "Heading",
    "value": "Using backtraces"
  },
  {
    "url": "/programs/01-debugging#Environment_variables",
    "value": "Environment variables",
    "info": ": section in <b>Debugging</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Debugging</b>",
    "category": "Heading",
    "value": "Ecosystem debugging modules",
    "url": "/programs/01-debugging#Ecosystem_debugging_modules"
  },
  {
    "url": "/programs/01-debugging#Debugger::UI::CommandLine",
    "category": "Heading",
    "value": "Debugger::UI::CommandLine",
    "info": ": section in <b>Debugging</b>"
  },
  {
    "value": "Grammar::Debugger (and Grammar::Tracer in the same distribution)",
    "info": ": section in <b>Debugging</b>",
    "category": "Heading",
    "url": "/programs/01-debugging#Grammar::Debugger_(and_Grammar::Tracer_in_the_same_distribution)"
  },
  {
    "url": "/programs/01-debugging#Trait::Traced",
    "value": "Trait::Traced",
    "info": ": section in <b>Debugging</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>redo</b>",
    "category": "Heading",
    "value": "In language/control",
    "url": "/syntax/redo#language/controlsyntaxredo"
  },
  {
    "category": "Heading",
    "info": ": section in <b>log2</b>",
    "url": "/routine/log2#type/Coolroutineroutine",
    "value": "In type/Cool"
  },
  {
    "category": "Heading",
    "value": "In language/hashmap",
    "info": ": section in <b>non-string keys</b>",
    "url": "/syntax/non-string%20keys#language/hashmapsyntaxnon-string keys"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "url": "/syntax/%21%20%28negation%20metaoperator%29#language/operatorssyntax! (negation metaoperator)",
    "info": ": section in <b>! (negation metaoperator)</b>"
  },
  {
    "url": "/routine/lcm#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>lcm</b>",
    "category": "Heading"
  },
  {
    "value": "Named Regexes",
    "info": ": section in <b>Grammars</b>",
    "category": "Heading",
    "url": "/language/grammars#Named_Regexes"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Grammars</b>",
    "url": "/language/grammars#Rules",
    "value": "Rules"
  },
  {
    "url": "/language/grammars#Creating_grammars",
    "info": ": section in <b>Grammars</b>",
    "value": "Creating grammars",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/grammars#Proto_regexes",
    "info": ": section in <b>Grammars</b>",
    "value": "Proto regexes"
  },
  {
    "url": "/language/grammars#Special_tokens",
    "info": ": section in <b>Grammars</b>",
    "category": "Heading",
    "value": "Special tokens"
  },
  {
    "info": ": section in <b>Grammars</b>",
    "value": "TOP",
    "category": "Heading",
    "url": "/language/grammars#TOP"
  },
  {
    "value": "ws",
    "url": "/language/grammars#ws",
    "info": ": section in <b>Grammars</b>",
    "category": "Heading"
  },
  {
    "url": "/language/grammars#sym",
    "info": ": section in <b>Grammars</b>",
    "value": "sym",
    "category": "Heading"
  },
  {
    "url": "/language/grammars#\\\"Always_succeed\\\"_assertion",
    "value": "\"Always succeed\" assertion",
    "info": ": section in <b>Grammars</b>",
    "category": "Heading"
  },
  {
    "value": "Methods in grammars",
    "category": "Heading",
    "url": "/language/grammars#Methods_in_grammars",
    "info": ": section in <b>Grammars</b>"
  },
  {
    "value": "Dynamic variables in grammars",
    "info": ": section in <b>Grammars</b>",
    "category": "Heading",
    "url": "/language/grammars#Dynamic_variables_in_grammars"
  },
  {
    "category": "Heading",
    "value": "Attributes in grammars",
    "info": ": section in <b>Grammars</b>",
    "url": "/language/grammars#Attributes_in_grammars"
  },
  {
    "category": "Heading",
    "url": "/language/grammars#Passing_arguments_into_grammars",
    "value": "Passing arguments into grammars",
    "info": ": section in <b>Grammars</b>"
  },
  {
    "info": ": section in <b>Grammars</b>",
    "value": "Action objects",
    "category": "Heading",
    "url": "/language/grammars#Action_objects"
  },
  {
    "info": ": section in <b>Date</b>",
    "category": "Heading",
    "url": "/routine/Date#type/Strroutinemethod",
    "value": "In type/Str"
  },
  {
    "category": "Heading",
    "url": "/routine/%2F#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>/</b>"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "Basic syntax",
    "url": "/language/rb-nutshell#Basic_syntax",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "Statement ending semicolons",
    "category": "Heading",
    "url": "/language/rb-nutshell#Statement_ending_semicolons"
  },
  {
    "value": "Whitespace",
    "category": "Heading",
    "url": "/language/rb-nutshell#Whitespace",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "url": "/language/rb-nutshell#._Method_calls,_.public_send",
    "value": ". Method calls, .public_send",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#Variables,_sigils,_scope,_and_common_types",
    "category": "Heading",
    "value": "Variables, sigils, scope, and common types"
  },
  {
    "category": "Heading",
    "value": "Variable scope",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#Variable_scope"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "$ Scalar",
    "category": "Heading",
    "url": "/language/rb-nutshell#$_Scalar"
  },
  {
    "value": "@ Array",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#@_Array",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "% Hash",
    "url": "/language/rb-nutshell#%_Hash",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "category": "Heading",
    "value": "& Sub",
    "url": "/language/rb-nutshell#&_Sub",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "url": "/language/rb-nutshell#*_Slurpy_params_/_argument_expansion",
    "category": "Heading",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "* Slurpy params / argument expansion"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#Twigils",
    "category": "Heading",
    "value": "Twigils"
  },
  {
    "url": "/language/rb-nutshell#:_Symbols",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading",
    "value": ": Symbols"
  },
  {
    "url": "/language/rb-nutshell#Operators",
    "value": "Operators",
    "category": "Heading",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "== != < > <= >= Comparisons",
    "url": "/language/rb-nutshell#==_!=_<_>_<=_>=_Comparisons",
    "category": "Heading"
  },
  {
    "url": "/language/rb-nutshell#<=>_Three-way_comparisons",
    "category": "Heading",
    "value": "<=> Three-way comparisons",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "value": "~~ Smartmatch operator",
    "category": "Heading",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#~~_Smartmatch_operator"
  },
  {
    "url": "/language/rb-nutshell#&_|_^_Numeric_bitwise_ops",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading",
    "value": "& | ^ Numeric bitwise ops"
  },
  {
    "value": "& | ^ Boolean ops",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading",
    "url": "/language/rb-nutshell#&_|_^_Boolean_ops"
  },
  {
    "value": "&. Conditional chaining operator",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#&._Conditional_chaining_operator",
    "category": "Heading"
  },
  {
    "url": "/language/rb-nutshell#<<_>>_Numeric_shift_left,_right_ops,_shovel_operator",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "<< >> Numeric shift left, right ops, shovel operator",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading",
    "value": "=> and : Key-value separators",
    "url": "/language/rb-nutshell#=>_and_:_Key-value_separators"
  },
  {
    "category": "Heading",
    "value": "? : Ternary operator",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#%3F_:_Ternary_operator"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading",
    "url": "/language/rb-nutshell#+_String_concatenation",
    "value": "+ String concatenation"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "String interpolation",
    "category": "Heading",
    "url": "/language/rb-nutshell#String_interpolation"
  },
  {
    "category": "Heading",
    "value": "Compound statements",
    "url": "/language/rb-nutshell#Compound_statements",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "value": "Conditionals",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#Conditionals",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading",
    "url": "/language/rb-nutshell#if_elsif_else_unless",
    "value": "if elsif else unless"
  },
  {
    "value": "case-when",
    "url": "/language/rb-nutshell#case-when",
    "category": "Heading",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "value": "Loops",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#Loops",
    "category": "Heading"
  },
  {
    "url": "/language/rb-nutshell#while_until",
    "category": "Heading",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "while until"
  },
  {
    "value": "for .each",
    "url": "/language/rb-nutshell#for_.each",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#Flow_interruption_statements",
    "value": "Flow interruption statements",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "Regular expressions ( regex / regexp )",
    "url": "/language/rb-nutshell#Regular_expressions_(_regex_/_regexp_)"
  },
  {
    "value": ".match method and =~ operator",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#.match_method_and_=~_operator",
    "category": "Heading"
  },
  {
    "value": ".sub and .sub!",
    "url": "/language/rb-nutshell#.sub_and_.sub!",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading"
  },
  {
    "value": "Regex options",
    "url": "/language/rb-nutshell#Regex_options",
    "category": "Heading",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading",
    "url": "/language/rb-nutshell#Whitespace_is_ignored,_most_things_must_be_quoted",
    "value": "Whitespace is ignored, most things must be quoted"
  },
  {
    "url": "/language/rb-nutshell#Special_matchers_generally_fall_under_the_<>_syntax",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "Special matchers generally fall under the <> syntax",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/rb-nutshell#Longest_token_matching_(LTM)_displaces_alternation",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "Longest token matching (LTM) displaces alternation"
  },
  {
    "url": "/language/rb-nutshell#File-related_operations",
    "category": "Heading",
    "value": "File-related operations",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "url": "/language/rb-nutshell#Reading_the_lines_of_a_text_file_into_an_array",
    "value": "Reading the lines of a text file into an array",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading"
  },
  {
    "url": "/language/rb-nutshell#Iterating_over_the_lines_of_a_text_file",
    "value": "Iterating over the lines of a text file",
    "category": "Heading",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "value": "Object orientation",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#Object_orientation",
    "category": "Heading"
  },
  {
    "url": "/language/rb-nutshell#Basic_classes,_methods,_attributes",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "Basic classes, methods, attributes",
    "category": "Heading"
  },
  {
    "value": "Private methods",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#Private_methods",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "url": "/language/rb-nutshell#Going_meta",
    "category": "Heading",
    "value": "Going meta"
  },
  {
    "value": "Environment variables",
    "url": "/language/rb-nutshell#Environment_variables",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "category": "Heading"
  },
  {
    "url": "/language/rb-nutshell#Raku_module_library_path",
    "category": "Heading",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "Raku module library path"
  },
  {
    "url": "/language/rb-nutshell#Misc.",
    "value": "Misc.",
    "category": "Heading",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "url": "/language/rb-nutshell#Importing_specific_functions_from_a_module",
    "category": "Heading",
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "Importing specific functions from a module"
  },
  {
    "url": "/language/rb-nutshell#OptionParser,_parsing_command-line_flags",
    "category": "Heading",
    "value": "OptionParser, parsing command-line flags",
    "info": ": section in <b>Ruby to Raku - nutshell</b>"
  },
  {
    "info": ": section in <b>Ruby to Raku - nutshell</b>",
    "value": "RubyGems, external libraries",
    "url": "/language/rb-nutshell#RubyGems,_external_libraries",
    "category": "Heading"
  },
  {
    "info": ": section in <b>!</b>",
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/%21#language/operatorsroutineprefix"
  },
  {
    "category": "Heading",
    "info": ": section in <b>callframe</b>",
    "value": "In type/CallFrame",
    "url": "/routine/callframe#type/CallFrameroutinesub"
  },
  {
    "value": "In language/control",
    "category": "Heading",
    "info": ": section in <b>once</b>",
    "url": "/syntax/once#language/controlsyntaxonce"
  },
  {
    "category": "Heading",
    "value": "In language/syntax",
    "info": ": section in <b>\\</b>",
    "url": "/syntax/%5C#language/syntaxsyntax%5C"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>∌</b>",
    "url": "/routine/%E2%88%8C#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "url": "/routine/%26gt%3B#language/operatorsroutineinfix",
    "category": "Heading",
    "info": ": section in <b>></b>",
    "value": "In language/operators"
  },
  {
    "category": "Heading",
    "value": "In language/regexes",
    "url": "/syntax/%3Aoverlap#language/regexessyntax:overlap",
    "info": ": section in <b>:overlap</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>acos</b>",
    "url": "/routine/acos#type/Coolroutineroutine",
    "value": "In type/Cool"
  },
  {
    "url": "/syntax/Type%20objects#language/objectssyntaxType objects",
    "info": ": section in <b>Type objects</b>",
    "value": "In language/objects",
    "category": "Heading"
  },
  {
    "info": ": section in <b>grabpairs</b>",
    "url": "/routine/grabpairs#type/Baggyroutinemethod",
    "category": "Heading",
    "value": "In type/Baggy"
  },
  {
    "info": ": section in <b>(-), infix ∖</b>",
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/%28-%29%2C%20infix%20%E2%88%96#language/operatorsroutineinfix"
  },
  {
    "info": ": section in <b>Complex</b>",
    "category": "Heading",
    "value": "In type/Cool",
    "url": "/routine/Complex#type/Coolroutinemethod"
  },
  {
    "url": "/routine/positional#type/Parameterroutinemethod",
    "category": "Heading",
    "value": "In type/Parameter",
    "info": ": section in <b>positional</b>"
  },
  {
    "url": "/routine/~%26gt%3B#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>~></b>",
    "category": "Heading"
  },
  {
    "value": "In type/Cool",
    "category": "Heading",
    "url": "/routine/sinh#type/Coolroutineroutine",
    "info": ": section in <b>sinh</b>"
  },
  {
    "value": "In language/functions",
    "url": "/syntax/nextsame#language/functionssyntaxnextsame",
    "category": "Heading",
    "info": ": section in <b>nextsame</b>"
  },
  {
    "value": "In language/glossary",
    "url": "/syntax/multi-method#language/glossarysyntaxmulti-method",
    "category": "Heading",
    "info": ": section in <b>multi-method</b>"
  },
  {
    "url": "/routine/%28.%29%2C%20infix%20%E2%8A%8D#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>(.), infix ⊍</b>",
    "category": "Heading"
  },
  {
    "url": "/syntax/statement%20%28Basics%29#language/101-basicssyntaxstatement (Basics)",
    "info": ": section in <b>statement (Basics)</b>",
    "category": "Heading",
    "value": "In language/101-basics"
  },
  {
    "url": "/routine/%C2%AB%20%C2%BB#language/operatorsroutinepostcircumfix",
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>« »</b>"
  },
  {
    "info": ": section in <b>POV</b>",
    "value": "In language/glossary",
    "category": "Heading",
    "url": "/syntax/POV#language/glossarysyntaxPOV"
  },
  {
    "category": "Heading",
    "url": "/routine/%5B%20%5D#language/operatorsroutinecircumfix",
    "info": ": section in <b>[ ]</b>",
    "value": "In language/operators"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>[ ]</b>",
    "url": "/routine/%5B%20%5D#language/operatorsroutinepostcircumfix",
    "category": "Heading"
  },
  {
    "url": "/routine/week-number#type/Dateishroutinemethod",
    "category": "Heading",
    "info": ": section in <b>week-number</b>",
    "value": "In type/Dateish"
  },
  {
    "category": "Heading",
    "info": ": section in <b>dd-mm-yyyy</b>",
    "value": "In type/Dateish",
    "url": "/routine/dd-mm-yyyy#type/Dateishroutinemethod"
  },
  {
    "url": "/language/classtut#A_quick_overview",
    "info": ": section in <b>Classes and objects</b>",
    "category": "Heading",
    "value": "A quick overview"
  },
  {
    "url": "/language/classtut#The_Task_example",
    "info": ": section in <b>Classes and objects</b>",
    "category": "Heading",
    "value": "The Task example"
  },
  {
    "info": ": section in <b>Classes and objects</b>",
    "value": "Class",
    "url": "/language/classtut#Class",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Classes and objects</b>",
    "value": "Attributes",
    "category": "Heading",
    "url": "/language/classtut#Attributes"
  },
  {
    "category": "Heading",
    "value": "Twigil $!",
    "info": ": section in <b>Classes and objects</b>",
    "url": "/language/classtut#Twigil_$!"
  },
  {
    "info": ": section in <b>Classes and objects</b>",
    "url": "/language/classtut#Twigil_$.",
    "value": "Twigil $.",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Classes and objects</b>",
    "value": "is rw trait",
    "url": "/language/classtut#is_rw_trait",
    "category": "Heading"
  },
  {
    "value": "is built trait",
    "category": "Heading",
    "info": ": section in <b>Classes and objects</b>",
    "url": "/language/classtut#is_built_trait"
  },
  {
    "value": "is required trait",
    "info": ": section in <b>Classes and objects</b>",
    "category": "Heading",
    "url": "/language/classtut#is_required_trait"
  },
  {
    "category": "Heading",
    "url": "/language/classtut#Default_values",
    "value": "Default values",
    "info": ": section in <b>Classes and objects</b>"
  },
  {
    "info": ": section in <b>Classes and objects</b>",
    "url": "/language/classtut#Class_variables",
    "category": "Heading",
    "value": "Class variables"
  },
  {
    "category": "Heading",
    "value": "Methods",
    "info": ": section in <b>Classes and objects</b>",
    "url": "/language/classtut#Methods"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Classes and objects</b>",
    "url": "/language/classtut#Private_methods",
    "value": "Private methods"
  },
  {
    "value": "Construction",
    "url": "/language/classtut#Construction",
    "info": ": section in <b>Classes and objects</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Classes and objects</b>",
    "url": "/language/classtut#bless",
    "value": "bless"
  },
  {
    "value": "TWEAK",
    "info": ": section in <b>Classes and objects</b>",
    "url": "/language/classtut#TWEAK",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Classes and objects</b>",
    "value": "BUILD",
    "url": "/language/classtut#BUILD",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/classtut#Destruction",
    "value": "Destruction",
    "info": ": section in <b>Classes and objects</b>"
  },
  {
    "value": "Consuming our class",
    "info": ": section in <b>Classes and objects</b>",
    "category": "Heading",
    "url": "/language/classtut#Consuming_our_class"
  },
  {
    "info": ": section in <b>Classes and objects</b>",
    "category": "Heading",
    "url": "/language/classtut#A_word_on_types",
    "value": "A word on types"
  },
  {
    "info": ": section in <b>Classes and objects</b>",
    "url": "/language/classtut#Inheritance",
    "category": "Heading",
    "value": "Inheritance"
  },
  {
    "info": ": section in <b>Classes and objects</b>",
    "value": "Overriding inherited methods",
    "category": "Heading",
    "url": "/language/classtut#Overriding_inherited_methods"
  },
  {
    "info": ": section in <b>Classes and objects</b>",
    "value": "Multiple inheritance",
    "category": "Heading",
    "url": "/language/classtut#Multiple_inheritance"
  },
  {
    "info": ": section in <b>Classes and objects</b>",
    "value": "The also declarator",
    "url": "/language/classtut#The_also_declarator",
    "category": "Heading"
  },
  {
    "value": "Introspection",
    "category": "Heading",
    "url": "/language/classtut#Introspection",
    "info": ": section in <b>Classes and objects</b>"
  },
  {
    "category": "Heading",
    "url": "/language/classtut#Overriding_default_gist_method",
    "info": ": section in <b>Classes and objects</b>",
    "value": "Overriding default gist method"
  },
  {
    "url": "/language/classtut#A_practical_introspection_example",
    "category": "Heading",
    "value": "A practical introspection example",
    "info": ": section in <b>Classes and objects</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>role Baggy</b>",
    "url": "/type/Baggy#Methods",
    "value": "Methods"
  },
  {
    "category": "Heading",
    "value": "method new-from-pairs",
    "url": "/type/Baggy#method_new-from-pairs",
    "info": ": section in <b>role Baggy</b>"
  },
  {
    "category": "Heading",
    "value": "method grab",
    "url": "/type/Baggy#method_grab",
    "info": ": section in <b>role Baggy</b>"
  },
  {
    "value": "method grabpairs",
    "category": "Heading",
    "info": ": section in <b>role Baggy</b>",
    "url": "/type/Baggy#method_grabpairs"
  },
  {
    "value": "method pick",
    "info": ": section in <b>role Baggy</b>",
    "category": "Heading",
    "url": "/type/Baggy#method_pick"
  },
  {
    "value": "method pickpairs",
    "category": "Heading",
    "info": ": section in <b>role Baggy</b>",
    "url": "/type/Baggy#method_pickpairs"
  },
  {
    "value": "method roll",
    "info": ": section in <b>role Baggy</b>",
    "category": "Heading",
    "url": "/type/Baggy#method_roll"
  },
  {
    "category": "Heading",
    "value": "method pairs",
    "url": "/type/Baggy#method_pairs",
    "info": ": section in <b>role Baggy</b>"
  },
  {
    "info": ": section in <b>role Baggy</b>",
    "url": "/type/Baggy#method_antipairs",
    "value": "method antipairs",
    "category": "Heading"
  },
  {
    "url": "/type/Baggy#method_invert",
    "value": "method invert",
    "info": ": section in <b>role Baggy</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>role Baggy</b>",
    "value": "method classify-list",
    "url": "/type/Baggy#method_classify-list"
  },
  {
    "info": ": section in <b>role Baggy</b>",
    "value": "method categorize-list",
    "url": "/type/Baggy#method_categorize-list",
    "category": "Heading"
  },
  {
    "info": ": section in <b>role Baggy</b>",
    "value": "method keys",
    "url": "/type/Baggy#method_keys",
    "category": "Heading"
  },
  {
    "info": ": section in <b>role Baggy</b>",
    "category": "Heading",
    "url": "/type/Baggy#method_values",
    "value": "method values"
  },
  {
    "info": ": section in <b>role Baggy</b>",
    "url": "/type/Baggy#method_kv",
    "value": "method kv",
    "category": "Heading"
  },
  {
    "info": ": section in <b>role Baggy</b>",
    "value": "method kxxv",
    "category": "Heading",
    "url": "/type/Baggy#method_kxxv"
  },
  {
    "category": "Heading",
    "value": "method elems",
    "url": "/type/Baggy#method_elems",
    "info": ": section in <b>role Baggy</b>"
  },
  {
    "info": ": section in <b>role Baggy</b>",
    "value": "method total",
    "url": "/type/Baggy#method_total",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "method default",
    "info": ": section in <b>role Baggy</b>",
    "url": "/type/Baggy#method_default"
  },
  {
    "category": "Heading",
    "info": ": section in <b>role Baggy</b>",
    "url": "/type/Baggy#method_hash",
    "value": "method hash"
  },
  {
    "value": "method Bool",
    "url": "/type/Baggy#method_Bool",
    "info": ": section in <b>role Baggy</b>",
    "category": "Heading"
  },
  {
    "value": "method Set",
    "url": "/type/Baggy#method_Set",
    "info": ": section in <b>role Baggy</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/type/Baggy#method_SetHash",
    "value": "method SetHash",
    "info": ": section in <b>role Baggy</b>"
  },
  {
    "url": "/type/Baggy#method_ACCEPTS",
    "value": "method ACCEPTS",
    "info": ": section in <b>role Baggy</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>role Baggy</b>",
    "url": "/type/Baggy#See_Also",
    "value": "See Also",
    "category": "Heading"
  },
  {
    "value": "In language/control",
    "url": "/syntax/start#language/controlsyntaxstart",
    "category": "Heading",
    "info": ": section in <b>start</b>"
  },
  {
    "url": "/syntax/rvalue#language/glossarysyntaxrvalue",
    "info": ": section in <b>rvalue</b>",
    "value": "In language/glossary",
    "category": "Heading"
  },
  {
    "value": "In language/classtut",
    "url": "/syntax/Constructor#language/classtutsyntaxConstructor",
    "info": ": section in <b>Constructor</b>",
    "category": "Heading"
  },
  {
    "value": "In language/variables",
    "url": "/syntax/augment#language/variablessyntaxdeclarator",
    "info": ": section in <b>augment</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In type/Str",
    "url": "/routine/rindex#type/Strroutineroutine",
    "info": ": section in <b>rindex</b>"
  },
  {
    "url": "/routine/rindex#type/Coolroutineroutine",
    "category": "Heading",
    "value": "In type/Cool",
    "info": ": section in <b>rindex</b>"
  },
  {
    "value": "In language/control",
    "info": ": section in <b>while until</b>",
    "url": "/syntax/while%20until#language/controlsyntaxwhile until",
    "category": "Heading"
  },
  {
    "url": "/programs/03-environment-variables#Affecting_execution_from_the_command_line",
    "info": ": section in <b>Environment variables used by the raku command line</b>",
    "value": "Affecting execution from the command line",
    "category": "Heading"
  },
  {
    "url": "/programs/03-environment-variables#Module_loading",
    "info": ": section in <b>Environment variables used by the raku command line</b>",
    "category": "Heading",
    "value": "Module loading"
  },
  {
    "info": ": section in <b>Environment variables used by the raku command line</b>",
    "category": "Heading",
    "url": "/programs/03-environment-variables#Error_message_verbosity_and_strictness",
    "value": "Error message verbosity and strictness"
  },
  {
    "value": "Affecting precompilation",
    "url": "/programs/03-environment-variables#Affecting_precompilation",
    "category": "Heading",
    "info": ": section in <b>Environment variables used by the raku command line</b>"
  },
  {
    "url": "/programs/03-environment-variables#Line_editor",
    "info": ": section in <b>Environment variables used by the raku command line</b>",
    "value": "Line editor",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Environment variables used by the raku command line</b>",
    "value": "Other",
    "url": "/programs/03-environment-variables#Other"
  },
  {
    "category": "Heading",
    "url": "/programs/03-environment-variables#WINDOWS_PECULIARITIES",
    "info": ": section in <b>Environment variables used by the raku command line</b>",
    "value": "WINDOWS PECULIARITIES"
  },
  {
    "url": "/programs/03-environment-variables#Non-console_applications",
    "value": "Non-console applications",
    "category": "Heading",
    "info": ": section in <b>Environment variables used by the raku command line</b>"
  },
  {
    "value": "In language/operators",
    "url": "/routine/%28%26amp%3B%29%2C%20infix%20%E2%88%A9#language/operatorsroutineinfix",
    "category": "Heading",
    "info": ": section in <b>(&), infix ∩</b>"
  },
  {
    "url": "/syntax/Regex%20adverbs#language/regexessyntaxRegex adverbs",
    "category": "Heading",
    "value": "In language/regexes",
    "info": ": section in <b>Regex adverbs</b>"
  },
  {
    "url": "/type/Proc/Async#Methods",
    "category": "Heading",
    "info": ": section in <b>class Proc::Async</b>",
    "value": "Methods"
  },
  {
    "url": "/type/Proc/Async#method_new",
    "category": "Heading",
    "value": "method new",
    "info": ": section in <b>class Proc::Async</b>"
  },
  {
    "value": "method stdout",
    "url": "/type/Proc/Async#method_stdout",
    "category": "Heading",
    "info": ": section in <b>class Proc::Async</b>"
  },
  {
    "url": "/type/Proc/Async#method_stderr",
    "info": ": section in <b>class Proc::Async</b>",
    "category": "Heading",
    "value": "method stderr"
  },
  {
    "info": ": section in <b>class Proc::Async</b>",
    "value": "method bind-stdin",
    "url": "/type/Proc/Async#method_bind-stdin",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Proc::Async</b>",
    "category": "Heading",
    "value": "method bind-stdout",
    "url": "/type/Proc/Async#method_bind-stdout"
  },
  {
    "value": "method bind-stderr",
    "info": ": section in <b>class Proc::Async</b>",
    "category": "Heading",
    "url": "/type/Proc/Async#method_bind-stderr"
  },
  {
    "url": "/type/Proc/Async#method_w",
    "category": "Heading",
    "value": "method w",
    "info": ": section in <b>class Proc::Async</b>"
  },
  {
    "value": "method start",
    "url": "/type/Proc/Async#method_start",
    "category": "Heading",
    "info": ": section in <b>class Proc::Async</b>"
  },
  {
    "value": "method started",
    "info": ": section in <b>class Proc::Async</b>",
    "category": "Heading",
    "url": "/type/Proc/Async#method_started"
  },
  {
    "info": ": section in <b>class Proc::Async</b>",
    "value": "method ready",
    "category": "Heading",
    "url": "/type/Proc/Async#method_ready"
  },
  {
    "url": "/type/Proc/Async#method_pid",
    "category": "Heading",
    "info": ": section in <b>class Proc::Async</b>",
    "value": "method pid"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Proc::Async</b>",
    "value": "method path",
    "url": "/type/Proc/Async#method_path"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Proc::Async</b>",
    "url": "/type/Proc/Async#method_args",
    "value": "method args"
  },
  {
    "info": ": section in <b>class Proc::Async</b>",
    "value": "method command",
    "category": "Heading",
    "url": "/type/Proc/Async#method_command"
  },
  {
    "value": "method write",
    "category": "Heading",
    "url": "/type/Proc/Async#method_write",
    "info": ": section in <b>class Proc::Async</b>"
  },
  {
    "info": ": section in <b>class Proc::Async</b>",
    "value": "method print",
    "url": "/type/Proc/Async#method_print",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Proc::Async</b>",
    "category": "Heading",
    "url": "/type/Proc/Async#method_put",
    "value": "method put"
  },
  {
    "value": "method say",
    "url": "/type/Proc/Async#method_say",
    "info": ": section in <b>class Proc::Async</b>",
    "category": "Heading"
  },
  {
    "value": "method Supply",
    "url": "/type/Proc/Async#method_Supply",
    "info": ": section in <b>class Proc::Async</b>",
    "category": "Heading"
  },
  {
    "value": "method close-stdin",
    "category": "Heading",
    "url": "/type/Proc/Async#method_close-stdin",
    "info": ": section in <b>class Proc::Async</b>"
  },
  {
    "url": "/type/Proc/Async#method_kill",
    "value": "method kill",
    "info": ": section in <b>class Proc::Async</b>",
    "category": "Heading"
  },
  {
    "url": "/routine/ord#type/Strroutineroutine",
    "info": ": section in <b>ord</b>",
    "value": "In type/Str",
    "category": "Heading"
  },
  {
    "info": ": section in <b>ord</b>",
    "value": "In type/Cool",
    "url": "/routine/ord#type/Coolroutineroutine",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>daycount</b>",
    "url": "/routine/daycount#type/Dateishroutinemethod",
    "value": "In type/Dateish"
  },
  {
    "category": "Heading",
    "value": "Scalar structures",
    "url": "/language/structures#Scalar_structures",
    "info": ": section in <b>Data structures</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Data structures</b>",
    "url": "/language/structures#Complex_data_structures",
    "value": "Complex data structures"
  },
  {
    "category": "Heading",
    "url": "/language/structures#Functional_structures",
    "info": ": section in <b>Data structures</b>",
    "value": "Functional structures"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Data structures</b>",
    "url": "/language/structures#Defining_and_constraining_data_structures",
    "value": "Defining and constraining data structures"
  },
  {
    "value": "Infinite structures and laziness",
    "url": "/language/structures#Infinite_structures_and_laziness",
    "category": "Heading",
    "info": ": section in <b>Data structures</b>"
  },
  {
    "url": "/language/structures#Introspection",
    "value": "Introspection",
    "info": ": section in <b>Data structures</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>day</b>",
    "category": "Heading",
    "url": "/routine/day#type/Dateishroutinemethod",
    "value": "In type/Dateish"
  },
  {
    "url": "/syntax/Community#language/glossarysyntaxCommunity",
    "info": ": section in <b>Community</b>",
    "value": "In language/glossary",
    "category": "Heading"
  },
  {
    "url": "/routine/usage-name#type/Parameterroutinemethod",
    "category": "Heading",
    "value": "In type/Parameter",
    "info": ": section in <b>usage-name</b>"
  },
  {
    "info": ": section in <b>SAP</b>",
    "url": "/syntax/SAP#language/glossarysyntaxSAP",
    "category": "Heading",
    "value": "In language/glossary"
  },
  {
    "category": "Heading",
    "url": "/routine/fmt#type/Coolroutinemethod",
    "info": ": section in <b>fmt</b>",
    "value": "In type/Cool"
  },
  {
    "info": ": section in <b>pid</b>",
    "url": "/routine/pid#type/Proc/Asyncroutinemethod",
    "category": "Heading",
    "value": "In type/Proc/Async"
  },
  {
    "category": "Heading",
    "info": ": section in <b>PAST</b>",
    "value": "In language/glossary",
    "url": "/syntax/PAST#language/glossarysyntaxPAST"
  },
  {
    "category": "Heading",
    "info": ": section in <b>given</b>",
    "url": "/syntax/given#language/controlsyntaxgiven",
    "value": "In language/control"
  },
  {
    "info": ": section in <b>pickpairs</b>",
    "url": "/routine/pickpairs#type/Baggyroutinemethod",
    "value": "In type/Baggy",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In language/glossary",
    "info": ": section in <b>Synopsis</b>",
    "url": "/syntax/Synopsis#language/glossarysyntaxSynopsis"
  },
  {
    "category": "Heading",
    "info": ": section in <b>&&</b>",
    "url": "/syntax/%26%26#language/regexessyntax&&",
    "value": "In language/regexes"
  },
  {
    "url": "/routine/match#type/Strroutinemethod",
    "value": "In type/Str",
    "info": ": section in <b>match</b>",
    "category": "Heading"
  },
  {
    "url": "/routine/match#type/Coolroutinemethod",
    "info": ": section in <b>match</b>",
    "category": "Heading",
    "value": "In type/Cool"
  },
  {
    "info": ": section in <b>printf</b>",
    "value": "In type/Cool",
    "category": "Heading",
    "url": "/routine/printf#type/Coolroutinemethod"
  },
  {
    "category": "Heading",
    "url": "/routine/printf#type/independent-routinesroutineroutine",
    "info": ": section in <b>printf</b>",
    "value": "In type/independent-routines"
  },
  {
    "value": "In language/glossary",
    "info": ": section in <b>Parameter</b>",
    "url": "/syntax/Parameter#language/glossarysyntaxParameter",
    "category": "Heading"
  },
  {
    "url": "/routine/copy#type/Parameterroutinemethod",
    "value": "In type/Parameter",
    "category": "Heading",
    "info": ": section in <b>copy</b>"
  },
  {
    "info": ": section in <b>$!</b>",
    "category": "Heading",
    "value": "In language/variables",
    "url": "/syntax/%24%21#language/variablessyntaxvariable"
  },
  {
    "url": "/routine/%26amp%3B%2Achdir#type/independent-routinesroutinesub",
    "info": ": section in <b>&*chdir</b>",
    "category": "Heading",
    "value": "In type/independent-routines"
  },
  {
    "url": "/routine/comb#type/Strroutineroutine",
    "info": ": section in <b>comb</b>",
    "value": "In type/Str",
    "category": "Heading"
  },
  {
    "value": "In type/Cool",
    "info": ": section in <b>comb</b>",
    "category": "Heading",
    "url": "/routine/comb#type/Coolroutineroutine"
  },
  {
    "info": ": section in <b>min</b>",
    "url": "/routine/min#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Signature</b>",
    "url": "/type/Signature#Methods",
    "value": "Methods"
  },
  {
    "value": "method params",
    "info": ": section in <b>class Signature</b>",
    "url": "/type/Signature#method_params",
    "category": "Heading"
  },
  {
    "value": "method arity",
    "info": ": section in <b>class Signature</b>",
    "url": "/type/Signature#method_arity",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Signature</b>",
    "value": "method count",
    "category": "Heading",
    "url": "/type/Signature#method_count"
  },
  {
    "category": "Heading",
    "url": "/type/Signature#method_returns",
    "value": "method returns",
    "info": ": section in <b>class Signature</b>"
  },
  {
    "value": "method ACCEPTS",
    "info": ": section in <b>class Signature</b>",
    "category": "Heading",
    "url": "/type/Signature#method_ACCEPTS"
  },
  {
    "value": "method Capture",
    "url": "/type/Signature#method_Capture",
    "info": ": section in <b>class Signature</b>",
    "category": "Heading"
  },
  {
    "url": "/type/Signature#Runtime_creation_of_Signature_objects_(6.d,_2019.03_and_later)",
    "info": ": section in <b>class Signature</b>",
    "category": "Heading",
    "value": "Runtime creation of Signature objects (6.d, 2019.03 and later)"
  },
  {
    "info": ": section in <b>Numeric</b>",
    "value": "In type/Str",
    "url": "/routine/Numeric#type/Strroutinemethod",
    "category": "Heading"
  },
  {
    "url": "/routine/gcd#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>gcd</b>"
  },
  {
    "value": "In language/5to6-perlvar",
    "url": "/syntax/%40INC%20%28Perl%29#language/5to6-perlvarsyntax@INC (Perl)",
    "category": "Heading",
    "info": ": section in <b>@INC (Perl)</b>"
  },
  {
    "category": "Heading",
    "url": "/syntax/STD#language/glossarysyntaxSTD",
    "value": "In language/glossary",
    "info": ": section in <b>STD</b>"
  },
  {
    "url": "/routine/acotan#type/Coolroutineroutine",
    "category": "Heading",
    "info": ": section in <b>acotan</b>",
    "value": "In type/Cool"
  },
  {
    "info": ": section in <b><:property></b>",
    "url": "/syntax/%3C%3Aproperty%3E#language/regexessyntax<:property>",
    "category": "Heading",
    "value": "In language/regexes"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>&</b>",
    "url": "/routine/%26amp%3B#language/operatorsroutineinfix"
  },
  {
    "value": "In type/Baggy",
    "url": "/routine/pick#type/Baggyroutinemethod",
    "info": ": section in <b>pick</b>",
    "category": "Heading"
  },
  {
    "url": "/routine/name#type/Parameterroutinemethod",
    "value": "In type/Parameter",
    "category": "Heading",
    "info": ": section in <b>name</b>"
  },
  {
    "value": "In type/Attribute",
    "category": "Heading",
    "url": "/routine/name#type/Attributeroutinemethod",
    "info": ": section in <b>name</b>"
  },
  {
    "url": "/routine/repl#type/independent-routinesroutinesub",
    "category": "Heading",
    "value": "In type/independent-routines",
    "info": ": section in <b>repl</b>"
  },
  {
    "url": "/routine/%26lt%3B%3D%26gt%3B#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b><=></b>"
  },
  {
    "info": ": section in <b>my</b>",
    "value": "In type/CallFrame",
    "url": "/routine/my#type/CallFrameroutinemethod",
    "category": "Heading"
  },
  {
    "url": "/routine/kxxv#type/Baggyroutinemethod",
    "info": ": section in <b>kxxv</b>",
    "value": "In type/Baggy",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>coll</b>",
    "url": "/routine/coll#language/operatorsroutineinfix",
    "value": "In language/operators"
  },
  {
    "category": "Heading",
    "url": "/routine/antipairs#type/Baggyroutinemethod",
    "value": "In type/Baggy",
    "info": ": section in <b>antipairs</b>"
  },
  {
    "value": "In type/Parameter",
    "category": "Heading",
    "info": ": section in <b>sigil</b>",
    "url": "/routine/sigil#type/Parameterroutinemethod"
  },
  {
    "url": "/routine/sin#type/Coolroutineroutine",
    "info": ": section in <b>sin</b>",
    "category": "Heading",
    "value": "In type/Cool"
  },
  {
    "url": "/syntax/%7C#language/regexessyntax|",
    "info": ": section in <b>|</b>",
    "category": "Heading",
    "value": "In language/regexes"
  },
  {
    "url": "/syntax/Argument#language/functionssyntaxArgument",
    "category": "Heading",
    "info": ": section in <b>Argument</b>",
    "value": "In language/functions"
  },
  {
    "url": "/routine/words#type/Strroutineroutine",
    "category": "Heading",
    "info": ": section in <b>words</b>",
    "value": "In type/Str"
  },
  {
    "url": "/routine/words#type/Coolroutinemethod",
    "info": ": section in <b>words</b>",
    "category": "Heading",
    "value": "In type/Cool"
  },
  {
    "value": "In language/operators",
    "url": "/syntax/S#language/operatorssyntaxS",
    "category": "Heading",
    "info": ": section in <b>S</b>"
  },
  {
    "value": "In language/operators",
    "url": "/routine/ff#language/operatorsroutineinfix",
    "category": "Heading",
    "info": ": section in <b>ff</b>"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>~</b>",
    "url": "/routine/~#language/operatorsroutineprefix"
  },
  {
    "info": ": section in <b>~</b>",
    "url": "/routine/~#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "url": "/syntax/R#language/operatorssyntaxR",
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>R</b>"
  },
  {
    "category": "Heading",
    "url": "/routine/shift#type/independent-routinesroutinesub",
    "info": ": section in <b>shift</b>",
    "value": "In type/independent-routines"
  },
  {
    "info": ": section in <b>FQN</b>",
    "url": "/syntax/FQN#language/classtutsyntaxFQN",
    "value": "In language/classtut",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/syntax/%5Cs#language/regexessyntax%5Cs",
    "info": ": section in <b>\\s</b>",
    "value": "In language/regexes"
  },
  {
    "info": ": section in <b>is default (Attribute)</b>",
    "url": "/syntax/is%20default%20%28Attribute%29#type/Attributesyntaxis default (Attribute)",
    "category": "Heading",
    "value": "In type/Attribute"
  },
  {
    "value": "NAME",
    "url": "/programs/04-running-raku#NAME",
    "category": "Heading",
    "info": ": section in <b>Running Raku</b>"
  },
  {
    "value": "SYNOPSIS",
    "url": "/programs/04-running-raku#SYNOPSIS",
    "info": ": section in <b>Running Raku</b>",
    "category": "Heading"
  },
  {
    "url": "/programs/04-running-raku#DESCRIPTION",
    "value": "DESCRIPTION",
    "info": ": section in <b>Running Raku</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>say</b>",
    "url": "/routine/say#type/Proc/Asyncroutinemethod",
    "category": "Heading",
    "value": "In type/Proc/Async"
  },
  {
    "category": "Heading",
    "info": ": section in <b>say</b>",
    "value": "In type/independent-routines",
    "url": "/routine/say#type/independent-routinesroutinesub"
  },
  {
    "value": "In type/Baggy",
    "info": ": section in <b>values</b>",
    "url": "/routine/values#type/Baggyroutinemethod",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>stderr</b>",
    "url": "/routine/stderr#type/Proc/Asyncroutinemethod",
    "value": "In type/Proc/Async"
  },
  {
    "info": ": section in <b>?</b>",
    "value": "In language/operators",
    "url": "/routine/%3F#language/operatorsroutineprefix",
    "category": "Heading"
  },
  {
    "value": "In type/Cool",
    "category": "Heading",
    "url": "/routine/truncate#type/Coolroutineroutine",
    "info": ": section in <b>truncate</b>"
  },
  {
    "info": ": section in <b>if</b>",
    "category": "Heading",
    "value": "In language/control",
    "url": "/syntax/if#language/controlsyntaxif"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "value": "Methods",
    "category": "Heading",
    "url": "/type/Cool#Methods"
  },
  {
    "url": "/type/Cool#routine_abs",
    "value": "routine abs",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "value": "method conj",
    "url": "/type/Cool#method_conj",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#method_EVAL",
    "value": "method EVAL",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "value": "routine sqrt",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_sqrt"
  },
  {
    "category": "Heading",
    "value": "method sign",
    "url": "/type/Cool#method_sign",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "url": "/type/Cool#method_rand",
    "category": "Heading",
    "value": "method rand",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "value": "routine sin",
    "url": "/type/Cool#routine_sin",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading"
  },
  {
    "url": "/type/Cool#routine_asin",
    "info": ": section in <b>class Cool</b>",
    "value": "routine asin",
    "category": "Heading"
  },
  {
    "value": "routine cos",
    "url": "/type/Cool#routine_cos",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "value": "routine acos",
    "category": "Heading",
    "url": "/type/Cool#routine_acos",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "url": "/type/Cool#routine_tan",
    "value": "routine tan"
  },
  {
    "value": "routine atan",
    "url": "/type/Cool#routine_atan",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "value": "routine atan2",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_atan2"
  },
  {
    "category": "Heading",
    "value": "routine sec",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_sec"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_asec",
    "category": "Heading",
    "value": "routine asec"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "url": "/type/Cool#routine_cosec",
    "value": "routine cosec"
  },
  {
    "url": "/type/Cool#routine_acosec",
    "category": "Heading",
    "value": "routine acosec",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "url": "/type/Cool#routine_cotan",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "value": "routine cotan"
  },
  {
    "url": "/type/Cool#routine_acotan",
    "info": ": section in <b>class Cool</b>",
    "value": "routine acotan",
    "category": "Heading"
  },
  {
    "url": "/type/Cool#routine_sinh",
    "category": "Heading",
    "value": "routine sinh",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#routine_asinh",
    "value": "routine asinh",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "value": "routine cosh",
    "url": "/type/Cool#routine_cosh"
  },
  {
    "value": "routine acosh",
    "url": "/type/Cool#routine_acosh",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "value": "routine tanh",
    "category": "Heading",
    "url": "/type/Cool#routine_tanh"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_atanh",
    "value": "routine atanh",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "routine sech",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_sech"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "url": "/type/Cool#routine_asech",
    "value": "routine asech"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#routine_cosech",
    "info": ": section in <b>class Cool</b>",
    "value": "routine cosech"
  },
  {
    "category": "Heading",
    "value": "routine acosech",
    "url": "/type/Cool#routine_acosech",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "url": "/type/Cool#routine_cotanh",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "value": "routine cotanh"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "value": "routine acotanh",
    "url": "/type/Cool#routine_acotanh",
    "category": "Heading"
  },
  {
    "value": "routine cis",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "url": "/type/Cool#routine_cis"
  },
  {
    "category": "Heading",
    "value": "routine log",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_log"
  },
  {
    "url": "/type/Cool#routine_log10",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "value": "routine log10"
  },
  {
    "value": "routine log2",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_log2"
  },
  {
    "value": "routine exp",
    "url": "/type/Cool#routine_exp",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading"
  },
  {
    "url": "/type/Cool#method_unpolar",
    "info": ": section in <b>class Cool</b>",
    "value": "method unpolar",
    "category": "Heading"
  },
  {
    "value": "routine round",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_round",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_floor",
    "value": "routine floor",
    "category": "Heading"
  },
  {
    "url": "/type/Cool#method_fmt",
    "value": "method fmt",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "value": "routine ceiling",
    "category": "Heading",
    "url": "/type/Cool#routine_ceiling",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "url": "/type/Cool#routine_truncate",
    "value": "routine truncate",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "value": "routine ord",
    "url": "/type/Cool#routine_ord",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#method_path",
    "category": "Heading",
    "value": "method path"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#routine_chr",
    "value": "routine chr",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "url": "/type/Cool#routine_chars",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "value": "routine chars"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_codes",
    "value": "routine codes",
    "category": "Heading"
  },
  {
    "value": "routine flip",
    "category": "Heading",
    "url": "/type/Cool#routine_flip",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_trim",
    "category": "Heading",
    "value": "routine trim"
  },
  {
    "category": "Heading",
    "value": "routine trim-leading",
    "url": "/type/Cool#routine_trim-leading",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "value": "routine trim-trailing",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "url": "/type/Cool#routine_trim-trailing"
  },
  {
    "category": "Heading",
    "value": "routine lc",
    "url": "/type/Cool#routine_lc",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "url": "/type/Cool#routine_uc",
    "info": ": section in <b>class Cool</b>",
    "value": "routine uc",
    "category": "Heading"
  },
  {
    "value": "routine fc",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_fc",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#routine_tc",
    "value": "routine tc",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "category": "Heading",
    "value": "routine tclc",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_tclc"
  },
  {
    "value": "routine wordcase",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_wordcase"
  },
  {
    "url": "/type/Cool#routine_samecase",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "value": "routine samecase"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "value": "routine uniprop",
    "url": "/type/Cool#routine_uniprop",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#sub_uniprops",
    "value": "sub uniprops",
    "category": "Heading"
  },
  {
    "value": "routine uniname",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_uniname"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#routine_uninames",
    "info": ": section in <b>class Cool</b>",
    "value": "routine uninames"
  },
  {
    "value": "routine unimatch",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_unimatch"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "value": "routine chop",
    "category": "Heading",
    "url": "/type/Cool#routine_chop"
  },
  {
    "url": "/type/Cool#routine_chomp",
    "value": "routine chomp",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "value": "routine substr",
    "category": "Heading",
    "url": "/type/Cool#routine_substr"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_substr-rw",
    "value": "routine substr-rw"
  },
  {
    "value": "routine ords",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_ords",
    "category": "Heading"
  },
  {
    "url": "/type/Cool#routine_chrs",
    "value": "routine chrs",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading"
  },
  {
    "url": "/type/Cool#routine_split",
    "category": "Heading",
    "value": "routine split",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_lines",
    "category": "Heading",
    "value": "routine lines"
  },
  {
    "value": "method words",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#method_words"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "url": "/type/Cool#routine_comb",
    "value": "routine comb"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#method_contains",
    "value": "method contains",
    "category": "Heading"
  },
  {
    "value": "routine index",
    "url": "/type/Cool#routine_index",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading"
  },
  {
    "value": "routine rindex",
    "category": "Heading",
    "info": ": section in <b>class Cool</b>",
    "url": "/type/Cool#routine_rindex"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "value": "method match",
    "category": "Heading",
    "url": "/type/Cool#method_match"
  },
  {
    "value": "routine roots",
    "category": "Heading",
    "url": "/type/Cool#routine_roots",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#method_subst",
    "value": "method subst",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "category": "Heading",
    "value": "method trans",
    "url": "/type/Cool#method_trans",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "value": "method IO",
    "url": "/type/Cool#method_IO",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "method sprintf",
    "url": "/type/Cool#method_sprintf",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "url": "/type/Cool#method_printf",
    "info": ": section in <b>class Cool</b>",
    "value": "method printf",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#method_Complex",
    "info": ": section in <b>class Cool</b>",
    "value": "method Complex"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "url": "/type/Cool#method_FatRat",
    "value": "method FatRat"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#method_Int",
    "info": ": section in <b>class Cool</b>",
    "value": "method Int"
  },
  {
    "value": "method Num",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "url": "/type/Cool#method_Num"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#method_Rat",
    "info": ": section in <b>class Cool</b>",
    "value": "method Rat"
  },
  {
    "value": "method Real",
    "category": "Heading",
    "url": "/type/Cool#method_Real",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "value": "method UInt",
    "info": ": section in <b>class Cool</b>",
    "category": "Heading",
    "url": "/type/Cool#method_UInt"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#method_uniparse",
    "info": ": section in <b>class Cool</b>",
    "value": "method uniparse"
  },
  {
    "category": "Heading",
    "url": "/type/Cool#method_Order",
    "value": "method Order",
    "info": ": section in <b>class Cool</b>"
  },
  {
    "info": ": section in <b>class Cool</b>",
    "value": "method Failure",
    "category": "Heading",
    "url": "/type/Cool#method_Failure"
  },
  {
    "info": ": section in <b>print</b>",
    "url": "/routine/print#type/Proc/Asyncroutinemethod",
    "category": "Heading",
    "value": "In type/Proc/Async"
  },
  {
    "category": "Heading",
    "info": ": section in <b>print</b>",
    "url": "/routine/print#type/independent-routinesroutinesub",
    "value": "In type/independent-routines"
  },
  {
    "info": ": section in <b>Mainline</b>",
    "value": "In language/glossary",
    "url": "/syntax/Mainline#language/glossarysyntaxMainline",
    "category": "Heading"
  },
  {
    "value": "In language/glossary",
    "url": "/syntax/RHS#language/glossarysyntaxRHS",
    "category": "Heading",
    "info": ": section in <b>RHS</b>"
  },
  {
    "info": ": section in <b>substr-eq</b>",
    "value": "In type/Str",
    "category": "Heading",
    "url": "/routine/substr-eq#type/Strroutinemethod"
  },
  {
    "value": "In language/control",
    "category": "Heading",
    "info": ": section in <b>supply emit</b>",
    "url": "/syntax/supply%20emit#language/controlsyntaxsupply emit"
  },
  {
    "info": ": section in <b>tclc</b>",
    "category": "Heading",
    "url": "/routine/tclc#type/Strroutineroutine",
    "value": "In type/Str"
  },
  {
    "value": "In type/Cool",
    "category": "Heading",
    "url": "/routine/tclc#type/Coolroutineroutine",
    "info": ": section in <b>tclc</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>fiddly</b>",
    "value": "In language/glossary",
    "url": "/syntax/fiddly#language/glossarysyntaxfiddly"
  },
  {
    "category": "Heading",
    "url": "/routine/keys#type/Baggyroutinemethod",
    "info": ": section in <b>keys</b>",
    "value": "In type/Baggy"
  },
  {
    "info": ": section in <b>Mayspec</b>",
    "value": "In language/glossary",
    "category": "Heading",
    "url": "/syntax/Mayspec#language/glossarysyntaxMayspec"
  },
  {
    "value": "In type/Int",
    "url": "/routine/Bridge#type/Introutinemethod",
    "category": "Heading",
    "info": ": section in <b>Bridge</b>"
  },
  {
    "value": "In language/glossary",
    "category": "Heading",
    "info": ": section in <b>Variable</b>",
    "url": "/syntax/Variable#language/glossarysyntaxVariable"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Range</b>",
    "value": "In type/Int",
    "url": "/routine/Range#type/Introutinemethod"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class</b>",
    "url": "/syntax/class#language/classtutsyntaxclass",
    "value": "In language/classtut"
  },
  {
    "url": "/syntax/class#language/objectssyntaxclass",
    "value": "In language/objects",
    "info": ": section in <b>class</b>",
    "category": "Heading"
  },
  {
    "value": "In language/variables",
    "info": ": section in <b>has</b>",
    "url": "/syntax/has#language/variablessyntaxdeclarator",
    "category": "Heading"
  },
  {
    "url": "/syntax/%3Asamemark#language/regexessyntax:samemark",
    "value": "In language/regexes",
    "category": "Heading",
    "info": ": section in <b>:samemark</b>"
  },
  {
    "category": "Heading",
    "url": "/language/pod-v2#Block_structure",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "value": "Block structure"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading",
    "value": "Delimited blocks",
    "url": "/language/pod-v2#Delimited_blocks"
  },
  {
    "category": "Heading",
    "value": "Configuration information",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Configuration_information"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading",
    "value": "Standard configuration options",
    "url": "/language/pod-v2#Standard_configuration_options"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Block_pre-configuration",
    "value": "Block pre-configuration"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Paragraph_blocks",
    "value": "Paragraph blocks",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Abbreviated blocks",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Abbreviated_blocks"
  },
  {
    "url": "/language/pod-v2#Declarator_blocks",
    "value": "Declarator blocks",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "value": "Block types",
    "url": "/language/pod-v2#Block_types",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "url": "/language/pod-v2#Headings",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "value": "Headings",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Numbered_headings",
    "value": "Numbered headings"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Ordinary_paragraphs",
    "value": "Ordinary paragraphs"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading",
    "value": "Code blocks",
    "url": "/language/pod-v2#Code_blocks"
  },
  {
    "value": "Formatting within code blocks",
    "category": "Heading",
    "url": "/language/pod-v2#Formatting_within_code_blocks",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "url": "/language/pod-v2#I/O_blocks",
    "value": "I/O blocks",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading"
  },
  {
    "value": "Lists",
    "url": "/language/pod-v2#Lists",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "url": "/language/pod-v2#Unordered_lists",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "value": "Unordered lists"
  },
  {
    "url": "/language/pod-v2#Ordered_lists",
    "value": "Ordered lists",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "url": "/language/pod-v2#Definition_lists",
    "category": "Heading",
    "value": "Definition lists",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading",
    "url": "/language/pod-v2#Multi-level_lists",
    "value": "Multi-level lists"
  },
  {
    "url": "/language/pod-v2#Multi-paragraph_lists",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading",
    "value": "Multi-paragraph lists"
  },
  {
    "value": "Nested blocks",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Nested_blocks",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Tables",
    "value": "Tables",
    "category": "Heading"
  },
  {
    "value": "Rakudoc comments",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Rakudoc_comments",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Semantic blocks",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Semantic_blocks"
  },
  {
    "category": "Heading",
    "value": "Formatting codes",
    "url": "/language/pod-v2#Formatting_codes",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "url": "/language/pod-v2#Bold",
    "category": "Heading",
    "value": "Bold",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading",
    "url": "/language/pod-v2#Italic",
    "value": "Italic"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading",
    "value": "Underlined",
    "url": "/language/pod-v2#Underlined"
  },
  {
    "value": "Code",
    "category": "Heading",
    "url": "/language/pod-v2#Code",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "value": "Links",
    "url": "/language/pod-v2#Links",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "url": "/language/pod-v2#Placement_links",
    "value": "Placement links",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "value": "Comments",
    "category": "Heading",
    "url": "/language/pod-v2#Comments",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "url": "/language/pod-v2#Notes",
    "value": "Notes",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading"
  },
  {
    "url": "/language/pod-v2#Keyboard_input",
    "value": "Keyboard input",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading"
  },
  {
    "url": "/language/pod-v2#Replaceable",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "value": "Replaceable",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "value": "Terminal output",
    "url": "/language/pod-v2#Terminal_output"
  },
  {
    "url": "/language/pod-v2#Unicode",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "value": "Unicode"
  },
  {
    "value": "Verbatim text",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading",
    "url": "/language/pod-v2#Verbatim_text"
  },
  {
    "value": "Indexing terms",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading",
    "url": "/language/pod-v2#Indexing_terms"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Accessing_Pod",
    "value": "Accessing Pod",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading",
    "url": "/language/pod-v2#Rendering_Rakudoc",
    "value": "Rendering Rakudoc"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "category": "Heading",
    "value": "Pod::To::Text",
    "url": "/language/pod-v2#Pod::To::Text"
  },
  {
    "value": "Pod::To::HTML",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Pod::To::HTML"
  },
  {
    "url": "/language/pod-v2#Raku::Pod::Render",
    "value": "Raku::Pod::Render",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "category": "Heading",
    "value": "Metadata available to all blocks",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Metadata_available_to_all_blocks"
  },
  {
    "category": "Heading",
    "url": "/language/pod-v2#Outermost_pod_configuration",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "value": "Outermost pod configuration"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "value": "Examples of Custom blocks",
    "category": "Heading",
    "url": "/language/pod-v2#Examples_of_Custom_blocks"
  },
  {
    "value": "Colourful line breaks",
    "url": "/language/pod-v2#Colourful_line_breaks",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "value": "Adding new templates for existing Pod::Blocks",
    "category": "Heading",
    "url": "/language/pod-v2#Adding_new_templates_for_existing_Pod::Blocks",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "value": "FontAwesome icons",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#FontAwesome_icons",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Graphviz",
    "value": "Graphviz",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "url": "/language/pod-v2#Digraph_g_{_main_->_parse_->_execute;_main_->_init;_main_->_cleanup;_execute_->_make_string;_execute_->_printf_init_->_make_string;_main_->_printf;_execute_->_compare;_}",
    "category": "Heading",
    "value": "Digraph g { main -> parse -> execute; main -> init; main -> cleanup; execute -> make_string; execute -> printf init -> make_string; main -> printf; execute -> compare; }"
  },
  {
    "value": "Latex",
    "url": "/language/pod-v2#Latex",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>"
  },
  {
    "url": "/language/pod-v2#Markdown",
    "category": "Heading",
    "info": ": section in <b>Rakudoc - formerly POD6</b>",
    "value": "Markdown"
  },
  {
    "url": "/routine/%2A%2A#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>**</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>o, infix ∘</b>",
    "url": "/routine/o%2C%20infix%20%E2%88%98#language/operatorsroutineinfix"
  },
  {
    "category": "Heading",
    "info": ": section in <b>tan</b>",
    "value": "In type/Cool",
    "url": "/routine/tan#type/Coolroutineroutine"
  },
  {
    "info": ": section in <b>shell</b>",
    "value": "In type/independent-routines",
    "category": "Heading",
    "url": "/routine/shell#type/independent-routinesroutinesub"
  },
  {
    "value": "In type/independent-routines",
    "info": ": section in <b>open</b>",
    "url": "/routine/open#type/independent-routinesroutinesub",
    "category": "Heading"
  },
  {
    "url": "/syntax/positive%20lookaround%20assertion%20%3C%3F%3E#language/regexessyntaxpositive lookaround assertion <%3F>",
    "category": "Heading",
    "info": ": section in <b>positive lookaround assertion <?></b>",
    "value": "In language/regexes"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Num</b>",
    "url": "/routine/Num#type/Strroutinemethod",
    "value": "In type/Str"
  },
  {
    "category": "Heading",
    "value": "In type/Cool",
    "info": ": section in <b>Num</b>",
    "url": "/routine/Num#type/Coolroutinemethod"
  },
  {
    "url": "/routine/Z#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>Z</b>"
  },
  {
    "value": "In language/glossary",
    "url": "/syntax/Parse%20Tree#language/glossarysyntaxParse Tree",
    "info": ": section in <b>Parse Tree</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In language/glossary",
    "info": ": section in <b>Interface</b>",
    "url": "/syntax/Interface#language/glossarysyntaxInterface"
  },
  {
    "url": "/syntax/IRC%20lingo#language/glossarysyntaxIRC lingo",
    "value": "In language/glossary",
    "info": ": section in <b>IRC lingo</b>",
    "category": "Heading"
  },
  {
    "value": "In language/glossary",
    "category": "Heading",
    "url": "/syntax/decont#language/glossarysyntaxdecont",
    "info": ": section in <b>decont</b>"
  },
  {
    "category": "Heading",
    "url": "/syntax/%3Asamespace#language/regexessyntax:samespace",
    "info": ": section in <b>:samespace</b>",
    "value": "In language/regexes"
  },
  {
    "info": ": section in <b>for</b>",
    "url": "/syntax/for#language/controlsyntaxfor",
    "value": "In language/control",
    "category": "Heading"
  },
  {
    "url": "/routine/%3D%3D%2C%20infix%20%E2%A9%B5#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>==, infix ⩵</b>"
  },
  {
    "url": "/syntax/LHS#language/glossarysyntaxLHS",
    "info": ": section in <b>LHS</b>",
    "value": "In language/glossary",
    "category": "Heading"
  },
  {
    "info": ": section in <b>conj</b>",
    "url": "/routine/conj#type/Coolroutinemethod",
    "value": "In type/Cool",
    "category": "Heading"
  },
  {
    "value": "In type/Str",
    "info": ": section in <b>unival</b>",
    "category": "Heading",
    "url": "/routine/unival#type/Strroutinemethod"
  },
  {
    "value": "In type/Int",
    "category": "Heading",
    "info": ": section in <b>unival</b>",
    "url": "/routine/unival#type/Introutineroutine"
  },
  {
    "url": "/syntax/multi#language/functionssyntaxmulti",
    "value": "In language/functions",
    "category": "Heading",
    "info": ": section in <b>multi</b>"
  },
  {
    "url": "/routine/univals#type/Strroutinemethod",
    "value": "In type/Str",
    "category": "Heading",
    "info": ": section in <b>univals</b>"
  },
  {
    "url": "/routine/%5E..#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>^..</b>"
  },
  {
    "category": "Heading",
    "value": "In language/nativecall",
    "url": "/routine/nativecast#language/nativecallroutinesub",
    "info": ": section in <b>nativecast</b>"
  },
  {
    "info": ": section in <b>@_</b>",
    "value": "In language/functions",
    "category": "Heading",
    "url": "/syntax/%40_#language/functionssyntax@_"
  },
  {
    "info": ": section in <b>exp</b>",
    "category": "Heading",
    "value": "In type/Cool",
    "url": "/routine/exp#type/Coolroutineroutine"
  },
  {
    "info": ": section in <b>*</b>",
    "category": "Heading",
    "url": "/syntax/%2A#language/regexessyntax*",
    "value": "In language/regexes"
  },
  {
    "value": "Int",
    "info": ": section in <b>Numerics</b>",
    "url": "/language/numerics#Int",
    "category": "Heading"
  },
  {
    "value": "Num",
    "url": "/language/numerics#Num",
    "info": ": section in <b>Numerics</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Numerics</b>",
    "url": "/language/numerics#Complex",
    "value": "Complex",
    "category": "Heading"
  },
  {
    "value": "Rational",
    "category": "Heading",
    "url": "/language/numerics#Rational",
    "info": ": section in <b>Numerics</b>"
  },
  {
    "value": "Rat",
    "url": "/language/numerics#Rat",
    "category": "Heading",
    "info": ": section in <b>Numerics</b>"
  },
  {
    "category": "Heading",
    "url": "/language/numerics#Degradation_to_Num",
    "value": "Degradation to Num",
    "info": ": section in <b>Numerics</b>"
  },
  {
    "value": "FatRat",
    "info": ": section in <b>Numerics</b>",
    "category": "Heading",
    "url": "/language/numerics#FatRat"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Numerics</b>",
    "url": "/language/numerics#Printing_rationals",
    "value": "Printing rationals"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Numerics</b>",
    "value": "Division by zero",
    "url": "/language/numerics#Division_by_zero"
  },
  {
    "info": ": section in <b>Numerics</b>",
    "value": "Zero-denominator rationals",
    "url": "/language/numerics#Zero-denominator_rationals",
    "category": "Heading"
  },
  {
    "url": "/language/numerics#Allomorphs",
    "info": ": section in <b>Numerics</b>",
    "value": "Allomorphs",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Numerics</b>",
    "url": "/language/numerics#Available_allomorphs",
    "value": "Available allomorphs"
  },
  {
    "value": "Coercion of allomorphs",
    "category": "Heading",
    "url": "/language/numerics#Coercion_of_allomorphs",
    "info": ": section in <b>Numerics</b>"
  },
  {
    "url": "/language/numerics#Object_identity",
    "value": "Object identity",
    "category": "Heading",
    "info": ": section in <b>Numerics</b>"
  },
  {
    "category": "Heading",
    "url": "/language/numerics#Native_numerics",
    "value": "Native numerics",
    "info": ": section in <b>Numerics</b>"
  },
  {
    "category": "Heading",
    "url": "/language/numerics#Available_native_numerics",
    "info": ": section in <b>Numerics</b>",
    "value": "Available native numerics"
  },
  {
    "info": ": section in <b>Numerics</b>",
    "category": "Heading",
    "value": "Creating native numerics",
    "url": "/language/numerics#Creating_native_numerics"
  },
  {
    "info": ": section in <b>Numerics</b>",
    "value": "Overflow/Underflow",
    "category": "Heading",
    "url": "/language/numerics#Overflow/Underflow"
  },
  {
    "url": "/language/numerics#Auto-boxing",
    "value": "Auto-boxing",
    "category": "Heading",
    "info": ": section in <b>Numerics</b>"
  },
  {
    "url": "/language/numerics#Default_values",
    "info": ": section in <b>Numerics</b>",
    "value": "Default values",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Native dispatch",
    "info": ": section in <b>Numerics</b>",
    "url": "/language/numerics#Native_dispatch"
  },
  {
    "category": "Heading",
    "url": "/language/numerics#Atomic_operations",
    "info": ": section in <b>Numerics</b>",
    "value": "Atomic operations"
  },
  {
    "url": "/language/numerics#Numeric_infectiousness",
    "info": ": section in <b>Numerics</b>",
    "category": "Heading",
    "value": "Numeric infectiousness"
  },
  {
    "url": "/routine/%26lt%3B#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b><</b>",
    "category": "Heading"
  },
  {
    "url": "/syntax/nextwith#language/functionssyntaxnextwith",
    "category": "Heading",
    "info": ": section in <b>nextwith</b>",
    "value": "In language/functions"
  },
  {
    "url": "/routine/%28elem%29%2C%20infix%20%E2%88%88#language/operatorsroutineinfix",
    "info": ": section in <b>(elem), infix ∈</b>",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>+^</b>",
    "url": "/routine/%2B%5E#language/operatorsroutineprefix"
  },
  {
    "category": "Heading",
    "info": ": section in <b>+^</b>",
    "url": "/routine/%2B%5E#language/operatorsroutineinfix",
    "value": "In language/operators"
  },
  {
    "info": ": section in <b>atan2</b>",
    "category": "Heading",
    "url": "/routine/atan2#type/Coolroutineroutine",
    "value": "In type/Cool"
  },
  {
    "url": "/routine/%2B%26gt%3B#language/operatorsroutineinfix",
    "info": ": section in <b>+></b>",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "info": ": section in <b>close-stdin</b>",
    "url": "/routine/close-stdin#type/Proc/Asyncroutinemethod",
    "value": "In type/Proc/Async",
    "category": "Heading"
  },
  {
    "value": "Traits",
    "category": "Heading",
    "info": ": section in <b>class Attribute</b>",
    "url": "/type/Attribute#Traits"
  },
  {
    "category": "Heading",
    "url": "/type/Attribute#Trait_is_default",
    "value": "Trait is default",
    "info": ": section in <b>class Attribute</b>"
  },
  {
    "info": ": section in <b>class Attribute</b>",
    "category": "Heading",
    "value": "Trait is required",
    "url": "/type/Attribute#Trait_is_required"
  },
  {
    "category": "Heading",
    "value": "trait is DEPRECATED",
    "info": ": section in <b>class Attribute</b>",
    "url": "/type/Attribute#trait_is_DEPRECATED"
  },
  {
    "info": ": section in <b>class Attribute</b>",
    "value": "trait is rw",
    "url": "/type/Attribute#trait_is_rw",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "trait is built",
    "url": "/type/Attribute#trait_is_built",
    "info": ": section in <b>class Attribute</b>"
  },
  {
    "category": "Heading",
    "url": "/type/Attribute#Methods",
    "value": "Methods",
    "info": ": section in <b>class Attribute</b>"
  },
  {
    "value": "method name",
    "info": ": section in <b>class Attribute</b>",
    "url": "/type/Attribute#method_name",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Attribute</b>",
    "category": "Heading",
    "value": "method package",
    "url": "/type/Attribute#method_package"
  },
  {
    "info": ": section in <b>class Attribute</b>",
    "url": "/type/Attribute#method_has_accessor",
    "value": "method has_accessor",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Attribute</b>",
    "value": "method rw",
    "url": "/type/Attribute#method_rw",
    "category": "Heading"
  },
  {
    "value": "method readonly",
    "url": "/type/Attribute#method_readonly",
    "category": "Heading",
    "info": ": section in <b>class Attribute</b>"
  },
  {
    "category": "Heading",
    "url": "/type/Attribute#method_required",
    "info": ": section in <b>class Attribute</b>",
    "value": "method required"
  },
  {
    "value": "method type",
    "category": "Heading",
    "url": "/type/Attribute#method_type",
    "info": ": section in <b>class Attribute</b>"
  },
  {
    "url": "/type/Attribute#method_get_value",
    "category": "Heading",
    "info": ": section in <b>class Attribute</b>",
    "value": "method get_value"
  },
  {
    "value": "method set_value",
    "url": "/type/Attribute#method_set_value",
    "category": "Heading",
    "info": ": section in <b>class Attribute</b>"
  },
  {
    "category": "Heading",
    "url": "/type/Attribute#method_gist",
    "info": ": section in <b>class Attribute</b>",
    "value": "method gist"
  },
  {
    "url": "/type/Attribute#Optional_introspection",
    "info": ": section in <b>class Attribute</b>",
    "category": "Heading",
    "value": "Optional introspection"
  },
  {
    "url": "/type/Attribute#DEPRECATED",
    "value": "DEPRECATED",
    "info": ": section in <b>class Attribute</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>,=</b>",
    "value": "In language/operators",
    "url": "/routine/%2C%3D#language/operatorsroutinepostfix",
    "category": "Heading"
  },
  {
    "value": "In type/Parameter",
    "category": "Heading",
    "info": ": section in <b>raw</b>",
    "url": "/routine/raw#type/Parameterroutinemethod"
  },
  {
    "category": "Heading",
    "info": ": section in <b>day-of-week</b>",
    "url": "/routine/day-of-week#type/Dateishroutinemethod",
    "value": "In type/Dateish"
  },
  {
    "info": ": section in <b>Lexing</b>",
    "value": "In language/glossary",
    "category": "Heading",
    "url": "/syntax/Lexing#language/glossarysyntaxLexing"
  },
  {
    "category": "Heading",
    "info": ": section in <b>cosec</b>",
    "url": "/routine/cosec#type/Coolroutineroutine",
    "value": "In type/Cool"
  },
  {
    "category": "Heading",
    "value": "In type/independent-routines",
    "info": ": section in <b>emit</b>",
    "url": "/routine/emit#type/independent-routinesroutinesub"
  },
  {
    "url": "/syntax/%28%20%29#language/regexessyntax( )",
    "info": ": section in <b>( )</b>",
    "category": "Heading",
    "value": "In language/regexes"
  },
  {
    "info": ": section in <b>^^</b>",
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/%5E%5E#language/operatorsroutineinfix"
  },
  {
    "url": "/routine/is-prime#type/Introutineroutine",
    "category": "Heading",
    "info": ": section in <b>is-prime</b>",
    "value": "In type/Int"
  },
  {
    "url": "/routine/%3F%7C#language/operatorsroutineinfix",
    "category": "Heading",
    "info": ": section in <b>?|</b>",
    "value": "In language/operators"
  },
  {
    "info": ": section in <b>weekday-of-month</b>",
    "category": "Heading",
    "value": "In type/Dateish",
    "url": "/routine/weekday-of-month#type/Dateishroutinemethod"
  },
  {
    "value": "In language/operators",
    "url": "/routine/~%5E#language/operatorsroutineprefix",
    "category": "Heading",
    "info": ": section in <b>~^</b>"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/~%5E#language/operatorsroutineinfix",
    "info": ": section in <b>~^</b>"
  },
  {
    "info": ": section in <b>chdir</b>",
    "value": "In type/independent-routines",
    "category": "Heading",
    "url": "/routine/chdir#type/independent-routinesroutinesub"
  },
  {
    "category": "Heading",
    "url": "/syntax/rakudoc#programs/02-reading-docssyntaxrakudoc",
    "info": ": section in <b>rakudoc</b>",
    "value": "In programs/02-reading-docs"
  },
  {
    "value": "In language/operators",
    "url": "/routine/%28%7C%29%2C%20infix%20%E2%88%AA#language/operatorsroutineinfix",
    "info": ": section in <b>(|), infix ∪</b>",
    "category": "Heading"
  },
  {
    "value": "In language/glossary",
    "info": ": section in <b>opcode</b>",
    "category": "Heading",
    "url": "/syntax/opcode#language/glossarysyntaxopcode"
  },
  {
    "info": ": section in <b>NFG</b>",
    "value": "In language/glossary",
    "category": "Heading",
    "url": "/syntax/NFG#language/glossarysyntaxNFG"
  },
  {
    "info": ": section in <b>andthen</b>",
    "category": "Heading",
    "url": "/routine/andthen#language/operatorsroutineinfix",
    "value": "In language/operators"
  },
  {
    "info": ": section in <b>DateTime</b>",
    "value": "In type/Str",
    "category": "Heading",
    "url": "/routine/DateTime#type/Strroutinemethod"
  },
  {
    "category": "Heading",
    "value": "In language/regexes",
    "url": "/syntax/s%2F%20%2F%20%2F#language/regexessyntaxs/ / /",
    "info": ": section in <b>s/ / /</b>"
  },
  {
    "url": "/language/101-basics#Pragma_v6",
    "category": "Heading",
    "value": "Pragma v6",
    "info": ": section in <b>Raku by example 101</b>"
  },
  {
    "info": ": section in <b>Raku by example 101</b>",
    "url": "/language/101-basics#Statements",
    "category": "Heading",
    "value": "Statements"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Raku by example 101</b>",
    "value": "Lexical scope and block",
    "url": "/language/101-basics#Lexical_scope_and_block"
  },
  {
    "url": "/language/101-basics#Sigils_and_identifiers",
    "value": "Sigils and identifiers",
    "info": ": section in <b>Raku by example 101</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Raku by example 101</b>",
    "value": "Scalar",
    "category": "Heading",
    "url": "/language/101-basics#Scalar"
  },
  {
    "value": "Filehandle and assignment",
    "category": "Heading",
    "url": "/language/101-basics#Filehandle_and_assignment",
    "info": ": section in <b>Raku by example 101</b>"
  },
  {
    "value": "String literals",
    "url": "/language/101-basics#String_literals",
    "category": "Heading",
    "info": ": section in <b>Raku by example 101</b>"
  },
  {
    "category": "Heading",
    "url": "/language/101-basics#Arrays,_methods_and_invocants",
    "value": "Arrays, methods and invocants",
    "info": ": section in <b>Raku by example 101</b>"
  },
  {
    "value": "Hashes",
    "info": ": section in <b>Raku by example 101</b>",
    "category": "Heading",
    "url": "/language/101-basics#Hashes"
  },
  {
    "value": "for and blocks",
    "url": "/language/101-basics#for_and_blocks",
    "info": ": section in <b>Raku by example 101</b>",
    "category": "Heading"
  },
  {
    "value": "Any and +=",
    "url": "/language/101-basics#Any_and_+=",
    "category": "Heading",
    "info": ": section in <b>Raku by example 101</b>"
  },
  {
    "url": "/language/101-basics#Fat_arrow,_pairs_and_autovivification",
    "value": "Fat arrow, pairs and autovivification",
    "category": "Heading",
    "info": ": section in <b>Raku by example 101</b>"
  },
  {
    "info": ": section in <b>Raku by example 101</b>",
    "value": "Postincrement and preincrement",
    "url": "/language/101-basics#Postincrement_and_preincrement",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Raku by example 101</b>",
    "url": "/language/101-basics#Topic_variable",
    "category": "Heading",
    "value": "Topic variable"
  },
  {
    "url": "/language/101-basics#Blocks",
    "category": "Heading",
    "value": "Blocks",
    "info": ": section in <b>Raku by example 101</b>"
  },
  {
    "info": ": section in <b>Raku by example 101</b>",
    "category": "Heading",
    "value": "Stable sort",
    "url": "/language/101-basics#Stable_sort"
  },
  {
    "info": ": section in <b>Raku by example 101</b>",
    "category": "Heading",
    "url": "/language/101-basics#Standard_output",
    "value": "Standard output"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Raku by example 101</b>",
    "url": "/language/101-basics#Variable_interpolation",
    "value": "Variable interpolation"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Raku by example 101</b>",
    "url": "/language/101-basics#Double-quoted_strings_and_single-quoted_strings",
    "value": "Double-quoted strings and single-quoted strings"
  },
  {
    "value": "Zen slices",
    "category": "Heading",
    "url": "/language/101-basics#Zen_slices",
    "info": ": section in <b>Raku by example 101</b>"
  },
  {
    "category": "Heading",
    "value": "Exercises",
    "info": ": section in <b>Raku by example 101</b>",
    "url": "/language/101-basics#Exercises"
  },
  {
    "url": "/syntax/lvalue#language/glossarysyntaxlvalue",
    "value": "In language/glossary",
    "category": "Heading",
    "info": ": section in <b>lvalue</b>"
  },
  {
    "url": "/syntax/%5Cw#language/regexessyntax%5Cw",
    "value": "In language/regexes",
    "info": ": section in <b>\\w</b>",
    "category": "Heading"
  },
  {
    "url": "/routine/repeated#type/independent-routinesroutineroutine",
    "info": ": section in <b>repeated</b>",
    "value": "In type/independent-routines",
    "category": "Heading"
  },
  {
    "value": "In language/variables",
    "category": "Heading",
    "info": ": section in <b>$_</b>",
    "url": "/syntax/%24_#language/variablessyntaxvariable"
  },
  {
    "category": "Heading",
    "info": ": section in <b>spurt</b>",
    "url": "/routine/spurt#type/independent-routinesroutinesub",
    "value": "In type/independent-routines"
  },
  {
    "info": ": section in <b>Phasers</b>",
    "category": "Heading",
    "value": "In language/control",
    "url": "/syntax/Phasers#language/controlsyntaxPhasers"
  },
  {
    "category": "Heading",
    "info": ": section in <b>my</b>",
    "url": "/syntax/my#language/variablessyntaxdeclarator",
    "value": "In language/variables"
  },
  {
    "info": ": section in <b>year</b>",
    "category": "Heading",
    "value": "In type/Dateish",
    "url": "/routine/year#type/Dateishroutinemethod"
  },
  {
    "url": "/routine/trim#type/Strroutinemethod",
    "value": "In type/Str",
    "info": ": section in <b>trim</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>trim</b>",
    "category": "Heading",
    "value": "In type/Cool",
    "url": "/routine/trim#type/Coolroutineroutine"
  },
  {
    "value": "Getting started",
    "category": "Heading",
    "url": "/language/nativecall#Getting_started",
    "info": ": section in <b>Native calling interface</b>"
  },
  {
    "url": "/language/nativecall#NativeCall_helper_module",
    "value": "NativeCall helper module",
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>"
  },
  {
    "info": ": section in <b>Native calling interface</b>",
    "category": "Heading",
    "url": "/language/nativecall#Changing_names",
    "value": "Changing names"
  },
  {
    "info": ": section in <b>Native calling interface</b>",
    "url": "/language/nativecall#Passing_and_returning_values",
    "category": "Heading",
    "value": "Passing and returning values"
  },
  {
    "url": "/language/nativecall#Specifying_the_native_representation",
    "value": "Specifying the native representation",
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>"
  },
  {
    "info": ": section in <b>Native calling interface</b>",
    "value": "Basic use of pointers",
    "url": "/language/nativecall#Basic_use_of_pointers",
    "category": "Heading"
  },
  {
    "value": "Function pointers",
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>",
    "url": "/language/nativecall#Function_pointers"
  },
  {
    "url": "/language/nativecall#Arrays",
    "value": "Arrays",
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>"
  },
  {
    "info": ": section in <b>Native calling interface</b>",
    "url": "/language/nativecall#CArray_methods",
    "category": "Heading",
    "value": "CArray methods"
  },
  {
    "value": "CArray sub-arrays",
    "url": "/language/nativecall#CArray_sub-arrays",
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>"
  },
  {
    "url": "/language/nativecall#Structs",
    "info": ": section in <b>Native calling interface</b>",
    "category": "Heading",
    "value": "Structs"
  },
  {
    "value": "CUnions",
    "info": ": section in <b>Native calling interface</b>",
    "url": "/language/nativecall#CUnions",
    "category": "Heading"
  },
  {
    "value": "Embedding CStructs and CUnions with HAS",
    "info": ": section in <b>Native calling interface</b>",
    "url": "/language/nativecall#Embedding_CStructs_and_CUnions_with_HAS",
    "category": "Heading"
  },
  {
    "value": "Notes on memory management",
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>",
    "url": "/language/nativecall#Notes_on_memory_management"
  },
  {
    "category": "Heading",
    "url": "/language/nativecall#In_your_Raku_code...",
    "info": ": section in <b>Native calling interface</b>",
    "value": "In your Raku code..."
  },
  {
    "url": "/language/nativecall#In_your_C_code...",
    "info": ": section in <b>Native calling interface</b>",
    "category": "Heading",
    "value": "In your C code..."
  },
  {
    "url": "/language/nativecall#Typed_pointers",
    "value": "Typed pointers",
    "info": ": section in <b>Native calling interface</b>",
    "category": "Heading"
  },
  {
    "value": "Strings",
    "info": ": section in <b>Native calling interface</b>",
    "url": "/language/nativecall#Strings",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Native calling interface</b>",
    "category": "Heading",
    "value": "Explicit memory management",
    "url": "/language/nativecall#Explicit_memory_management"
  },
  {
    "url": "/language/nativecall#Buffers_and_blobs",
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>",
    "value": "Buffers and blobs"
  },
  {
    "info": ": section in <b>Native calling interface</b>",
    "value": "Function arguments",
    "url": "/language/nativecall#Function_arguments",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>",
    "url": "/language/nativecall#Library_paths_and_names",
    "value": "Library paths and names"
  },
  {
    "info": ": section in <b>Native calling interface</b>",
    "category": "Heading",
    "url": "/language/nativecall#ABI/API_version",
    "value": "ABI/API version"
  },
  {
    "category": "Heading",
    "url": "/language/nativecall#Routine",
    "value": "Routine",
    "info": ": section in <b>Native calling interface</b>"
  },
  {
    "url": "/language/nativecall#Calling_into_the_standard_library",
    "category": "Heading",
    "value": "Calling into the standard library",
    "info": ": section in <b>Native calling interface</b>"
  },
  {
    "value": "Exported variables",
    "info": ": section in <b>Native calling interface</b>",
    "url": "/language/nativecall#Exported_variables",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "C++ support",
    "url": "/language/nativecall#C++_support",
    "info": ": section in <b>Native calling interface</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>",
    "url": "/language/nativecall#Helper_functions",
    "value": "Helper functions"
  },
  {
    "info": ": section in <b>Native calling interface</b>",
    "value": "sub nativecast",
    "url": "/language/nativecall#sub_nativecast",
    "category": "Heading"
  },
  {
    "url": "/language/nativecall#sub_cglobal",
    "info": ": section in <b>Native calling interface</b>",
    "value": "sub cglobal",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Native calling interface</b>",
    "category": "Heading",
    "url": "/language/nativecall#sub_nativesizeof",
    "value": "sub nativesizeof"
  },
  {
    "value": "sub explicitly-manage",
    "category": "Heading",
    "url": "/language/nativecall#sub_explicitly-manage",
    "info": ": section in <b>Native calling interface</b>"
  },
  {
    "value": "Examples",
    "url": "/language/nativecall#Examples",
    "info": ": section in <b>Native calling interface</b>",
    "category": "Heading"
  },
  {
    "url": "/language/nativecall#PostgreSQL",
    "value": "PostgreSQL",
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>"
  },
  {
    "info": ": section in <b>Native calling interface</b>",
    "value": "MySQL",
    "category": "Heading",
    "url": "/language/nativecall#MySQL"
  },
  {
    "url": "/language/nativecall#Microsoft_Windows",
    "value": "Microsoft Windows",
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>"
  },
  {
    "url": "/language/nativecall#Short_tutorial_on_calling_a_C_function",
    "category": "Heading",
    "info": ": section in <b>Native calling interface</b>",
    "value": "Short tutorial on calling a C function"
  },
  {
    "info": ": section in <b>Native calling interface</b>",
    "category": "Heading",
    "value": "Platform Specific Notes",
    "url": "/language/nativecall#Platform_Specific_Notes"
  },
  {
    "category": "Heading",
    "url": "/language/nativecall#MacOS_-_DYLD_LIBRARY_PATH_is_ignored",
    "info": ": section in <b>Native calling interface</b>",
    "value": "MacOS - DYLD_LIBRARY_PATH is ignored"
  },
  {
    "value": "In language/operators",
    "url": "/routine/%26lt%3B%26gt%3B#language/operatorsroutinepostcircumfix",
    "category": "Heading",
    "info": ": section in <b><></b>"
  },
  {
    "info": ": section in <b>named</b>",
    "category": "Heading",
    "url": "/routine/named#type/Parameterroutinemethod",
    "value": "In type/Parameter"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "value": "Lexical conventions",
    "category": "Heading",
    "url": "/language/syntax#Lexical_conventions"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "category": "Heading",
    "url": "/language/syntax#Free_form",
    "value": "Free form"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#Unspace",
    "category": "Heading",
    "value": "Unspace"
  },
  {
    "value": "Separating statements with semicolons",
    "info": ": section in <b>Syntax</b>",
    "category": "Heading",
    "url": "/language/syntax#Separating_statements_with_semicolons"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#Implied_separator_rule_(for_statements_ending_in_blocks)",
    "value": "Implied separator rule (for statements ending in blocks)"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "category": "Heading",
    "value": "Comments",
    "url": "/language/syntax#Comments"
  },
  {
    "value": "Single-line comments",
    "url": "/language/syntax#Single-line_comments",
    "info": ": section in <b>Syntax</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/syntax#Multi-line_/_embedded_comments",
    "value": "Multi-line / embedded comments",
    "info": ": section in <b>Syntax</b>"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "value": "Pod comments",
    "category": "Heading",
    "url": "/language/syntax#Pod_comments"
  },
  {
    "url": "/language/syntax#Identifiers",
    "value": "Identifiers",
    "info": ": section in <b>Syntax</b>",
    "category": "Heading"
  },
  {
    "url": "/language/syntax#Ordinary_identifiers",
    "info": ": section in <b>Syntax</b>",
    "value": "Ordinary identifiers",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Extended identifiers",
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#Extended_identifiers"
  },
  {
    "value": "Compound identifiers",
    "url": "/language/syntax#Compound_identifiers",
    "info": ": section in <b>Syntax</b>",
    "category": "Heading"
  },
  {
    "url": "/language/syntax#term_term:<>",
    "value": "term term:<>",
    "category": "Heading",
    "info": ": section in <b>Syntax</b>"
  },
  {
    "value": "Statements and expressions",
    "category": "Heading",
    "url": "/language/syntax#Statements_and_expressions",
    "info": ": section in <b>Syntax</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Syntax</b>",
    "value": "Terms",
    "url": "/language/syntax#Terms"
  },
  {
    "url": "/language/syntax#Variables",
    "value": "Variables",
    "category": "Heading",
    "info": ": section in <b>Syntax</b>"
  },
  {
    "value": "Barewords (constants, type names)",
    "category": "Heading",
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#Barewords_(constants,_type_names)"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "category": "Heading",
    "value": "Packages and qualified names",
    "url": "/language/syntax#Packages_and_qualified_names"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "category": "Heading",
    "value": "Literals",
    "url": "/language/syntax#Literals"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#String_literals",
    "value": "String literals",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Syntax</b>",
    "value": "Number literals",
    "url": "/language/syntax#Number_literals"
  },
  {
    "url": "/language/syntax#Int_literals",
    "category": "Heading",
    "info": ": section in <b>Syntax</b>",
    "value": "Int literals"
  },
  {
    "category": "Heading",
    "value": "Rat literals",
    "url": "/language/syntax#Rat_literals",
    "info": ": section in <b>Syntax</b>"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#Num_literals",
    "value": "Num literals",
    "category": "Heading"
  },
  {
    "url": "/language/syntax#Complex_literals",
    "value": "Complex literals",
    "info": ": section in <b>Syntax</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#Pair_literals",
    "category": "Heading",
    "value": "Pair literals"
  },
  {
    "category": "Heading",
    "value": "Arrow pairs",
    "url": "/language/syntax#Arrow_pairs",
    "info": ": section in <b>Syntax</b>"
  },
  {
    "url": "/language/syntax#Adverbial_pairs_(colon_pairs)",
    "value": "Adverbial pairs (colon pairs)",
    "info": ": section in <b>Syntax</b>",
    "category": "Heading"
  },
  {
    "url": "/language/syntax#Boolean_literals",
    "category": "Heading",
    "value": "Boolean literals",
    "info": ": section in <b>Syntax</b>"
  },
  {
    "value": "Array literals",
    "url": "/language/syntax#Array_literals",
    "info": ": section in <b>Syntax</b>",
    "category": "Heading"
  },
  {
    "value": "Hash literals",
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#Hash_literals",
    "category": "Heading"
  },
  {
    "value": "Regex literals",
    "info": ": section in <b>Syntax</b>",
    "category": "Heading",
    "url": "/language/syntax#Regex_literals"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#Signature_literals",
    "value": "Signature literals",
    "category": "Heading"
  },
  {
    "value": "Declarations",
    "url": "/language/syntax#Declarations",
    "category": "Heading",
    "info": ": section in <b>Syntax</b>"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "value": "Variable declaration",
    "url": "/language/syntax#Variable_declaration",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#Subroutine_declaration",
    "category": "Heading",
    "value": "Subroutine declaration"
  },
  {
    "category": "Heading",
    "url": "/language/syntax#Package,_Module,_Class,_Role,_and_Grammar_declaration",
    "value": "Package, Module, Class, Role, and Grammar declaration",
    "info": ": section in <b>Syntax</b>"
  },
  {
    "url": "/language/syntax#Multi-dispatch_declaration",
    "category": "Heading",
    "value": "Multi-dispatch declaration",
    "info": ": section in <b>Syntax</b>"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "value": "Subroutine calls",
    "url": "/language/syntax#Subroutine_calls",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#Precedence_drop",
    "category": "Heading",
    "value": "Precedence drop"
  },
  {
    "info": ": section in <b>Syntax</b>",
    "category": "Heading",
    "url": "/language/syntax#Operators",
    "value": "Operators"
  },
  {
    "value": "Metaoperators",
    "category": "Heading",
    "info": ": section in <b>Syntax</b>",
    "url": "/language/syntax#Metaoperators"
  },
  {
    "value": "In language/functions",
    "category": "Heading",
    "info": ": section in <b>nextcallee</b>",
    "url": "/syntax/nextcallee#language/functionssyntaxnextcallee"
  },
  {
    "info": ": section in <b>unpolar</b>",
    "value": "In type/Cool",
    "url": "/routine/unpolar#type/Coolroutinemethod",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/routine/unpolar#type/independent-routinesroutineroutine",
    "info": ": section in <b>unpolar</b>",
    "value": "In type/independent-routines"
  },
  {
    "info": ": section in <b>roots</b>",
    "url": "/routine/roots#type/Coolroutineroutine",
    "value": "In type/Cool",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "XCompose (Linux)",
    "url": "/language/unicode_entry#XCompose_(Linux)",
    "info": ": section in <b>Entering unicode characters</b>"
  },
  {
    "info": ": section in <b>Entering unicode characters</b>",
    "category": "Heading",
    "url": "/language/unicode_entry#Getting_compose_working_in_all_programs",
    "value": "Getting compose working in all programs"
  },
  {
    "value": "ibus",
    "info": ": section in <b>Entering unicode characters</b>",
    "url": "/language/unicode_entry#ibus",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "XKB (Linux)",
    "url": "/language/unicode_entry#XKB_(Linux)",
    "info": ": section in <b>Entering unicode characters</b>"
  },
  {
    "url": "/language/unicode_entry#Single-user_configuration",
    "value": "Single-user configuration",
    "info": ": section in <b>Entering unicode characters</b>",
    "category": "Heading"
  },
  {
    "url": "/language/unicode_entry#System-wide_configuration",
    "value": "System-wide configuration",
    "info": ": section in <b>Entering unicode characters</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Entering unicode characters</b>",
    "category": "Heading",
    "value": "KDE",
    "url": "/language/unicode_entry#KDE"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Entering unicode characters</b>",
    "value": "How to enter Unicode characters using a two-key combination",
    "url": "/language/unicode_entry#How_to_enter_Unicode_characters_using_a_two-key_combination"
  },
  {
    "info": ": section in <b>Entering unicode characters</b>",
    "category": "Heading",
    "value": "WinCompose (Windows)",
    "url": "/language/unicode_entry#WinCompose_(Windows)"
  },
  {
    "url": "/language/unicode_entry#Terminals,_shells,_and_editors:",
    "info": ": section in <b>Entering unicode characters</b>",
    "category": "Heading",
    "value": "Terminals, shells, and editors:"
  },
  {
    "info": ": section in <b>Entering unicode characters</b>",
    "category": "Heading",
    "url": "/language/unicode_entry#XTerm",
    "value": "XTerm"
  },
  {
    "value": "URxvt",
    "category": "Heading",
    "url": "/language/unicode_entry#URxvt",
    "info": ": section in <b>Entering unicode characters</b>"
  },
  {
    "value": "Unix shell",
    "category": "Heading",
    "info": ": section in <b>Entering unicode characters</b>",
    "url": "/language/unicode_entry#Unix_shell"
  },
  {
    "info": ": section in <b>Entering unicode characters</b>",
    "url": "/language/unicode_entry#Screen",
    "value": "Screen",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/unicode_entry#Vim",
    "info": ": section in <b>Entering unicode characters</b>",
    "value": "Vim"
  },
  {
    "url": "/language/unicode_entry#vim-raku",
    "category": "Heading",
    "value": "vim-raku",
    "info": ": section in <b>Entering unicode characters</b>"
  },
  {
    "url": "/language/unicode_entry#Emacs",
    "value": "Emacs",
    "info": ": section in <b>Entering unicode characters</b>",
    "category": "Heading"
  },
  {
    "value": "Some characters useful in Raku",
    "category": "Heading",
    "url": "/language/unicode_entry#Some_characters_useful_in_Raku",
    "info": ": section in <b>Entering unicode characters</b>"
  },
  {
    "category": "Heading",
    "url": "/language/unicode_entry#Smart_quotes",
    "info": ": section in <b>Entering unicode characters</b>",
    "value": "Smart quotes"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Entering unicode characters</b>",
    "url": "/language/unicode_entry#Guillemets",
    "value": "Guillemets"
  },
  {
    "info": ": section in <b>Entering unicode characters</b>",
    "url": "/language/unicode_entry#Set/bag_operators",
    "category": "Heading",
    "value": "Set/bag operators"
  },
  {
    "info": ": section in <b>Entering unicode characters</b>",
    "category": "Heading",
    "url": "/language/unicode_entry#Mathematical_symbols",
    "value": "Mathematical symbols"
  },
  {
    "url": "/language/unicode_entry#Greek_characters",
    "category": "Heading",
    "value": "Greek characters",
    "info": ": section in <b>Entering unicode characters</b>"
  },
  {
    "info": ": section in <b>Entering unicode characters</b>",
    "url": "/language/unicode_entry#Superscripts_and_subscripts",
    "category": "Heading",
    "value": "Superscripts and subscripts"
  },
  {
    "category": "Heading",
    "url": "/syntax/callsame#language/functionssyntaxcallsame",
    "info": ": section in <b>callsame</b>",
    "value": "In language/functions"
  },
  {
    "info": ": section in <b>%INC (Perl)</b>",
    "value": "In language/5to6-perlvar",
    "category": "Heading",
    "url": "/syntax/%25INC%20%28Perl%29#language/5to6-perlvarsyntax%INC (Perl)"
  },
  {
    "info": ": section in <b>Not Quite Perl</b>",
    "url": "/syntax/Not%20Quite%20Perl#language/glossarysyntaxNot Quite Perl",
    "value": "In language/glossary",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Sigil</b>",
    "value": "In language/glossary",
    "category": "Heading",
    "url": "/syntax/Sigil#language/glossarysyntaxSigil"
  },
  {
    "url": "/routine/acotanh#type/Coolroutineroutine",
    "value": "In type/Cool",
    "info": ": section in <b>acotanh</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b><|w></b>",
    "url": "/syntax/%3C%7Cw%3E#language/regexessyntax<|w>",
    "value": "In language/regexes"
  },
  {
    "value": "In language/glossary",
    "url": "/syntax/ASCII%20operator#language/glossarysyntaxASCII operator",
    "info": ": section in <b>ASCII operator</b>",
    "category": "Heading"
  },
  {
    "url": "/routine/X#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>X</b>"
  },
  {
    "info": ": section in <b>SetHash</b>",
    "url": "/routine/SetHash#type/Baggyroutinemethod",
    "value": "In type/Baggy",
    "category": "Heading"
  },
  {
    "info": ": section in <b>attributes</b>",
    "value": "In language/classtut",
    "url": "/syntax/attributes#language/classtutsyntaxattributes",
    "category": "Heading"
  },
  {
    "value": "In type/Str",
    "url": "/routine/ends-with#type/Strroutinemethod",
    "info": ": section in <b>ends-with</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>formatter</b>",
    "url": "/routine/formatter#type/Dateishroutinemethod",
    "category": "Heading",
    "value": "In type/Dateish"
  },
  {
    "url": "/routine/div#type/Introutineinfix",
    "info": ": section in <b>div</b>",
    "category": "Heading",
    "value": "In type/Int"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/div#language/operatorsroutineinfix",
    "info": ": section in <b>div</b>"
  },
  {
    "value": "In type/Cool",
    "info": ": section in <b>Failure</b>",
    "url": "/routine/Failure#type/Coolroutinemethod",
    "category": "Heading"
  },
  {
    "info": ": section in <b>sign</b>",
    "url": "/routine/sign#type/Coolroutinemethod",
    "value": "In type/Cool",
    "category": "Heading"
  },
  {
    "url": "/routine/acosh#type/Coolroutineroutine",
    "value": "In type/Cool",
    "category": "Heading",
    "info": ": section in <b>acosh</b>"
  },
  {
    "value": "In language/glossary",
    "info": ": section in <b>TheDamian</b>",
    "url": "/syntax/TheDamian#language/glossarysyntaxTheDamian",
    "category": "Heading"
  },
  {
    "info": ": section in <b>and</b>",
    "url": "/routine/and#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>!!!</b>",
    "url": "/routine/%21%21%21#language/operatorsroutinelistop"
  },
  {
    "url": "/routine/rw#type/Parameterroutinemethod",
    "category": "Heading",
    "info": ": section in <b>rw</b>",
    "value": "In type/Parameter"
  },
  {
    "category": "Heading",
    "url": "/routine/rw#type/Attributeroutinemethod",
    "info": ": section in <b>rw</b>",
    "value": "In type/Attribute"
  },
  {
    "value": "In language/glossary",
    "url": "/syntax/Arity#language/glossarysyntaxArity",
    "info": ": section in <b>Arity</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Multi-Dispatch</b>",
    "url": "/syntax/Multi-Dispatch#language/glossarysyntaxMulti-Dispatch",
    "value": "In language/glossary"
  },
  {
    "value": "In type/X/Proc/Unsuccessful",
    "info": ": section in <b>proc</b>",
    "category": "Heading",
    "url": "/routine/proc#type/X/Proc/Unsuccessfulroutinemethod"
  },
  {
    "url": "/syntax/sub#language/functionssyntaxsub",
    "category": "Heading",
    "info": ": section in <b>sub</b>",
    "value": "In language/functions"
  },
  {
    "value": "In type/Str",
    "url": "/routine/val#type/Strroutineroutine",
    "category": "Heading",
    "info": ": section in <b>val</b>"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>(==), infix ≡</b>",
    "url": "/routine/%28%3D%3D%29%2C%20infix%20%E2%89%A1#language/operatorsroutineinfix"
  },
  {
    "url": "/syntax/Type%20Objects#language/glossarysyntaxType Objects",
    "info": ": section in <b>Type Objects</b>",
    "value": "In language/glossary",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/routine/coerce_type#type/Parameterroutinemethod",
    "value": "In type/Parameter",
    "info": ": section in <b>coerce_type</b>"
  },
  {
    "info": ": section in <b>$?DISTRIBUTION</b>",
    "value": "In language/variables",
    "url": "/syntax/%24%3FDISTRIBUTION#language/variablessyntax$%3FDISTRIBUTION",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In type/Dateish",
    "url": "/routine/earlier#type/Dateishroutinemethod",
    "info": ": section in <b>earlier</b>"
  },
  {
    "info": ": section in <b>\\h</b>",
    "url": "/syntax/%5Ch#language/regexessyntax%5Ch",
    "category": "Heading",
    "value": "In language/regexes"
  },
  {
    "value": "In language/glossary",
    "info": ": section in <b>Virtual Machine</b>",
    "url": "/syntax/Virtual%20Machine#language/glossarysyntaxVirtual Machine",
    "category": "Heading"
  },
  {
    "url": "/syntax/Anonymous#language/glossarysyntaxAnonymous",
    "info": ": section in <b>Anonymous</b>",
    "category": "Heading",
    "value": "In language/glossary"
  },
  {
    "info": ": section in <b>is-leap-year</b>",
    "category": "Heading",
    "value": "In type/Dateish",
    "url": "/routine/is-leap-year#type/Dateishroutinemethod"
  },
  {
    "info": ": section in <b>< ></b>",
    "url": "/routine/%26lt%3B%20%26gt%3B#language/operatorsroutineterm",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "info": ": section in <b>< ></b>",
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/%26lt%3B%20%26gt%3B#language/operatorsroutinepostcircumfix"
  },
  {
    "category": "Heading",
    "url": "/routine/slurp#type/independent-routinesroutinesub",
    "value": "In type/independent-routines",
    "info": ": section in <b>slurp</b>"
  },
  {
    "value": "In type/Str",
    "category": "Heading",
    "url": "/routine/contains#type/Strroutinemethod",
    "info": ": section in <b>contains</b>"
  },
  {
    "value": "In type/Cool",
    "url": "/routine/contains#type/Coolroutinemethod",
    "info": ": section in <b>contains</b>",
    "category": "Heading"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>but</b>",
    "category": "Heading",
    "url": "/routine/but#language/operatorsroutineinfix"
  },
  {
    "url": "/syntax/N%C3%A9e#language/glossarysyntaxNée",
    "value": "In language/glossary",
    "category": "Heading",
    "info": ": section in <b>Née</b>"
  },
  {
    "category": "Heading",
    "url": "/routine/ne#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>ne</b>"
  },
  {
    "value": "In type/Int",
    "url": "/routine/expmod#type/Introutineroutine",
    "category": "Heading",
    "info": ": section in <b>expmod</b>"
  },
  {
    "url": "/routine/cglobal#language/nativecallroutinesub",
    "info": ": section in <b>cglobal</b>",
    "value": "In language/nativecall",
    "category": "Heading"
  },
  {
    "info": ": section in <b>IRC</b>",
    "category": "Heading",
    "url": "/syntax/IRC#language/glossarysyntaxIRC",
    "value": "In language/glossary"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>>=, infix ≥</b>",
    "url": "/routine/%26gt%3B%3D%2C%20infix%20%E2%89%A5#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In language/variables",
    "info": ": section in <b>$/</b>",
    "url": "/syntax/%24%2F#language/variablessyntaxvariable"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/%26lt%3B%3D%2C%20infix%20%E2%89%A4#language/operatorsroutineinfix",
    "info": ": section in <b><=, infix ≤</b>"
  },
  {
    "url": "/routine/parse-base#type/Strroutineroutine",
    "value": "In type/Str",
    "info": ": section in <b>parse-base</b>",
    "category": "Heading"
  },
  {
    "url": "/syntax/invocant%20%28Basics%29#language/101-basicssyntaxinvocant (Basics)",
    "info": ": section in <b>invocant (Basics)</b>",
    "category": "Heading",
    "value": "In language/101-basics"
  },
  {
    "value": "In language/variables",
    "category": "Heading",
    "info": ": section in <b>our</b>",
    "url": "/syntax/our#language/variablessyntaxdeclarator"
  },
  {
    "category": "Heading",
    "url": "/routine/asech#type/Coolroutineroutine",
    "info": ": section in <b>asech</b>",
    "value": "In type/Cool"
  },
  {
    "url": "/syntax/Overriding%20default%20gist%20method#language/classtutsyntaxOverriding default gist method",
    "category": "Heading",
    "value": "In language/classtut",
    "info": ": section in <b>Overriding default gist method</b>"
  },
  {
    "info": ": section in <b>Type Smiley</b>",
    "category": "Heading",
    "url": "/syntax/Type%20Smiley#language/glossarysyntaxType Smiley",
    "value": "In language/glossary"
  },
  {
    "category": "Heading",
    "info": ": section in <b>ords</b>",
    "url": "/routine/ords#type/Strroutinemethod",
    "value": "In type/Str"
  },
  {
    "url": "/routine/ords#type/Coolroutineroutine",
    "value": "In type/Cool",
    "info": ": section in <b>ords</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>samemark</b>",
    "url": "/routine/samemark#type/Strroutineroutine",
    "value": "In type/Str"
  },
  {
    "url": "/routine/atanh#type/Coolroutineroutine",
    "value": "In type/Cool",
    "info": ": section in <b>atanh</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>term:<></b>",
    "value": "In language/syntax",
    "url": "/routine/term%3A%26lt%3B%26gt%3B#language/syntaxroutineterm",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/routine/%2A#language/operatorsroutineinfix",
    "info": ": section in <b>*</b>",
    "value": "In language/operators"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>fff^</b>",
    "url": "/routine/fff%5E#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/routine/week#type/Dateishroutinemethod",
    "info": ": section in <b>week</b>",
    "value": "In type/Dateish"
  },
  {
    "info": ": section in <b>||</b>",
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/%7C%7C#language/operatorsroutineinfix"
  },
  {
    "url": "/syntax/block#language/glossarysyntaxblock",
    "value": "In language/glossary",
    "info": ": section in <b>block</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>statements</b>",
    "value": "In language/control",
    "url": "/syntax/statements#language/controlsyntaxstatements"
  },
  {
    "category": "Heading",
    "value": "In type/Str",
    "url": "/routine/lines#type/Strroutineroutine",
    "info": ": section in <b>lines</b>"
  },
  {
    "value": "In type/Cool",
    "category": "Heading",
    "info": ": section in <b>lines</b>",
    "url": "/routine/lines#type/Coolroutineroutine"
  },
  {
    "url": "/routine/let#language/variablesroutineprefix",
    "value": "In language/variables",
    "category": "Heading",
    "info": ": section in <b>let</b>"
  },
  {
    "url": "/routine/let#language/operatorsroutineprefix",
    "value": "In language/operators",
    "info": ": section in <b>let</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In type/Proc/Async",
    "info": ": section in <b>ready</b>",
    "url": "/routine/ready#type/Proc/Asyncroutinemethod"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/mod#language/operatorsroutineinfix",
    "info": ": section in <b>mod</b>"
  },
  {
    "value": "In language/control",
    "category": "Heading",
    "info": ": section in <b>when</b>",
    "url": "/syntax/when#language/controlsyntaxwhen"
  },
  {
    "url": "/routine/before#language/operatorsroutineinfix",
    "category": "Heading",
    "info": ": section in <b>before</b>",
    "value": "In language/operators"
  },
  {
    "category": "Heading",
    "url": "/routine/classify-list#type/Baggyroutinemethod",
    "value": "In type/Baggy",
    "info": ": section in <b>classify-list</b>"
  },
  {
    "url": "/language/variables#Sigils",
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "value": "Sigils"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "value": "Item and list assignment",
    "url": "/language/variables#Item_and_list_assignment"
  },
  {
    "value": "Sigilless variables",
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "url": "/language/variables#Sigilless_variables"
  },
  {
    "category": "Heading",
    "value": "Twigils",
    "url": "/language/variables#Twigils",
    "info": ": section in <b>Variables</b>"
  },
  {
    "url": "/language/variables#The_*_twigil",
    "value": "The * twigil",
    "info": ": section in <b>Variables</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "The ? twigil",
    "category": "Heading",
    "url": "/language/variables#The_%3F_twigil"
  },
  {
    "value": "The ! twigil",
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "url": "/language/variables#The_!_twigil"
  },
  {
    "value": "The . twigil",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#The_._twigil",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "The ^ twigil",
    "category": "Heading",
    "url": "/language/variables#The_^_twigil"
  },
  {
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#The_:_twigil",
    "category": "Heading",
    "value": "The : twigil"
  },
  {
    "value": "A note on ^ and :",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#A_note_on_^_and_:",
    "category": "Heading"
  },
  {
    "url": "/language/variables#The_=_twigil",
    "info": ": section in <b>Variables</b>",
    "value": "The = twigil",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "url": "/language/variables#The_~_twigil",
    "value": "The ~ twigil"
  },
  {
    "url": "/language/variables#Variable_declarators_and_scope",
    "value": "Variable declarators and scope",
    "category": "Heading",
    "info": ": section in <b>Variables</b>"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "The my declarator",
    "url": "/language/variables#The_my_declarator",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "The our declarator",
    "url": "/language/variables#The_our_declarator",
    "info": ": section in <b>Variables</b>"
  },
  {
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#Declaring_a_list_of_variables_with_lexical_(my)_or_package_(our)_scope",
    "value": "Declaring a list of variables with lexical (my) or package (our) scope",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "value": "The has declarator",
    "url": "/language/variables#The_has_declarator"
  },
  {
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#The_anon_declarator",
    "value": "The anon declarator",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "The state declarator",
    "url": "/language/variables#The_state_declarator",
    "category": "Heading"
  },
  {
    "url": "/language/variables#The_$_variable",
    "value": "The $ variable",
    "category": "Heading",
    "info": ": section in <b>Variables</b>"
  },
  {
    "value": "The @ variable",
    "url": "/language/variables#The_@_variable",
    "info": ": section in <b>Variables</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "The % variable",
    "category": "Heading",
    "url": "/language/variables#The_%_variable"
  },
  {
    "url": "/language/variables#The_augment_declarator",
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "value": "The augment declarator"
  },
  {
    "value": "The temp prefix",
    "category": "Heading",
    "url": "/language/variables#The_temp_prefix",
    "info": ": section in <b>Variables</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#The_let_prefix",
    "value": "The let prefix"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "value": "The constant prefix",
    "url": "/language/variables#The_constant_prefix"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "Type constraints and initialization",
    "category": "Heading",
    "url": "/language/variables#Type_constraints_and_initialization"
  },
  {
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#Default_defined_variables_pragma",
    "value": "Default defined variables pragma",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Special variables",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#Special_variables"
  },
  {
    "url": "/language/variables#Pre-defined_lexical_variables",
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "value": "Pre-defined lexical variables"
  },
  {
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "value": "The $_ variable",
    "url": "/language/variables#The_$__variable"
  },
  {
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "value": "The $/ variable",
    "url": "/language/variables#The_$/_variable"
  },
  {
    "category": "Heading",
    "url": "/language/variables#Positional_attributes",
    "value": "Positional attributes",
    "info": ": section in <b>Variables</b>"
  },
  {
    "category": "Heading",
    "value": "Named attributes",
    "url": "/language/variables#Named_attributes",
    "info": ": section in <b>Variables</b>"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "Thread-safety issues",
    "category": "Heading",
    "url": "/language/variables#Thread-safety_issues"
  },
  {
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "value": "The $! variable",
    "url": "/language/variables#The_$!_variable"
  },
  {
    "url": "/language/variables#Compile-time_variables",
    "info": ": section in <b>Variables</b>",
    "value": "Compile-time variables",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#%%3FRESOURCES",
    "value": "%?RESOURCES"
  },
  {
    "category": "Heading",
    "url": "/language/variables#Introspection_compile-time_variables",
    "info": ": section in <b>Variables</b>",
    "value": "Introspection compile-time variables"
  },
  {
    "value": "Rakudo-specific compile-time variables",
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#Rakudo-specific_compile-time_variables"
  },
  {
    "value": "&?ROUTINE",
    "url": "/language/variables#&%3FROUTINE",
    "info": ": section in <b>Variables</b>",
    "category": "Heading"
  },
  {
    "value": "&?BLOCK",
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#&%3FBLOCK"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "$?DISTRIBUTION",
    "url": "/language/variables#$%3FDISTRIBUTION",
    "category": "Heading"
  },
  {
    "value": "Dynamic variables",
    "url": "/language/variables#Dynamic_variables",
    "info": ": section in <b>Variables</b>",
    "category": "Heading"
  },
  {
    "value": "Argument related variables",
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "url": "/language/variables#Argument_related_variables"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "$*ARGFILES",
    "url": "/language/variables#$*ARGFILES",
    "category": "Heading"
  },
  {
    "value": "@*ARGS",
    "category": "Heading",
    "url": "/language/variables#@*ARGS",
    "info": ": section in <b>Variables</b>"
  },
  {
    "value": "&*ARGS-TO-CAPTURE",
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#&*ARGS-TO-CAPTURE"
  },
  {
    "category": "Heading",
    "value": "&*GENERATE-USAGE",
    "url": "/language/variables#&*GENERATE-USAGE",
    "info": ": section in <b>Variables</b>"
  },
  {
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#Special_filehandles:_STDIN,_STDOUT_and_STDERR",
    "value": "Special filehandles: STDIN, STDOUT and STDERR",
    "category": "Heading"
  },
  {
    "url": "/language/variables#Runtime_environment",
    "category": "Heading",
    "value": "Runtime environment",
    "info": ": section in <b>Variables</b>"
  },
  {
    "category": "Heading",
    "value": "%*ENV",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#%*ENV"
  },
  {
    "category": "Heading",
    "url": "/language/variables#$*REPO",
    "value": "$*REPO",
    "info": ": section in <b>Variables</b>"
  },
  {
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#$*INIT-INSTANT",
    "category": "Heading",
    "value": "$*INIT-INSTANT"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "$*TZ",
    "url": "/language/variables#$*TZ",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "$*CWD",
    "url": "/language/variables#$*CWD",
    "info": ": section in <b>Variables</b>"
  },
  {
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#$*KERNEL",
    "category": "Heading",
    "value": "$*KERNEL"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "$*DISTRO",
    "url": "/language/variables#$*DISTRO",
    "category": "Heading"
  },
  {
    "url": "/language/variables#$*VM",
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "value": "$*VM"
  },
  {
    "url": "/language/variables#$*RAKU",
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "value": "$*RAKU"
  },
  {
    "value": "$*PERL",
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#$*PERL"
  },
  {
    "url": "/language/variables#$*PID",
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "value": "$*PID"
  },
  {
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#$*PROGRAM-NAME",
    "value": "$*PROGRAM-NAME",
    "category": "Heading"
  },
  {
    "value": "$*PROGRAM",
    "url": "/language/variables#$*PROGRAM",
    "info": ": section in <b>Variables</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "value": "&*EXIT",
    "url": "/language/variables#&*EXIT"
  },
  {
    "value": "$*EXIT",
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#$*EXIT"
  },
  {
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#$*EXCEPTION",
    "value": "$*EXCEPTION",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "url": "/language/variables#$*EXECUTABLE",
    "value": "$*EXECUTABLE"
  },
  {
    "value": "$*EXECUTABLE-NAME",
    "url": "/language/variables#$*EXECUTABLE-NAME",
    "info": ": section in <b>Variables</b>",
    "category": "Heading"
  },
  {
    "value": "$*USAGE",
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "url": "/language/variables#$*USAGE"
  },
  {
    "url": "/language/variables#$*USER",
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "value": "$*USER"
  },
  {
    "category": "Heading",
    "url": "/language/variables#$*GROUP",
    "value": "$*GROUP",
    "info": ": section in <b>Variables</b>"
  },
  {
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#$*HOMEDRIVE",
    "value": "$*HOMEDRIVE",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#$*HOMEPATH",
    "value": "$*HOMEPATH"
  },
  {
    "url": "/language/variables#$*HOME",
    "category": "Heading",
    "value": "$*HOME",
    "info": ": section in <b>Variables</b>"
  },
  {
    "url": "/language/variables#$*SPEC",
    "value": "$*SPEC",
    "info": ": section in <b>Variables</b>",
    "category": "Heading"
  },
  {
    "url": "/language/variables#$*TMPDIR",
    "info": ": section in <b>Variables</b>",
    "value": "$*TMPDIR",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/variables#$*THREAD",
    "info": ": section in <b>Variables</b>",
    "value": "$*THREAD"
  },
  {
    "url": "/language/variables#$*SCHEDULER",
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "value": "$*SCHEDULER"
  },
  {
    "info": ": section in <b>Variables</b>",
    "value": "$*SAMPLER",
    "category": "Heading",
    "url": "/language/variables#$*SAMPLER"
  },
  {
    "category": "Heading",
    "value": "Runtime variables",
    "info": ": section in <b>Variables</b>",
    "url": "/language/variables#Runtime_variables"
  },
  {
    "url": "/language/variables#$*DEFAULT-READ-ELEMS",
    "category": "Heading",
    "info": ": section in <b>Variables</b>",
    "value": "$*DEFAULT-READ-ELEMS"
  },
  {
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "value": "$*COLLATION",
    "url": "/language/variables#$*COLLATION"
  },
  {
    "url": "/language/variables#$*RAT-OVERFLOW",
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "value": "$*RAT-OVERFLOW"
  },
  {
    "info": ": section in <b>Variables</b>",
    "category": "Heading",
    "url": "/language/variables#$*TOLERANCE",
    "value": "$*TOLERANCE"
  },
  {
    "category": "Heading",
    "value": "Naming conventions",
    "url": "/language/variables#Naming_conventions",
    "info": ": section in <b>Variables</b>"
  },
  {
    "value": "In language/5to6-perlvar",
    "category": "Heading",
    "url": "/syntax/%240%20%28Perl%29#language/5to6-perlvarsyntax$0 (Perl)",
    "info": ": section in <b>$0 (Perl)</b>"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>~<</b>",
    "url": "/routine/~%26lt%3B#language/operatorsroutineinfix"
  },
  {
    "url": "/routine/~~#language/operatorsroutineinfix",
    "info": ": section in <b>~~</b>",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "value": "In type/Str",
    "category": "Heading",
    "info": ": section in <b>subst</b>",
    "url": "/routine/subst#type/Strroutinemethod"
  },
  {
    "category": "Heading",
    "value": "In type/Cool",
    "url": "/routine/subst#type/Coolroutinemethod",
    "info": ": section in <b>subst</b>"
  },
  {
    "info": ": section in <b>:pos</b>",
    "value": "In language/regexes",
    "url": "/syntax/%3Apos#language/regexessyntax:pos",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/routine/%5Efff#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>^fff</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>tilde</b>",
    "url": "/syntax/tilde#language/regexessyntaxtilde",
    "value": "In language/regexes"
  },
  {
    "category": "Heading",
    "value": "In language/101-basics",
    "url": "/syntax/topic%20variable%20%28Basics%29#language/101-basicssyntaxtopic variable (Basics)",
    "info": ": section in <b>topic variable (Basics)</b>"
  },
  {
    "url": "/syntax/value#language/glossarysyntaxvalue",
    "info": ": section in <b>value</b>",
    "value": "In language/glossary",
    "category": "Heading"
  },
  {
    "info": ": section in <b>ff^</b>",
    "value": "In language/operators",
    "url": "/routine/ff%5E#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "value": "In language/operators",
    "url": "/routine/%3D%20%28item%20assignment%29#language/operatorsroutineinfix",
    "category": "Heading",
    "info": ": section in <b>= (item assignment)</b>"
  },
  {
    "url": "/routine/fc#type/Strroutineroutine",
    "info": ": section in <b>fc</b>",
    "category": "Heading",
    "value": "In type/Str"
  },
  {
    "info": ": section in <b>fc</b>",
    "url": "/routine/fc#type/Coolroutineroutine",
    "category": "Heading",
    "value": "In type/Cool"
  },
  {
    "url": "/routine/Set#type/Baggyroutinemethod",
    "value": "In type/Baggy",
    "info": ": section in <b>Set</b>",
    "category": "Heading"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/%3A%3A%3D#language/operatorsroutineinfix",
    "info": ": section in <b>::=</b>"
  },
  {
    "info": ": section in <b>not</b>",
    "value": "In language/operators",
    "url": "/routine/not#language/operatorsroutineprefix",
    "category": "Heading"
  },
  {
    "info": ": section in <b>asin</b>",
    "value": "In type/Cool",
    "category": "Heading",
    "url": "/routine/asin#type/Coolroutineroutine"
  },
  {
    "category": "Heading",
    "url": "/syntax/samewith#language/functionssyntaxsamewith",
    "value": "In language/functions",
    "info": ": section in <b>samewith</b>"
  },
  {
    "value": "In type/Dateish",
    "url": "/routine/week-year#type/Dateishroutinemethod",
    "category": "Heading",
    "info": ": section in <b>week-year</b>"
  },
  {
    "url": "/routine/%21%3D%2C%20infix%20%E2%89%A0#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>!=, infix ≠</b>",
    "category": "Heading"
  },
  {
    "url": "/syntax/Exegesis#language/glossarysyntaxExegesis",
    "value": "In language/glossary",
    "info": ": section in <b>Exegesis</b>",
    "category": "Heading"
  },
  {
    "value": "In language/module-packages",
    "category": "Heading",
    "info": ": section in <b>import</b>",
    "url": "/syntax/import#language/module-packagessyntaximport"
  },
  {
    "url": "/syntax/import#language/glossarysyntaximport",
    "info": ": section in <b>import</b>",
    "value": "In language/glossary",
    "category": "Heading"
  },
  {
    "url": "/syntax/Literal#language/glossarysyntaxLiteral",
    "info": ": section in <b>Literal</b>",
    "value": "In language/glossary",
    "category": "Heading"
  },
  {
    "value": "In language/grammars",
    "info": ": section in <b>token</b>",
    "category": "Heading",
    "url": "/syntax/token#language/grammarssyntaxtoken"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "Abstract class",
    "url": "/language/glossary#Abstract_class"
  },
  {
    "value": "Advent calendar",
    "url": "/language/glossary#Advent_calendar",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "Adverb",
    "category": "Heading",
    "url": "/language/glossary#Adverb"
  },
  {
    "url": "/language/glossary#Adverbial_pair",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "Adverbial pair"
  },
  {
    "url": "/language/glossary#Allomorph",
    "info": ": section in <b>Glossary</b>",
    "value": "Allomorph",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "value": "Anonymous",
    "url": "/language/glossary#Anonymous"
  },
  {
    "url": "/language/glossary#API",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "value": "API"
  },
  {
    "value": "Apocalypse",
    "url": "/language/glossary#Apocalypse",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "value": "Arity",
    "url": "/language/glossary#Arity",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "ASCII operator",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#ASCII_operator"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "Autothreading",
    "category": "Heading",
    "url": "/language/glossary#Autothreading"
  },
  {
    "category": "Heading",
    "value": "Backtracking",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Backtracking"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#binder",
    "value": "binder"
  },
  {
    "value": "block",
    "url": "/language/glossary#block",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "value": "bytecode",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "url": "/language/glossary#bytecode"
  },
  {
    "category": "Heading",
    "url": "/language/glossary#Camelia",
    "info": ": section in <b>Glossary</b>",
    "value": "Camelia"
  },
  {
    "url": "/language/glossary#Colon_pair_and_colon_list",
    "value": "Colon pair and colon list",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "url": "/language/glossary#Community",
    "value": "Community",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Damian Conway",
    "url": "/language/glossary#Damian_Conway",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "decont",
    "category": "Heading",
    "url": "/language/glossary#decont"
  },
  {
    "value": "diffy",
    "url": "/language/glossary#diffy",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "url": "/language/glossary#Exegesis",
    "value": "Exegesis",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "Forward declarations",
    "url": "/language/glossary#Forward_declarations"
  },
  {
    "url": "/language/glossary#fiddly",
    "value": "fiddly",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "Handle",
    "url": "/language/glossary#Handle"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "Huffmanize",
    "category": "Heading",
    "url": "/language/glossary#Huffmanize"
  },
  {
    "url": "/language/glossary#iffy",
    "info": ": section in <b>Glossary</b>",
    "value": "iffy",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#import",
    "category": "Heading",
    "value": "import"
  },
  {
    "url": "/language/glossary#Instance",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "value": "Instance"
  },
  {
    "url": "/language/glossary#Interface",
    "value": "Interface",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "url": "/language/glossary#Invocant",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "Invocant"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "IRC",
    "category": "Heading",
    "url": "/language/glossary#IRC"
  },
  {
    "value": "IRC lingo",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "url": "/language/glossary#IRC_lingo"
  },
  {
    "value": "ALAP",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "url": "/language/glossary#ALAP"
  },
  {
    "value": "autopun",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#autopun"
  },
  {
    "value": "backlog",
    "category": "Heading",
    "url": "/language/glossary#backlog",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "Bot",
    "url": "/language/glossary#Bot"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Compilation_unit_or_compunit",
    "value": "Compilation unit or compunit"
  },
  {
    "category": "Heading",
    "value": "DWIM",
    "url": "/language/glossary#DWIM",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "url": "/language/glossary#flap",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "flap"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "fossil",
    "url": "/language/glossary#fossil",
    "category": "Heading"
  },
  {
    "value": "FSVO",
    "url": "/language/glossary#FSVO",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "value": "FTFY",
    "category": "Heading",
    "url": "/language/glossary#FTFY",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "url": "/language/glossary#gradual_typing",
    "value": "gradual typing",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "value": "IIRC",
    "url": "/language/glossary#IIRC"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "IMHO",
    "url": "/language/glossary#IMHO",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/glossary#IWBN",
    "value": "IWBN",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "value": "LHF",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#LHF"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#LGTM",
    "value": "LGTM",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#LTA",
    "value": "LTA",
    "category": "Heading"
  },
  {
    "url": "/language/glossary#NST",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "value": "NST"
  },
  {
    "url": "/language/glossary#Opt",
    "info": ": section in <b>Glossary</b>",
    "value": "Opt",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/glossary#PB",
    "value": "PB",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "PR",
    "category": "Heading",
    "url": "/language/glossary#PR"
  },
  {
    "category": "Heading",
    "url": "/language/glossary#P5",
    "value": "P5",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "P6",
    "category": "Heading",
    "url": "/language/glossary#P6"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "RSN",
    "category": "Heading",
    "url": "/language/glossary#RSN"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "RT",
    "category": "Heading",
    "url": "/language/glossary#RT"
  },
  {
    "category": "Heading",
    "value": "TIMTOWTDI",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#TIMTOWTDI"
  },
  {
    "url": "/language/glossary#TMI",
    "value": "TMI",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "url": "/language/glossary#TMTOWTDI",
    "info": ": section in <b>Glossary</b>",
    "value": "TMTOWTDI",
    "category": "Heading"
  },
  {
    "url": "/language/glossary#UGT",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "value": "UGT"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "WFM",
    "category": "Heading",
    "url": "/language/glossary#WFM"
  },
  {
    "category": "Heading",
    "url": "/language/glossary#WIP",
    "info": ": section in <b>Glossary</b>",
    "value": "WIP"
  },
  {
    "url": "/language/glossary#WP",
    "value": "WP",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "url": "/language/glossary#WW",
    "category": "Heading",
    "value": "WW",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "value": "Larry Wall",
    "url": "/language/glossary#Larry_Wall",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "Lexing",
    "category": "Heading",
    "url": "/language/glossary#Lexing"
  },
  {
    "url": "/language/glossary#Literal",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "Literal"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#LHS",
    "category": "Heading",
    "value": "LHS"
  },
  {
    "url": "/language/glossary#lvalue",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "lvalue"
  },
  {
    "value": "Mainline",
    "url": "/language/glossary#Mainline",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "url": "/language/glossary#Mayspec",
    "value": "Mayspec",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "MoarVM",
    "category": "Heading",
    "url": "/language/glossary#MoarVM"
  },
  {
    "value": "Multi-dispatch",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "url": "/language/glossary#Multi-dispatch"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#multi-method",
    "category": "Heading",
    "value": "multi-method"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "Née",
    "url": "/language/glossary#Née",
    "category": "Heading"
  },
  {
    "value": "NFG",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "url": "/language/glossary#NFG"
  },
  {
    "url": "/language/glossary#Niecza",
    "category": "Heading",
    "value": "Niecza",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "Not Quite Perl",
    "url": "/language/glossary#Not_Quite_Perl"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "NQP",
    "url": "/language/glossary#NQP",
    "category": "Heading"
  },
  {
    "value": "NYI",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#NYI"
  },
  {
    "url": "/language/glossary#opcode",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "value": "opcode"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "url": "/language/glossary#Operator",
    "value": "Operator"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "Parse tree",
    "url": "/language/glossary#Parse_tree"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "Parameter",
    "category": "Heading",
    "url": "/language/glossary#Parameter"
  },
  {
    "value": "Parrot",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Parrot",
    "category": "Heading"
  },
  {
    "value": "PAST",
    "category": "Heading",
    "url": "/language/glossary#PAST",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Perl",
    "value": "Perl"
  },
  {
    "url": "/language/glossary#Perl_6",
    "value": "Perl 6",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#PERL",
    "value": "PERL"
  },
  {
    "value": "POD",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#POD",
    "category": "Heading"
  },
  {
    "value": "POV",
    "category": "Heading",
    "url": "/language/glossary#POV",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "url": "/language/glossary#Propspec",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "Propspec"
  },
  {
    "category": "Heading",
    "url": "/language/glossary#Pull_request",
    "value": "Pull request",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#property",
    "value": "property",
    "category": "Heading"
  },
  {
    "url": "/language/glossary#pugs",
    "value": "pugs",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "url": "/language/glossary#QAST",
    "value": "QAST",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Rakudo",
    "value": "Rakudo",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "value": "Reify",
    "url": "/language/glossary#Reify"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Repository",
    "category": "Heading",
    "value": "Repository"
  },
  {
    "value": "RHS",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#RHS",
    "category": "Heading"
  },
  {
    "value": "roast",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "url": "/language/glossary#roast"
  },
  {
    "category": "Heading",
    "value": "Roles",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Roles"
  },
  {
    "url": "/language/glossary#rvalue",
    "value": "rvalue",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "value": "SAP",
    "url": "/language/glossary#SAP",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "value": "Semilist",
    "url": "/language/glossary#Semilist",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "value": "Sigil",
    "url": "/language/glossary#Sigil",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "value": "Sigilless variable",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Sigilless_variable",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "Spesh",
    "url": "/language/glossary#Spesh",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/glossary#STD",
    "info": ": section in <b>Glossary</b>",
    "value": "STD"
  },
  {
    "value": "Stub",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Stub"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Symbol",
    "value": "Symbol"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "Synopsis",
    "url": "/language/glossary#Synopsis",
    "category": "Heading"
  },
  {
    "value": "Syntax analysis",
    "category": "Heading",
    "url": "/language/glossary#Syntax_analysis",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "Test suite",
    "category": "Heading",
    "url": "/language/glossary#Test_suite"
  },
  {
    "url": "/language/glossary#TheDamian",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "value": "TheDamian"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#TimToady",
    "value": "TimToady"
  },
  {
    "category": "Heading",
    "value": "token",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#token"
  },
  {
    "category": "Heading",
    "url": "/language/glossary#Thunk",
    "info": ": section in <b>Glossary</b>",
    "value": "Thunk"
  },
  {
    "value": "Tight and loose precedence",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Tight_and_loose_precedence",
    "category": "Heading"
  },
  {
    "url": "/language/glossary#twine",
    "value": "twine",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "url": "/language/glossary#Type_objects",
    "value": "Type objects",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Type_smiley",
    "value": "Type smiley",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "value",
    "url": "/language/glossary#value",
    "category": "Heading"
  },
  {
    "value": "UB",
    "url": "/language/glossary#UB",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading"
  },
  {
    "value": "Value type",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>",
    "url": "/language/glossary#Value_type"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "value": "Variable",
    "url": "/language/glossary#Variable",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "url": "/language/glossary#Variable_interpolation",
    "value": "Variable interpolation"
  },
  {
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "url": "/language/glossary#Virtual_machine",
    "value": "Virtual machine"
  },
  {
    "value": "WAT",
    "info": ": section in <b>Glossary</b>",
    "category": "Heading",
    "url": "/language/glossary#WAT"
  },
  {
    "value": "whitespace",
    "url": "/language/glossary#whitespace",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "url": "/language/glossary#6model",
    "value": "6model",
    "category": "Heading",
    "info": ": section in <b>Glossary</b>"
  },
  {
    "value": "In language/glossary",
    "info": ": section in <b>Token</b>",
    "url": "/syntax/Token#language/glossarysyntaxToken",
    "category": "Heading"
  },
  {
    "value": "In language/variables",
    "category": "Heading",
    "info": ": section in <b>&?ROUTINE</b>",
    "url": "/syntax/%26%3FROUTINE#language/variablessyntax&%3FROUTINE"
  },
  {
    "info": ": section in <b>&&</b>",
    "value": "In language/operators",
    "url": "/routine/%26amp%3B%26amp%3B#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "info": ": section in <b>$_ (Perl)</b>",
    "category": "Heading",
    "url": "/syntax/%24_%20%28Perl%29#language/5to6-perlvarsyntax$_ (Perl)",
    "value": "In language/5to6-perlvar"
  },
  {
    "value": "In language/glossary",
    "url": "/syntax/Abstract%20Class#language/glossarysyntaxAbstract Class",
    "category": "Heading",
    "info": ": section in <b>Abstract Class</b>"
  },
  {
    "info": ": section in <b><==</b>",
    "url": "/routine/%26lt%3B%3D%3D#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "url": "/syntax/type%20object#language/classtutsyntaxtype object",
    "category": "Heading",
    "value": "In language/classtut",
    "info": ": section in <b>type object</b>"
  },
  {
    "value": "In language/glossary",
    "category": "Heading",
    "info": ": section in <b>TimToady</b>",
    "url": "/syntax/TimToady#language/glossarysyntaxTimToady"
  },
  {
    "value": "In language/glossary",
    "category": "Heading",
    "url": "/syntax/property#language/glossarysyntaxproperty",
    "info": ": section in <b>property</b>"
  },
  {
    "value": "In language/regexes",
    "url": "/syntax/%5Cx#language/regexessyntax%5Cx",
    "category": "Heading",
    "info": ": section in <b>\\x</b>"
  },
  {
    "category": "Heading",
    "url": "/routine/write#type/Proc/Asyncroutinemethod",
    "info": ": section in <b>write</b>",
    "value": "In type/Proc/Async"
  },
  {
    "url": "/syntax/Rakudo#language/glossarysyntaxRakudo",
    "value": "In language/glossary",
    "info": ": section in <b>Rakudo</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>xor</b>",
    "url": "/routine/xor#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "url": "/syntax/instance#language/glossarysyntaxinstance",
    "category": "Heading",
    "value": "In language/glossary",
    "info": ": section in <b>instance</b>"
  },
  {
    "category": "Heading",
    "url": "/routine/%3F%3F%3F#language/operatorsroutinelistop",
    "info": ": section in <b>???</b>",
    "value": "In language/operators"
  },
  {
    "url": "/syntax/QAST#language/glossarysyntaxQAST",
    "category": "Heading",
    "info": ": section in <b>QAST</b>",
    "value": "In language/glossary"
  },
  {
    "category": "Heading",
    "url": "/routine/FatRat#type/Coolroutinemethod",
    "value": "In type/Cool",
    "info": ": section in <b>FatRat</b>"
  },
  {
    "url": "/syntax/Pull%20request#language/glossarysyntaxPull request",
    "value": "In language/glossary",
    "info": ": section in <b>Pull request</b>",
    "category": "Heading"
  },
  {
    "url": "/syntax/%7C%7C#language/regexessyntax||",
    "info": ": section in <b>||</b>",
    "value": "In language/regexes",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In language/regexes",
    "info": ": section in <b><( )></b>",
    "url": "/syntax/%3C%28%20%29%3E#language/regexessyntax<( )>"
  },
  {
    "info": ": section in <b>asec</b>",
    "url": "/routine/asec#type/Coolroutineroutine",
    "value": "In type/Cool",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/syntax/Actions#language/grammarssyntaxActions",
    "value": "In language/grammars",
    "info": ": section in <b>Actions</b>"
  },
  {
    "info": ": section in <b>leg</b>",
    "url": "/routine/leg#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "value": "In language/functions",
    "url": "/syntax/closures#language/functionssyntaxclosures",
    "info": ": section in <b>closures</b>",
    "category": "Heading"
  },
  {
    "url": "/syntax/unit#language/syntaxsyntaxunit",
    "info": ": section in <b>unit</b>",
    "category": "Heading",
    "value": "In language/syntax"
  },
  {
    "category": "Heading",
    "url": "/language/control#Statements",
    "value": "Statements",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "category": "Heading",
    "url": "/language/control#Blocks",
    "value": "Blocks",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "value": "Phasers",
    "info": ": section in <b>Control flow</b>",
    "category": "Heading",
    "url": "/language/control#Phasers"
  },
  {
    "category": "Heading",
    "url": "/language/control#do",
    "info": ": section in <b>Control flow</b>",
    "value": "do"
  },
  {
    "info": ": section in <b>Control flow</b>",
    "category": "Heading",
    "url": "/language/control#start",
    "value": "start"
  },
  {
    "category": "Heading",
    "value": "if",
    "url": "/language/control#if",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "info": ": section in <b>Control flow</b>",
    "value": "else/elsif",
    "url": "/language/control#else/elsif",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "unless",
    "url": "/language/control#unless",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "url": "/language/control#with_orwith_without",
    "value": "with orwith without",
    "category": "Heading",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "url": "/language/control#when",
    "info": ": section in <b>Control flow</b>",
    "value": "when",
    "category": "Heading"
  },
  {
    "value": "for",
    "category": "Heading",
    "info": ": section in <b>Control flow</b>",
    "url": "/language/control#for"
  },
  {
    "category": "Heading",
    "url": "/language/control#gather/take",
    "value": "gather/take",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Control flow</b>",
    "url": "/language/control#supply/emit",
    "value": "supply/emit"
  },
  {
    "category": "Heading",
    "url": "/language/control#given",
    "value": "given",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "info": ": section in <b>Control flow</b>",
    "category": "Heading",
    "value": "default and when",
    "url": "/language/control#default_and_when"
  },
  {
    "url": "/language/control#proceed_and_succeed",
    "value": "proceed and succeed",
    "category": "Heading",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "value": "given as a statement",
    "url": "/language/control#given_as_a_statement",
    "category": "Heading",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Control flow</b>",
    "value": "loop",
    "url": "/language/control#loop"
  },
  {
    "value": "while, until",
    "url": "/language/control#while,_until",
    "info": ": section in <b>Control flow</b>",
    "category": "Heading"
  },
  {
    "url": "/language/control#repeat/while,_repeat/until",
    "value": "repeat/while, repeat/until",
    "category": "Heading",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "url": "/language/control#return",
    "category": "Heading",
    "value": "return",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "value": "return-rw",
    "url": "/language/control#return-rw",
    "info": ": section in <b>Control flow</b>",
    "category": "Heading"
  },
  {
    "value": "fail",
    "url": "/language/control#fail",
    "category": "Heading",
    "info": ": section in <b>Control flow</b>"
  },
  {
    "category": "Heading",
    "value": "once",
    "info": ": section in <b>Control flow</b>",
    "url": "/language/control#once"
  },
  {
    "url": "/language/control#LABELs",
    "category": "Heading",
    "info": ": section in <b>Control flow</b>",
    "value": "LABELs"
  },
  {
    "info": ": section in <b>Control flow</b>",
    "url": "/language/control#next",
    "value": "next",
    "category": "Heading"
  },
  {
    "url": "/language/control#last",
    "category": "Heading",
    "info": ": section in <b>Control flow</b>",
    "value": "last"
  },
  {
    "category": "Heading",
    "url": "/language/control#redo",
    "info": ": section in <b>Control flow</b>",
    "value": "redo"
  },
  {
    "value": "Methods",
    "category": "Heading",
    "url": "/type/Parameter#Methods",
    "info": ": section in <b>class Parameter</b>"
  },
  {
    "info": ": section in <b>class Parameter</b>",
    "url": "/type/Parameter#method_name",
    "value": "method name",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/type/Parameter#method_usage-name",
    "info": ": section in <b>class Parameter</b>",
    "value": "method usage-name"
  },
  {
    "info": ": section in <b>class Parameter</b>",
    "value": "method sigil",
    "url": "/type/Parameter#method_sigil",
    "category": "Heading"
  },
  {
    "value": "method type",
    "category": "Heading",
    "info": ": section in <b>class Parameter</b>",
    "url": "/type/Parameter#method_type"
  },
  {
    "info": ": section in <b>class Parameter</b>",
    "url": "/type/Parameter#method_coerce_type",
    "value": "method coerce_type",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Parameter</b>",
    "url": "/type/Parameter#method_constraints",
    "value": "method constraints"
  },
  {
    "category": "Heading",
    "url": "/type/Parameter#method_named",
    "value": "method named",
    "info": ": section in <b>class Parameter</b>"
  },
  {
    "info": ": section in <b>class Parameter</b>",
    "url": "/type/Parameter#method_named_names",
    "value": "method named_names",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Parameter</b>",
    "value": "method positional",
    "url": "/type/Parameter#method_positional"
  },
  {
    "category": "Heading",
    "url": "/type/Parameter#method_slurpy",
    "info": ": section in <b>class Parameter</b>",
    "value": "method slurpy"
  },
  {
    "url": "/type/Parameter#method_twigil",
    "category": "Heading",
    "info": ": section in <b>class Parameter</b>",
    "value": "method twigil"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Parameter</b>",
    "url": "/type/Parameter#method_optional",
    "value": "method optional"
  },
  {
    "info": ": section in <b>class Parameter</b>",
    "url": "/type/Parameter#method_raw",
    "value": "method raw",
    "category": "Heading"
  },
  {
    "value": "method capture",
    "category": "Heading",
    "url": "/type/Parameter#method_capture",
    "info": ": section in <b>class Parameter</b>"
  },
  {
    "info": ": section in <b>class Parameter</b>",
    "url": "/type/Parameter#method_rw",
    "value": "method rw",
    "category": "Heading"
  },
  {
    "value": "method copy",
    "category": "Heading",
    "info": ": section in <b>class Parameter</b>",
    "url": "/type/Parameter#method_copy"
  },
  {
    "category": "Heading",
    "url": "/type/Parameter#method_readonly",
    "info": ": section in <b>class Parameter</b>",
    "value": "method readonly"
  },
  {
    "info": ": section in <b>class Parameter</b>",
    "category": "Heading",
    "value": "method invocant",
    "url": "/type/Parameter#method_invocant"
  },
  {
    "value": "method default",
    "url": "/type/Parameter#method_default",
    "category": "Heading",
    "info": ": section in <b>class Parameter</b>"
  },
  {
    "category": "Heading",
    "value": "method type_captures",
    "url": "/type/Parameter#method_type_captures",
    "info": ": section in <b>class Parameter</b>"
  },
  {
    "value": "method sub_signature",
    "category": "Heading",
    "url": "/type/Parameter#method_sub_signature",
    "info": ": section in <b>class Parameter</b>"
  },
  {
    "url": "/type/Parameter#method_prefix",
    "value": "method prefix",
    "info": ": section in <b>class Parameter</b>",
    "category": "Heading"
  },
  {
    "url": "/type/Parameter#method_suffix",
    "info": ": section in <b>class Parameter</b>",
    "category": "Heading",
    "value": "method suffix"
  },
  {
    "value": "Runtime creation of Parameter objects (6.d, 2019.03 and later)",
    "info": ": section in <b>class Parameter</b>",
    "category": "Heading",
    "url": "/type/Parameter#Runtime_creation_of_Parameter_objects_(6.d,_2019.03_and_later)"
  },
  {
    "url": "/syntax/Allomorph#language/glossarysyntaxAllomorph",
    "category": "Heading",
    "info": ": section in <b>Allomorph</b>",
    "value": "In language/glossary"
  },
  {
    "category": "Heading",
    "url": "/routine/day-of-year#type/Dateishroutinemethod",
    "info": ": section in <b>day-of-year</b>",
    "value": "In type/Dateish"
  },
  {
    "category": "Heading",
    "value": "In language/glossary",
    "info": ": section in <b>API</b>",
    "url": "/syntax/API#language/glossarysyntaxAPI"
  },
  {
    "category": "Heading",
    "url": "/routine/command#type/Proc/Asyncroutinemethod",
    "info": ": section in <b>command</b>",
    "value": "In type/Proc/Async"
  },
  {
    "value": "In type/independent-routines",
    "info": ": section in <b>get</b>",
    "category": "Heading",
    "url": "/routine/get#type/independent-routinesroutinesub"
  },
  {
    "info": ": section in <b>^</b>",
    "value": "In language/operators",
    "url": "/routine/%5E#language/operatorsroutineprefix",
    "category": "Heading"
  },
  {
    "info": ": section in <b>^</b>",
    "url": "/routine/%5E#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "value": "In type/Baggy",
    "category": "Heading",
    "info": ": section in <b>hash</b>",
    "url": "/routine/hash#type/Baggyroutinemethod"
  },
  {
    "info": ": section in <b>EVAL</b>",
    "category": "Heading",
    "value": "In type/Cool",
    "url": "/routine/EVAL#type/Coolroutinemethod"
  },
  {
    "value": "In type/independent-routines",
    "info": ": section in <b>EVAL</b>",
    "url": "/routine/EVAL#type/independent-routinesroutineroutine",
    "category": "Heading"
  },
  {
    "url": "/syntax/Parrot#language/glossarysyntaxParrot",
    "info": ": section in <b>Parrot</b>",
    "category": "Heading",
    "value": "In language/glossary"
  },
  {
    "url": "/language/objects#Using_objects",
    "info": ": section in <b>Object orientation</b>",
    "value": "Using objects",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Type objects",
    "url": "/language/objects#Type_objects",
    "info": ": section in <b>Object orientation</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Object orientation</b>",
    "value": "Classes",
    "url": "/language/objects#Classes"
  },
  {
    "value": "Attributes",
    "url": "/language/objects#Attributes",
    "category": "Heading",
    "info": ": section in <b>Object orientation</b>"
  },
  {
    "url": "/language/objects#Methods",
    "value": "Methods",
    "info": ": section in <b>Object orientation</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Object orientation</b>",
    "category": "Heading",
    "value": "Class and instance methods",
    "url": "/language/objects#Class_and_instance_methods"
  },
  {
    "url": "/language/objects#self",
    "value": "self",
    "info": ": section in <b>Object orientation</b>",
    "category": "Heading"
  },
  {
    "value": "Private methods",
    "info": ": section in <b>Object orientation</b>",
    "category": "Heading",
    "url": "/language/objects#Private_methods"
  },
  {
    "category": "Heading",
    "value": "Submethods",
    "url": "/language/objects#Submethods",
    "info": ": section in <b>Object orientation</b>"
  },
  {
    "info": ": section in <b>Object orientation</b>",
    "category": "Heading",
    "url": "/language/objects#Inheritance",
    "value": "Inheritance"
  },
  {
    "value": "Delegation",
    "category": "Heading",
    "url": "/language/objects#Delegation",
    "info": ": section in <b>Object orientation</b>"
  },
  {
    "value": "Object construction",
    "info": ": section in <b>Object orientation</b>",
    "url": "/language/objects#Object_construction",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Object cloning",
    "url": "/language/objects#Object_cloning",
    "info": ": section in <b>Object orientation</b>"
  },
  {
    "value": "Roles",
    "url": "/language/objects#Roles",
    "category": "Heading",
    "info": ": section in <b>Object orientation</b>"
  },
  {
    "value": "Applying roles",
    "info": ": section in <b>Object orientation</b>",
    "url": "/language/objects#Applying_roles",
    "category": "Heading"
  },
  {
    "url": "/language/objects#Stubs",
    "info": ": section in <b>Object orientation</b>",
    "category": "Heading",
    "value": "Stubs"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Object orientation</b>",
    "url": "/language/objects#Pecking_order",
    "value": "Pecking order"
  },
  {
    "category": "Heading",
    "value": "Automatic role punning",
    "info": ": section in <b>Object orientation</b>",
    "url": "/language/objects#Automatic_role_punning"
  },
  {
    "value": "Parameterized roles",
    "info": ": section in <b>Object orientation</b>",
    "category": "Heading",
    "url": "/language/objects#Parameterized_roles"
  },
  {
    "category": "Heading",
    "url": "/language/objects#Mixins_of_roles",
    "value": "Mixins of roles",
    "info": ": section in <b>Object orientation</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Object orientation</b>",
    "url": "/language/objects#Metaobject_programming_and_introspection",
    "value": "Metaobject programming and introspection"
  },
  {
    "value": "Block structure",
    "category": "Heading",
    "info": ": section in <b>Pod6</b>",
    "url": "/language/pod#Block_structure"
  },
  {
    "value": "Delimited blocks",
    "category": "Heading",
    "url": "/language/pod#Delimited_blocks",
    "info": ": section in <b>Pod6</b>"
  },
  {
    "url": "/language/pod#Configuration_information",
    "category": "Heading",
    "info": ": section in <b>Pod6</b>",
    "value": "Configuration information"
  },
  {
    "info": ": section in <b>Pod6</b>",
    "value": "Paragraph blocks",
    "url": "/language/pod#Paragraph_blocks",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Abbreviated blocks",
    "info": ": section in <b>Pod6</b>",
    "url": "/language/pod#Abbreviated_blocks"
  },
  {
    "value": "Declarator blocks",
    "url": "/language/pod#Declarator_blocks",
    "info": ": section in <b>Pod6</b>",
    "category": "Heading"
  },
  {
    "url": "/language/pod#Block_types",
    "category": "Heading",
    "value": "Block types",
    "info": ": section in <b>Pod6</b>"
  },
  {
    "url": "/language/pod#Headings",
    "info": ": section in <b>Pod6</b>",
    "value": "Headings",
    "category": "Heading"
  },
  {
    "value": "Ordinary paragraphs",
    "category": "Heading",
    "info": ": section in <b>Pod6</b>",
    "url": "/language/pod#Ordinary_paragraphs"
  },
  {
    "info": ": section in <b>Pod6</b>",
    "category": "Heading",
    "value": "Code blocks",
    "url": "/language/pod#Code_blocks"
  },
  {
    "category": "Heading",
    "value": "I/O blocks",
    "url": "/language/pod#I/O_blocks",
    "info": ": section in <b>Pod6</b>"
  },
  {
    "info": ": section in <b>Pod6</b>",
    "value": "Lists",
    "category": "Heading",
    "url": "/language/pod#Lists"
  },
  {
    "category": "Heading",
    "value": "Unordered lists",
    "url": "/language/pod#Unordered_lists",
    "info": ": section in <b>Pod6</b>"
  },
  {
    "info": ": section in <b>Pod6</b>",
    "category": "Heading",
    "url": "/language/pod#Definition_lists",
    "value": "Definition lists"
  },
  {
    "url": "/language/pod#Multi-level_lists",
    "info": ": section in <b>Pod6</b>",
    "value": "Multi-level lists",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Pod6</b>",
    "category": "Heading",
    "url": "/language/pod#Multi-paragraph_lists",
    "value": "Multi-paragraph lists"
  },
  {
    "url": "/language/pod#Tables",
    "value": "Tables",
    "category": "Heading",
    "info": ": section in <b>Pod6</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Pod6</b>",
    "url": "/language/pod#Pod6_comments",
    "value": "Pod6 comments"
  },
  {
    "category": "Heading",
    "value": "Semantic blocks",
    "info": ": section in <b>Pod6</b>",
    "url": "/language/pod#Semantic_blocks"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Pod6</b>",
    "value": "Formatting codes",
    "url": "/language/pod#Formatting_codes"
  },
  {
    "value": "Bold",
    "url": "/language/pod#Bold",
    "category": "Heading",
    "info": ": section in <b>Pod6</b>"
  },
  {
    "value": "Italic",
    "info": ": section in <b>Pod6</b>",
    "category": "Heading",
    "url": "/language/pod#Italic"
  },
  {
    "url": "/language/pod#Underlined",
    "info": ": section in <b>Pod6</b>",
    "value": "Underlined",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Pod6</b>",
    "category": "Heading",
    "value": "Code",
    "url": "/language/pod#Code"
  },
  {
    "value": "Links",
    "url": "/language/pod#Links",
    "info": ": section in <b>Pod6</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/pod#Placement_links",
    "value": "Placement links",
    "info": ": section in <b>Pod6</b>"
  },
  {
    "category": "Heading",
    "url": "/language/pod#Comments",
    "info": ": section in <b>Pod6</b>",
    "value": "Comments"
  },
  {
    "info": ": section in <b>Pod6</b>",
    "category": "Heading",
    "url": "/language/pod#Notes",
    "value": "Notes"
  },
  {
    "value": "Keyboard input",
    "category": "Heading",
    "url": "/language/pod#Keyboard_input",
    "info": ": section in <b>Pod6</b>"
  },
  {
    "value": "Replaceable",
    "url": "/language/pod#Replaceable",
    "category": "Heading",
    "info": ": section in <b>Pod6</b>"
  },
  {
    "url": "/language/pod#Terminal_output",
    "info": ": section in <b>Pod6</b>",
    "value": "Terminal output",
    "category": "Heading"
  },
  {
    "value": "Unicode",
    "url": "/language/pod#Unicode",
    "info": ": section in <b>Pod6</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Verbatim text",
    "info": ": section in <b>Pod6</b>",
    "url": "/language/pod#Verbatim_text"
  },
  {
    "value": "Indexing terms",
    "info": ": section in <b>Pod6</b>",
    "category": "Heading",
    "url": "/language/pod#Indexing_terms"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Pod6</b>",
    "value": "Rendering Pod",
    "url": "/language/pod#Rendering_Pod"
  },
  {
    "info": ": section in <b>Pod6</b>",
    "category": "Heading",
    "url": "/language/pod#HTML",
    "value": "HTML"
  },
  {
    "info": ": section in <b>Pod6</b>",
    "value": "Markdown",
    "category": "Heading",
    "url": "/language/pod#Markdown"
  },
  {
    "url": "/language/pod#Text",
    "category": "Heading",
    "value": "Text",
    "info": ": section in <b>Pod6</b>"
  },
  {
    "url": "/language/pod#Accessing_Pod",
    "value": "Accessing Pod",
    "info": ": section in <b>Pod6</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Colon Pair</b>",
    "category": "Heading",
    "value": "In language/glossary",
    "url": "/syntax/Colon%20Pair#language/glossarysyntaxColon Pair"
  },
  {
    "info": ": section in <b>days-in-year</b>",
    "value": "In type/Dateish",
    "url": "/routine/days-in-year#type/Dateishroutinemethod",
    "category": "Heading"
  },
  {
    "value": "In type/Parameter",
    "url": "/routine/invocant#type/Parameterroutinemethod",
    "category": "Heading",
    "info": ": section in <b>invocant</b>"
  },
  {
    "category": "Heading",
    "value": "In language/glossary",
    "info": ": section in <b>Propspec</b>",
    "url": "/syntax/Propspec#language/glossarysyntaxPropspec"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>≢</b>",
    "url": "/routine/%E2%89%A2#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "value": "In language/operators",
    "url": "/routine/-#language/operatorsroutineprefix",
    "category": "Heading",
    "info": ": section in <b>-</b>"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/-#language/operatorsroutineinfix",
    "info": ": section in <b>-</b>"
  },
  {
    "url": "/syntax/%26%3FBLOCK#language/variablessyntax&%3FBLOCK",
    "category": "Heading",
    "value": "In language/variables",
    "info": ": section in <b>&?BLOCK</b>"
  },
  {
    "url": "/routine/grab#type/Baggyroutinemethod",
    "value": "In type/Baggy",
    "info": ": section in <b>grab</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>asinh</b>",
    "category": "Heading",
    "url": "/routine/asinh#type/Coolroutineroutine",
    "value": "In type/Cool"
  },
  {
    "url": "/routine/so#language/operatorsroutineprefix",
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>so</b>"
  },
  {
    "info": ": section in <b>undefine</b>",
    "url": "/routine/undefine#type/independent-routinesroutinesub",
    "value": "In type/independent-routines",
    "category": "Heading"
  },
  {
    "info": ": section in <b>prompt</b>",
    "value": "In type/independent-routines",
    "category": "Heading",
    "url": "/routine/prompt#type/independent-routinesroutinesub"
  },
  {
    "url": "/routine/file#type/CallFrameroutinemethod",
    "value": "In type/CallFrame",
    "category": "Heading",
    "info": ": section in <b>file</b>"
  },
  {
    "info": ": section in <b>bind-stderr</b>",
    "url": "/routine/bind-stderr#type/Proc/Asyncroutinemethod",
    "category": "Heading",
    "value": "In type/Proc/Async"
  },
  {
    "value": "In type/Cool",
    "url": "/routine/unimatch#type/Coolroutineroutine",
    "info": ": section in <b>unimatch</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Twigil</b>",
    "category": "Heading",
    "url": "/syntax/Twigil#language/variablessyntaxTwigil",
    "value": "In language/variables"
  },
  {
    "category": "Heading",
    "url": "/syntax/Advent%20Calendar#language/glossarysyntaxAdvent Calendar",
    "info": ": section in <b>Advent Calendar</b>",
    "value": "In language/glossary"
  },
  {
    "value": "In type/Proc/Async",
    "category": "Heading",
    "info": ": section in <b>bind-stdout</b>",
    "url": "/routine/bind-stdout#type/Proc/Asyncroutinemethod"
  },
  {
    "info": ": section in <b>class X::Proc::Unsuccessful</b>",
    "value": "Methods",
    "category": "Heading",
    "url": "/type/X/Proc/Unsuccessful#Methods"
  },
  {
    "info": ": section in <b>class X::Proc::Unsuccessful</b>",
    "url": "/type/X/Proc/Unsuccessful#method_proc",
    "value": "method proc",
    "category": "Heading"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/%3D%3D%26gt%3B#language/operatorsroutineinfix",
    "info": ": section in <b>==></b>"
  },
  {
    "value": "In type/Signature",
    "url": "/routine/ACCEPTS#type/Signatureroutinemethod",
    "info": ": section in <b>ACCEPTS</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>ACCEPTS</b>",
    "value": "In type/Str",
    "category": "Heading",
    "url": "/routine/ACCEPTS#type/Strroutinemethod"
  },
  {
    "info": ": section in <b>ACCEPTS</b>",
    "value": "In type/Baggy",
    "url": "/routine/ACCEPTS#type/Baggyroutinemethod",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In type/Cool",
    "url": "/routine/cos#type/Coolroutineroutine",
    "info": ": section in <b>cos</b>"
  },
  {
    "url": "/routine/trans#type/Strroutinemethod",
    "info": ": section in <b>trans</b>",
    "category": "Heading",
    "value": "In type/Str"
  },
  {
    "info": ": section in <b>trans</b>",
    "value": "In type/Cool",
    "category": "Heading",
    "url": "/routine/trans#type/Coolroutinemethod"
  },
  {
    "category": "Heading",
    "value": "In type/Parameter",
    "info": ": section in <b>readonly</b>",
    "url": "/routine/readonly#type/Parameterroutinemethod"
  },
  {
    "value": "In type/Attribute",
    "info": ": section in <b>readonly</b>",
    "url": "/routine/readonly#type/Attributeroutinemethod",
    "category": "Heading"
  },
  {
    "url": "/syntax/state#language/variablessyntaxdeclarator",
    "category": "Heading",
    "value": "In language/variables",
    "info": ": section in <b>state</b>"
  },
  {
    "category": "Heading",
    "value": "In type/Str",
    "info": ": section in <b>chars</b>",
    "url": "/routine/chars#type/Strroutineroutine"
  },
  {
    "category": "Heading",
    "info": ": section in <b>chars</b>",
    "value": "In type/Cool",
    "url": "/routine/chars#type/Coolroutineroutine"
  },
  {
    "category": "Heading",
    "url": "/routine/UInt#type/Coolroutinemethod",
    "info": ": section in <b>UInt</b>",
    "value": "In type/Cool"
  },
  {
    "info": ": section in <b>pairs</b>",
    "url": "/routine/pairs#type/Baggyroutinemethod",
    "category": "Heading",
    "value": "In type/Baggy"
  },
  {
    "info": ": section in <b>sqrt</b>",
    "url": "/routine/sqrt#type/Coolroutineroutine",
    "category": "Heading",
    "value": "In type/Cool"
  },
  {
    "info": ": section in <b>Huffmanize</b>",
    "value": "In language/glossary",
    "url": "/syntax/Huffmanize#language/glossarysyntaxHuffmanize",
    "category": "Heading"
  },
  {
    "url": "/syntax/Reify#language/glossarysyntaxReify",
    "value": "In language/glossary",
    "info": ": section in <b>Reify</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>after</b>",
    "url": "/routine/after#language/operatorsroutineinfix"
  },
  {
    "url": "/routine/%28%26lt%3B%3D%29%2C%20infix%20%E2%8A%86#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>(<=), infix ⊆</b>"
  },
  {
    "url": "/routine/line#type/CallFrameroutinemethod",
    "value": "In type/CallFrame",
    "category": "Heading",
    "info": ": section in <b>line</b>"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>(^), infix ⊖</b>",
    "url": "/routine/%28%5E%29%2C%20infix%20%E2%8A%96#language/operatorsroutineinfix"
  },
  {
    "url": "/syntax/next#language/controlsyntaxnext",
    "value": "In language/control",
    "info": ": section in <b>next</b>",
    "category": "Heading"
  },
  {
    "value": "In type/Parameter",
    "category": "Heading",
    "info": ": section in <b>type</b>",
    "url": "/routine/type#type/Parameterroutinemethod"
  },
  {
    "info": ": section in <b>type</b>",
    "category": "Heading",
    "value": "In type/Attribute",
    "url": "/routine/type#type/Attributeroutinemethod"
  },
  {
    "category": "Heading",
    "info": ": section in <b>\\c</b>",
    "url": "/syntax/%5Cc#language/regexessyntax%5Cc",
    "value": "In language/regexes"
  },
  {
    "category": "Heading",
    "url": "/syntax/test%20suite#language/glossarysyntaxtest suite",
    "value": "In language/glossary",
    "info": ": section in <b>test suite</b>"
  },
  {
    "url": "/routine/get_value#type/Attributeroutinemethod",
    "info": ": section in <b>get_value</b>",
    "value": "In type/Attribute",
    "category": "Heading"
  },
  {
    "url": "/language/faq#General",
    "info": ": section in <b>FAQ</b>",
    "value": "General",
    "category": "Heading"
  },
  {
    "url": "/language/faq#What's_the_difference_between_Raku,_Rakudo_and_Perl_6%3F",
    "category": "Heading",
    "value": "What's the difference between Raku, Rakudo and Perl 6?",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "value": "When was Raku released?",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#When_was_Raku_released%3F",
    "category": "Heading"
  },
  {
    "url": "/language/faq#Is_there_a_Raku_version_6.0.0%3F",
    "value": "Is there a Raku version 6.0.0?",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "When was v6.d released?",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#When_was_v6.d_released%3F"
  },
  {
    "url": "/language/faq#As_a_Raku_user,_what_should_I_install%3F",
    "info": ": section in <b>FAQ</b>",
    "value": "As a Raku user, what should I install?",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>FAQ</b>",
    "value": "As an advanced user I want to track Rakudo development.",
    "url": "/language/faq#As_an_advanced_user_I_want_to_track_Rakudo_development."
  },
  {
    "value": "Where can I find good documentation on Raku?",
    "url": "/language/faq#Where_can_I_find_good_documentation_on_Raku%3F",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>FAQ</b>",
    "value": "Can I get some books about Raku?",
    "url": "/language/faq#Can_I_get_some_books_about_Raku%3F",
    "category": "Heading"
  },
  {
    "url": "/language/faq#What_is_the_Raku_specification%3F",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading",
    "value": "What is the Raku specification?"
  },
  {
    "category": "Heading",
    "url": "/language/faq#Is_there_a_glossary_of_Raku_related_terms%3F",
    "info": ": section in <b>FAQ</b>",
    "value": "Is there a glossary of Raku related terms?"
  },
  {
    "category": "Heading",
    "url": "/language/faq#I'm_a_Perl_programmer._Where_is_a_list_of_differences_between_Perl_and_Raku%3F",
    "info": ": section in <b>FAQ</b>",
    "value": "I'm a Perl programmer. Where is a list of differences between Perl and Raku?"
  },
  {
    "value": "I'm a Ruby programmer looking for quickstart type docs?",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#I'm_a_Ruby_programmer_looking_for_quickstart_type_docs%3F"
  },
  {
    "info": ": section in <b>FAQ</b>",
    "value": "Modules",
    "category": "Heading",
    "url": "/language/faq#Modules"
  },
  {
    "url": "/language/faq#Is_there_a_repository_of_third_party_library_modules_for_Raku%3F",
    "category": "Heading",
    "value": "Is there a repository of third party library modules for Raku?",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "info": ": section in <b>FAQ</b>",
    "category": "Heading",
    "url": "/language/faq#Is_there_a_perldoc_(command_line_documentation_viewer)_for_Raku%3F",
    "value": "Is there a perldoc (command line documentation viewer) for Raku?"
  },
  {
    "url": "/language/faq#Can_I_use_Perl_modules_from_Raku%3F",
    "category": "Heading",
    "value": "Can I use Perl modules from Raku?",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "info": ": section in <b>FAQ</b>",
    "category": "Heading",
    "url": "/language/faq#Can_I_use_C_and_C++_from_Raku%3F",
    "value": "Can I use C and C++ from Raku?"
  },
  {
    "value": "Nativecall can't find libfoo.so and I only have libfoo.so.1.2!",
    "url": "/language/faq#Nativecall_can't_find_libfoo.so_and_I_only_have_libfoo.so.1.2!",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "value": "Where have all the traditional UNIX library functions gone?",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#Where_have_all_the_traditional_UNIX_library_functions_gone%3F"
  },
  {
    "category": "Heading",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#Does_Rakudo_have_a_core_standard_library%3F",
    "value": "Does Rakudo have a core standard library?"
  },
  {
    "value": "Is there something like B::Deparse/How can I get hold of the AST?",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#Is_there_something_like_B::Deparse/How_can_I_get_hold_of_the_AST%3F"
  },
  {
    "value": "What is precompilation?",
    "category": "Heading",
    "url": "/language/faq#What_is_precompilation%3F",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "category": "Heading",
    "url": "/language/faq#Can_I_have_circular_dependencies_between_modules%3F",
    "value": "Can I have circular dependencies between modules?",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "url": "/language/faq#Common_operations",
    "value": "Common operations",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#String:_How_can_I_parse_and_get_a_number_from_a_string%3F",
    "category": "Heading",
    "value": "String: How can I parse and get a number from a string?"
  },
  {
    "value": "String: How can I check if a string contains a substring and if so, how can I get indices of matches?",
    "url": "/language/faq#String:_How_can_I_check_if_a_string_contains_a_substring_and_if_so,_how_can_I_get_indices_of_matches%3F",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>FAQ</b>",
    "value": "String: How can I get the hexadecimal representation of a string?",
    "url": "/language/faq#String:_How_can_I_get_the_hexadecimal_representation_of_a_string%3F"
  },
  {
    "value": "String: How can I remove from a string some characters by index?",
    "url": "/language/faq#String:_How_can_I_remove_from_a_string_some_characters_by_index%3F",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "String: How can I split a string in equal parts?",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#String:_How_can_I_split_a_string_in_equal_parts%3F"
  },
  {
    "info": ": section in <b>FAQ</b>",
    "value": "Language features",
    "url": "/language/faq#Language_features",
    "category": "Heading"
  },
  {
    "url": "/language/faq#How_can_I_dump_Raku_data_structures_(like_Perl_Data::Dumper_and_similar)%3F",
    "category": "Heading",
    "value": "How can I dump Raku data structures (like Perl Data::Dumper and similar)?",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#How_can_I_get_command_line_history_in_the_Raku_prompt_(REPL)%3F",
    "value": "How can I get command line history in the Raku prompt (REPL)?"
  },
  {
    "url": "/language/faq#Why_is_the_Rakudo_compiler_so_apologetic%3F",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading",
    "value": "Why is the Rakudo compiler so apologetic?"
  },
  {
    "info": ": section in <b>FAQ</b>",
    "category": "Heading",
    "value": "What is (Any)?",
    "url": "/language/faq#What_is_(Any)%3F"
  },
  {
    "url": "/language/faq#What_is_so%3F",
    "value": "What is so?",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "value": "What are those :D and :U things in signatures?",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading",
    "url": "/language/faq#What_are_those_:D_and_:U_things_in_signatures%3F"
  },
  {
    "url": "/language/faq#What_is_the_-->_thing_in_the_signature%3F",
    "info": ": section in <b>FAQ</b>",
    "value": "What is the --> thing in the signature?",
    "category": "Heading"
  },
  {
    "info": ": section in <b>FAQ</b>",
    "value": "How can I extract the values from a Junction?",
    "url": "/language/faq#How_can_I_extract_the_values_from_a_Junction%3F",
    "category": "Heading"
  },
  {
    "url": "/language/faq#If_Str_is_immutable,_how_does_s///_work%3F_If_Int_is_immutable,_how_does_$i++_work%3F",
    "info": ": section in <b>FAQ</b>",
    "value": "If Str is immutable, how does s/// work? If Int is immutable, how does $i++ work?",
    "category": "Heading"
  },
  {
    "value": "What's up with array references and automatic dereferencing? Do I need the @ sigil?",
    "url": "/language/faq#What's_up_with_array_references_and_automatic_dereferencing%3F_Do_I_need_the_@_sigil%3F",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading"
  },
  {
    "value": "Why sigils? Couldn't you do without them?",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#Why_sigils%3F_Couldn't_you_do_without_them%3F",
    "category": "Heading"
  },
  {
    "value": "\"Type Str does not support associative indexing.\"",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#\\\"Type_Str_does_not_support_associative_indexing.\\\"",
    "category": "Heading"
  },
  {
    "url": "/language/faq#Does_Raku_have_coroutines%3F_What_about_yield%3F",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading",
    "value": "Does Raku have coroutines? What about yield?"
  },
  {
    "value": "Why can't I initialize private attributes from the new method, and how can I fix this?",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#Why_can't_I_initialize_private_attributes_from_the_new_method,_and_how_can_I_fix_this%3F"
  },
  {
    "category": "Heading",
    "url": "/language/faq#How_and_why_do_say,_put_and_print_differ%3F",
    "value": "How and why do say, put and print differ?",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "url": "/language/faq#What's_the_difference_between_token_and_rule_%3F",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading",
    "value": "What's the difference between token and rule ?"
  },
  {
    "value": "What's the difference between die and fail?",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#What's_the_difference_between_die_and_fail%3F",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/faq#What's_the_difference_between_Pointer_and_OpaquePointer%3F",
    "value": "What's the difference between Pointer and OpaquePointer?",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "category": "Heading",
    "value": "You can have colonpairs in identifiers. What's the justification?",
    "url": "/language/faq#You_can_have_colonpairs_in_identifiers._What's_the_justification%3F",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "value": "How do most people enter unicode characters?",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#How_do_most_people_enter_unicode_characters%3F"
  },
  {
    "value": "Raku implementation",
    "url": "/language/faq#Raku_implementation",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "url": "/language/faq#What_Raku_implementations_are_available%3F",
    "value": "What Raku implementations are available?",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "url": "/language/faq#What_language_is_Rakudo_written_in%3F",
    "value": "What language is Rakudo written in?",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "url": "/language/faq#What_language_is_NQP_written_in%3F",
    "value": "What language is NQP written in?",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "value": "Is Raku Lisp?",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading",
    "url": "/language/faq#Is_Raku_Lisp%3F"
  },
  {
    "url": "/language/faq#Can_I_compile_my_script_to_a_standalone_executable%3F",
    "category": "Heading",
    "info": ": section in <b>FAQ</b>",
    "value": "Can I compile my script to a standalone executable?"
  },
  {
    "value": "Raku distribution",
    "url": "/language/faq#Raku_distribution",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/faq#When_will_the_next_version_of_Rakudo_Star_be_released%3F",
    "info": ": section in <b>FAQ</b>",
    "value": "When will the next version of Rakudo Star be released?"
  },
  {
    "url": "/language/faq#Metaquestions_and_advocacy",
    "value": "Metaquestions and advocacy",
    "info": ": section in <b>FAQ</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>FAQ</b>",
    "url": "/language/faq#Why_was_Raku_originally_called_Perl_6%3F",
    "value": "Why was Raku originally called Perl 6?",
    "category": "Heading"
  },
  {
    "info": ": section in <b>FAQ</b>",
    "value": "When will Raku be ready? Is it ready now?",
    "url": "/language/faq#When_will_Raku_be_ready%3F_Is_it_ready_now%3F",
    "category": "Heading"
  },
  {
    "value": "Why should I learn Raku? What's so great about it?",
    "category": "Heading",
    "url": "/language/faq#Why_should_I_learn_Raku%3F_What's_so_great_about_it%3F",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "url": "/language/faq#Is_Raku_fast_enough_for_me%3F",
    "category": "Heading",
    "value": "Is Raku fast enough for me?",
    "info": ": section in <b>FAQ</b>"
  },
  {
    "value": "In type/Attribute",
    "info": ": section in <b>is DEPRECATED (Attribute)</b>",
    "category": "Heading",
    "url": "/syntax/is%20DEPRECATED%20%28Attribute%29#type/Attributesyntaxis DEPRECATED (Attribute)"
  },
  {
    "url": "/language/hashmap#The_associative_role_and_associative_classes",
    "value": "The associative role and associative classes",
    "info": ": section in <b>Hashes and maps</b>",
    "category": "Heading"
  },
  {
    "url": "/language/hashmap#Mutable_hashes_and_immutable_maps",
    "category": "Heading",
    "value": "Mutable hashes and immutable maps",
    "info": ": section in <b>Hashes and maps</b>"
  },
  {
    "url": "/language/hashmap#Hash_assignment",
    "value": "Hash assignment",
    "category": "Heading",
    "info": ": section in <b>Hashes and maps</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Hashes and maps</b>",
    "url": "/language/hashmap#Hash_slices",
    "value": "Hash slices"
  },
  {
    "value": "Non-string keys (object hash)",
    "category": "Heading",
    "url": "/language/hashmap#Non-string_keys_(object_hash)",
    "info": ": section in <b>Hashes and maps</b>"
  },
  {
    "value": "Constraint value types",
    "url": "/language/hashmap#Constraint_value_types",
    "info": ": section in <b>Hashes and maps</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Hashes and maps</b>",
    "url": "/language/hashmap#Looping_over_hash_keys_and_values",
    "value": "Looping over hash keys and values"
  },
  {
    "value": "In place editing of values",
    "info": ": section in <b>Hashes and maps</b>",
    "category": "Heading",
    "url": "/language/hashmap#In_place_editing_of_values"
  },
  {
    "value": "In language/glossary",
    "category": "Heading",
    "info": ": section in <b>pugs</b>",
    "url": "/syntax/pugs#language/glossarysyntaxpugs"
  },
  {
    "value": "In language/101-basics",
    "category": "Heading",
    "url": "/syntax/hash%20%28Basics%29#language/101-basicssyntaxhash (Basics)",
    "info": ": section in <b>hash (Basics)</b>"
  },
  {
    "url": "/routine/new#type/Proc/Asyncroutinemethod",
    "value": "In type/Proc/Async",
    "info": ": section in <b>new</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In type/Int",
    "url": "/routine/new#type/Introutinemethod",
    "info": ": section in <b>new</b>"
  },
  {
    "url": "/syntax/roast#language/glossarysyntaxroast",
    "category": "Heading",
    "info": ": section in <b>roast</b>",
    "value": "In language/glossary"
  },
  {
    "value": "In language/operators",
    "url": "/routine/%25%25#language/operatorsroutineinfix",
    "category": "Heading",
    "info": ": section in <b>%%</b>"
  },
  {
    "value": "In type/Attribute",
    "category": "Heading",
    "info": ": section in <b>set_value</b>",
    "url": "/routine/set_value#type/Attributeroutinemethod"
  },
  {
    "url": "/syntax/loop#language/controlsyntaxloop",
    "info": ": section in <b>loop</b>",
    "value": "In language/control",
    "category": "Heading"
  },
  {
    "info": ": section in <b>System interaction</b>",
    "value": "Getting arguments through the command line",
    "url": "/language/system#Getting_arguments_through_the_command_line",
    "category": "Heading"
  },
  {
    "info": ": section in <b>System interaction</b>",
    "value": "Getting arguments interactively",
    "category": "Heading",
    "url": "/language/system#Getting_arguments_interactively"
  },
  {
    "value": "Running programs synchronously and asynchronously",
    "category": "Heading",
    "url": "/language/system#Running_programs_synchronously_and_asynchronously",
    "info": ": section in <b>System interaction</b>"
  },
  {
    "info": ": section in <b>System interaction</b>",
    "category": "Heading",
    "value": "Making operating system calls through the native API",
    "url": "/language/system#Making_operating_system_calls_through_the_native_API"
  },
  {
    "info": ": section in <b>$$ (Perl)</b>",
    "url": "/syntax/%24%24%20%28Perl%29#language/5to6-perlvarsyntax$$ (Perl)",
    "value": "In language/5to6-perlvar",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/routine/flat#type/independent-routinesroutinesub",
    "value": "In type/independent-routines",
    "info": ": section in <b>flat</b>"
  },
  {
    "info": ": section in <b>exit</b>",
    "value": "In type/independent-routines",
    "category": "Heading",
    "url": "/routine/exit#type/independent-routinesroutinesub"
  },
  {
    "url": "/syntax/Named%20captures#language/regexessyntaxNamed captures",
    "value": "In language/regexes",
    "info": ": section in <b>Named captures</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "value": "Lexical conventions",
    "url": "/language/regexes#Lexical_conventions",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Regexes</b>",
    "value": "Anonymous regex definition syntax",
    "url": "/language/regexes#Anonymous_regex_definition_syntax"
  },
  {
    "url": "/language/regexes#Named_regex_definition_syntax",
    "value": "Named regex definition syntax",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "value": "Regex readability: whitespace and comments",
    "url": "/language/regexes#Regex_readability:_whitespace_and_comments"
  },
  {
    "url": "/language/regexes#Match_syntax",
    "value": "Match syntax",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "url": "/language/regexes#Literals_and_metacharacters",
    "info": ": section in <b>Regexes</b>",
    "value": "Literals and metacharacters",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "value": "Wildcards",
    "category": "Heading",
    "url": "/language/regexes#Wildcards"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "value": "Character classes",
    "url": "/language/regexes#Character_classes"
  },
  {
    "url": "/language/regexes#Backslashed_character_classes",
    "value": "Backslashed character classes",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "url": "/language/regexes#%5Cn_and_%5CN",
    "info": ": section in <b>Regexes</b>",
    "value": "\\n and \\N",
    "category": "Heading"
  },
  {
    "value": "\\t and \\T",
    "url": "/language/regexes#%5Ct_and_%5CT",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "url": "/language/regexes#%5Ch_and_%5CH",
    "value": "\\h and \\H",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "\\v and \\V",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#%5Cv_and_%5CV"
  },
  {
    "url": "/language/regexes#%5Cs_and_%5CS",
    "value": "\\s and \\S",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#%5Cd_and_%5CD",
    "category": "Heading",
    "value": "\\d and \\D"
  },
  {
    "value": "\\w and \\W",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#%5Cw_and_%5CW"
  },
  {
    "category": "Heading",
    "value": "\\c and \\C",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#%5Cc_and_%5CC"
  },
  {
    "value": "\\x and \\X",
    "url": "/language/regexes#%5Cx_and_%5CX",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "url": "/language/regexes#Predefined_character_classes",
    "value": "Predefined character classes"
  },
  {
    "category": "Heading",
    "url": "/language/regexes#Predefined_Regexes",
    "info": ": section in <b>Regexes</b>",
    "value": "Predefined Regexes"
  },
  {
    "value": "Unicode properties",
    "url": "/language/regexes#Unicode_properties",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "url": "/language/regexes#Enumerated_character_classes_and_ranges",
    "value": "Enumerated character classes and ranges"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "url": "/language/regexes#Quantifiers",
    "value": "Quantifiers"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#One_or_more:_+",
    "value": "One or more: +",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "value": "Zero or more: *",
    "url": "/language/regexes#Zero_or_more:_*",
    "category": "Heading"
  },
  {
    "value": "Zero or one: ?",
    "category": "Heading",
    "url": "/language/regexes#Zero_or_one:_%3F",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "url": "/language/regexes#General_quantifier:_**_min..max",
    "info": ": section in <b>Regexes</b>",
    "value": "General quantifier: ** min..max",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Regexes</b>",
    "value": "Modified quantifier: %, %%",
    "url": "/language/regexes#Modified_quantifier:_%,_%%"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "value": "Preventing backtracking: :",
    "url": "/language/regexes#Preventing_backtracking:_:"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Greedy_versus_frugal_quantifiers:_%3F",
    "value": "Greedy versus frugal quantifiers: ?",
    "category": "Heading"
  },
  {
    "url": "/language/regexes#Alternation:_||",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "value": "Alternation: ||"
  },
  {
    "value": "Longest alternation: |",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Longest_alternation:_|"
  },
  {
    "value": "Quoted lists are LTM matches",
    "category": "Heading",
    "url": "/language/regexes#Quoted_lists_are_LTM_matches",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "value": "Conjunction: &&",
    "url": "/language/regexes#Conjunction:_&&",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/regexes#Conjunction:_&",
    "info": ": section in <b>Regexes</b>",
    "value": "Conjunction: &"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "url": "/language/regexes#Anchors",
    "value": "Anchors"
  },
  {
    "url": "/language/regexes#Start_of_string_and_end_of_string",
    "category": "Heading",
    "value": "Start of string and end of string",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Start_of_line_and_end_of_line",
    "category": "Heading",
    "value": "Start of line and end of line"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Regexes</b>",
    "value": "Word boundary",
    "url": "/language/regexes#Word_boundary"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "url": "/language/regexes#Left_and_right_word_boundary",
    "value": "Left and right word boundary"
  },
  {
    "url": "/language/regexes#Summary_of_anchors",
    "value": "Summary of anchors",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "url": "/language/regexes#Zero-width_assertions",
    "value": "Zero-width assertions",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "value": "Lookaround assertions",
    "category": "Heading",
    "url": "/language/regexes#Lookaround_assertions",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "url": "/language/regexes#Lookahead_assertions",
    "value": "Lookahead assertions",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "url": "/language/regexes#Lookbehind_assertions",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "value": "Lookbehind assertions"
  },
  {
    "value": "Grouping and capturing",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Grouping_and_capturing",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/regexes#Capturing",
    "value": "Capturing",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Non-capturing_grouping",
    "value": "Non-capturing grouping",
    "category": "Heading"
  },
  {
    "value": "Capture numbers",
    "url": "/language/regexes#Capture_numbers",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "category": "Heading",
    "value": "Named captures",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Named_captures"
  },
  {
    "category": "Heading",
    "value": "Capture markers: <( )>",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Capture_markers:_<(_)>"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "value": "Substitution",
    "url": "/language/regexes#Substitution"
  },
  {
    "category": "Heading",
    "value": "Replacing string literals",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Replacing_string_literals"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Wildcards_and_character_classes",
    "category": "Heading",
    "value": "Wildcards and character classes"
  },
  {
    "url": "/language/regexes#Capturing_groups",
    "value": "Capturing groups",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "value": "Common adverbs",
    "url": "/language/regexes#Common_adverbs",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "url": "/language/regexes#S///_non-destructive_substitution",
    "info": ": section in <b>Regexes</b>",
    "value": "S/// non-destructive substitution",
    "category": "Heading"
  },
  {
    "value": "Tilde for nesting structures",
    "url": "/language/regexes#Tilde_for_nesting_structures",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Recursive_Regexes",
    "value": "Recursive Regexes"
  },
  {
    "category": "Heading",
    "value": "Subrules",
    "url": "/language/regexes#Subrules",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "category": "Heading",
    "value": "Regex interpolation",
    "url": "/language/regexes#Regex_interpolation"
  },
  {
    "category": "Heading",
    "value": "Regex Boolean condition check",
    "url": "/language/regexes#Regex_Boolean_condition_check",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Adverbs",
    "value": "Adverbs",
    "category": "Heading"
  },
  {
    "value": "Regex adverbs",
    "category": "Heading",
    "url": "/language/regexes#Regex_adverbs",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "category": "Heading",
    "value": "Ignorecase",
    "url": "/language/regexes#Ignorecase",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Ignoremark",
    "value": "Ignoremark"
  },
  {
    "url": "/language/regexes#Ratchet",
    "value": "Ratchet",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "value": "Sigspace",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Sigspace"
  },
  {
    "value": "Perl compatibility adverb",
    "category": "Heading",
    "url": "/language/regexes#Perl_compatibility_adverb",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "value": "Matching adverbs",
    "category": "Heading",
    "url": "/language/regexes#Matching_adverbs",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "url": "/language/regexes#Positional_adverbs",
    "value": "Positional adverbs",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "value": "Counting",
    "url": "/language/regexes#Counting",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "value": "Continue",
    "url": "/language/regexes#Continue",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "url": "/language/regexes#Exhaustive",
    "value": "Exhaustive",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "url": "/language/regexes#Global",
    "category": "Heading",
    "value": "Global",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Pos",
    "value": "Pos",
    "category": "Heading"
  },
  {
    "value": "Overlap",
    "url": "/language/regexes#Overlap",
    "category": "Heading",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "value": "Substitution adverbs",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Substitution_adverbs",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Samecase",
    "category": "Heading",
    "value": "Samecase"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Regexes</b>",
    "url": "/language/regexes#Samemark",
    "value": "Samemark"
  },
  {
    "url": "/language/regexes#Samespace",
    "info": ": section in <b>Regexes</b>",
    "value": "Samespace",
    "category": "Heading"
  },
  {
    "value": "Backtracking",
    "category": "Heading",
    "url": "/language/regexes#Backtracking",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "value": "$/ changes each time a regular expression is matched",
    "category": "Heading",
    "url": "/language/regexes#$/_changes_each_time_a_regular_expression_is_matched",
    "info": ": section in <b>Regexes</b>"
  },
  {
    "value": "Best practices and gotchas",
    "url": "/language/regexes#Best_practices_and_gotchas",
    "info": ": section in <b>Regexes</b>",
    "category": "Heading"
  },
  {
    "url": "/syntax/wrapped%20routines#language/functionssyntaxwrapped routines",
    "value": "In language/functions",
    "category": "Heading",
    "info": ": section in <b>wrapped routines</b>"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "url": "/routine/lt#language/operatorsroutineinfix",
    "info": ": section in <b>lt</b>"
  },
  {
    "url": "/routine/%3F%3F%20%21%21#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators",
    "info": ": section in <b>?? !!</b>"
  },
  {
    "info": ": section in <b>w</b>",
    "category": "Heading",
    "url": "/routine/w#type/Proc/Asyncroutinemethod",
    "value": "In type/Proc/Async"
  },
  {
    "category": "Heading",
    "url": "/routine/Capture#type/Signatureroutinemethod",
    "value": "In type/Signature",
    "info": ": section in <b>Capture</b>"
  },
  {
    "category": "Heading",
    "url": "/routine/Capture#type/Strroutinemethod",
    "value": "In type/Str",
    "info": ": section in <b>Capture</b>"
  },
  {
    "value": "In type/Int",
    "info": ": section in <b>Capture</b>",
    "category": "Heading",
    "url": "/routine/Capture#type/Introutinemethod"
  },
  {
    "info": ": section in <b>diffy</b>",
    "value": "In language/glossary",
    "category": "Heading",
    "url": "/syntax/diffy#language/glossarysyntaxdiffy"
  },
  {
    "info": ": section in <b>elems</b>",
    "category": "Heading",
    "url": "/routine/elems#type/Baggyroutinemethod",
    "value": "In type/Baggy"
  },
  {
    "info": ": section in <b>run</b>",
    "url": "/routine/run#type/independent-routinesroutinesub",
    "category": "Heading",
    "value": "In type/independent-routines"
  },
  {
    "value": "In language/regexes",
    "info": ": section in <b>S/// non-destructive substitution</b>",
    "url": "/syntax/S%2F%2F%2F%20non-destructive%20substitution#language/regexessyntaxS/// non-destructive substitution",
    "category": "Heading"
  },
  {
    "value": "In language/glossary",
    "category": "Heading",
    "info": ": section in <b>Tight</b>",
    "url": "/syntax/Tight#language/glossarysyntaxTight"
  },
  {
    "info": ": section in <b>prefix</b>",
    "category": "Heading",
    "value": "In type/Parameter",
    "url": "/routine/prefix#type/Parameterroutinemethod"
  },
  {
    "url": "/syntax/Backtracking#language/glossarysyntaxBacktracking",
    "value": "In language/glossary",
    "category": "Heading",
    "info": ": section in <b>Backtracking</b>"
  },
  {
    "info": ": section in <b>=~=</b>",
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/%3D~%3D#language/operatorsroutineinfix"
  },
  {
    "info": ": section in <b>Stub</b>",
    "category": "Heading",
    "url": "/syntax/Stub#language/glossarysyntaxStub",
    "value": "In language/glossary"
  },
  {
    "category": "Heading",
    "value": "In language/5to6-perlvar",
    "info": ": section in <b>$\" (Perl)</b>",
    "url": "/syntax/%24%22%20%28Perl%29#language/5to6-perlvarsyntax$\\\" (Perl)"
  },
  {
    "category": "Heading",
    "info": ": section in <b>\\n</b>",
    "url": "/syntax/%5Cn#language/regexessyntax%5Cn",
    "value": "In language/regexes"
  },
  {
    "value": "In type/Proc/Async",
    "url": "/routine/args#type/Proc/Asyncroutinemethod",
    "category": "Heading",
    "info": ": section in <b>args</b>"
  },
  {
    "url": "/routine/~%7C#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>~|</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>(>=), infix ⊇</b>",
    "url": "/routine/%28%26gt%3B%3D%29%2C%20infix%20%E2%8A%87#language/operatorsroutineinfix",
    "value": "In language/operators"
  },
  {
    "url": "/syntax/6model#language/glossarysyntax6model",
    "category": "Heading",
    "value": "In language/glossary",
    "info": ": section in <b>6model</b>"
  },
  {
    "value": "In type/Proc/Async",
    "category": "Heading",
    "url": "/routine/kill#type/Proc/Asyncroutinemethod",
    "info": ": section in <b>kill</b>"
  },
  {
    "info": ": section in <b>^..^</b>",
    "url": "/routine/%5E..%5E#language/operatorsroutineinfix",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>( )</b>",
    "url": "/routine/%28%20%29#language/operatorsroutineterm"
  },
  {
    "category": "Heading",
    "url": "/routine/%28%20%29#language/operatorsroutinepostcircumfix",
    "value": "In language/operators",
    "info": ": section in <b>( )</b>"
  },
  {
    "url": "/routine/unicmp#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>unicmp</b>"
  },
  {
    "value": "Methods",
    "url": "/type/Int#Methods",
    "info": ": section in <b>class Int</b>",
    "category": "Heading"
  },
  {
    "url": "/type/Int#method_new",
    "category": "Heading",
    "info": ": section in <b>class Int</b>",
    "value": "method new"
  },
  {
    "url": "/type/Int#method_Capture",
    "info": ": section in <b>class Int</b>",
    "value": "method Capture",
    "category": "Heading"
  },
  {
    "value": "routine chr",
    "category": "Heading",
    "info": ": section in <b>class Int</b>",
    "url": "/type/Int#routine_chr"
  },
  {
    "info": ": section in <b>class Int</b>",
    "value": "routine expmod",
    "url": "/type/Int#routine_expmod",
    "category": "Heading"
  },
  {
    "value": "method polymod",
    "info": ": section in <b>class Int</b>",
    "category": "Heading",
    "url": "/type/Int#method_polymod"
  },
  {
    "value": "routine is-prime",
    "url": "/type/Int#routine_is-prime",
    "info": ": section in <b>class Int</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>class Int</b>",
    "category": "Heading",
    "url": "/type/Int#routine_lsb",
    "value": "routine lsb"
  },
  {
    "info": ": section in <b>class Int</b>",
    "url": "/type/Int#routine_msb",
    "category": "Heading",
    "value": "routine msb"
  },
  {
    "value": "routine unival",
    "category": "Heading",
    "info": ": section in <b>class Int</b>",
    "url": "/type/Int#routine_unival"
  },
  {
    "category": "Heading",
    "info": ": section in <b>class Int</b>",
    "url": "/type/Int#method_Range",
    "value": "method Range"
  },
  {
    "info": ": section in <b>class Int</b>",
    "url": "/type/Int#method_Bridge",
    "value": "method Bridge",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Operators",
    "url": "/type/Int#Operators",
    "info": ": section in <b>class Int</b>"
  },
  {
    "info": ": section in <b>class Int</b>",
    "url": "/type/Int#infix_div",
    "value": "infix div",
    "category": "Heading"
  },
  {
    "url": "/syntax/Damian%20Conway#language/glossarysyntaxDamian Conway",
    "info": ": section in <b>Damian Conway</b>",
    "category": "Heading",
    "value": "In language/glossary"
  },
  {
    "url": "/language/5to6-perlvar#DESCRIPTION",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading",
    "value": "DESCRIPTION"
  },
  {
    "value": "NOTE",
    "category": "Heading",
    "url": "/language/5to6-perlvar#NOTE",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "category": "Heading",
    "value": "SPECIAL VARIABLES",
    "url": "/language/5to6-perlvar#SPECIAL_VARIABLES",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "url": "/language/5to6-perlvar#General_variables",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading",
    "value": "General variables"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$ARG, $_",
    "url": "/language/5to6-perlvar#$ARG,_$_"
  },
  {
    "url": "/language/5to6-perlvar#@ARG,_@_",
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "@ARG, @_"
  },
  {
    "url": "/language/5to6-perlvar#$LIST_SEPARATOR,_$\\\"",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$LIST_SEPARATOR, $\"",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$PROCESS_ID, $PID, $$",
    "url": "/language/5to6-perlvar#$PROCESS_ID,_$PID,_$$",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$PROGRAM_NAME, $0",
    "url": "/language/5to6-perlvar#$PROGRAM_NAME,_$0"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#$REAL_GROUP_ID,_$GID,_$(",
    "value": "$REAL_GROUP_ID, $GID, $(",
    "category": "Heading"
  },
  {
    "value": "$EFFECTIVE_GROUP_ID, $EGID, $)",
    "url": "/language/5to6-perlvar#$EFFECTIVE_GROUP_ID,_$EGID,_$)",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading"
  },
  {
    "url": "/language/5to6-perlvar#$REAL_USER_ID,_$UID,_$<",
    "category": "Heading",
    "value": "$REAL_USER_ID, $UID, $<",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "url": "/language/5to6-perlvar#$EFFECTIVE_USER_ID,_$EUID,_$>",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$EFFECTIVE_USER_ID, $EUID, $>",
    "category": "Heading"
  },
  {
    "value": "$SUBSCRIPT_SEPARATOR, $SUBSEP, $;",
    "category": "Heading",
    "url": "/language/5to6-perlvar#$SUBSCRIPT_SEPARATOR,_$SUBSEP,_$;",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading",
    "url": "/language/5to6-perlvar#$a,_$b",
    "value": "$a, $b"
  },
  {
    "url": "/language/5to6-perlvar#%ENV",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "%ENV",
    "category": "Heading"
  },
  {
    "value": "$OLD_PERL_VERSION, $]",
    "category": "Heading",
    "url": "/language/5to6-perlvar#$OLD_PERL_VERSION,_$]",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "url": "/language/5to6-perlvar#$SYSTEM_FD_MAX,_$^F",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading",
    "value": "$SYSTEM_FD_MAX, $^F"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#@F",
    "category": "Heading",
    "value": "@F"
  },
  {
    "value": "@INC",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading",
    "url": "/language/5to6-perlvar#@INC"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "%INC",
    "category": "Heading",
    "url": "/language/5to6-perlvar#%INC"
  },
  {
    "value": "$INPLACE_EDIT, $^I",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#$INPLACE_EDIT,_$^I",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$^M",
    "url": "/language/5to6-perlvar#$^M",
    "category": "Heading"
  },
  {
    "url": "/language/5to6-perlvar#$OSNAME,_$^O",
    "value": "$OSNAME, $^O",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading"
  },
  {
    "value": "%SIG",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading",
    "url": "/language/5to6-perlvar#%SIG"
  },
  {
    "url": "/language/5to6-perlvar#$BASETIME,_$^T",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading",
    "value": "$BASETIME, $^T"
  },
  {
    "category": "Heading",
    "url": "/language/5to6-perlvar#$PERL_VERSION,_$^V",
    "value": "$PERL_VERSION, $^V",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "value": "${^WIN32_SLOPPY_STAT}",
    "url": "/language/5to6-perlvar#${^WIN32_SLOPPY_STAT}",
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "category": "Heading",
    "url": "/language/5to6-perlvar#$EXECUTABLE_NAME,_$^X",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$EXECUTABLE_NAME, $^X"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "Variables related to regular expressions",
    "url": "/language/5to6-perlvar#Variables_related_to_regular_expressions",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "Performance issues",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#Performance_issues"
  },
  {
    "value": "$<digits> ($1, $2, ...)",
    "url": "/language/5to6-perlvar#$<digits>_($1,_$2,_...)",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$MATCH, $&",
    "url": "/language/5to6-perlvar#$MATCH,_$&",
    "category": "Heading"
  },
  {
    "url": "/language/5to6-perlvar#${^MATCH}",
    "value": "${^MATCH}",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "url": "/language/5to6-perlvar#$PREMATCH,_$`",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$PREMATCH, $`"
  },
  {
    "value": "${^PREMATCH}",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#${^PREMATCH}",
    "category": "Heading"
  },
  {
    "url": "/language/5to6-perlvar#$POSTMATCH,_$'",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$POSTMATCH, $'",
    "category": "Heading"
  },
  {
    "url": "/language/5to6-perlvar#${^POSTMATCH}",
    "value": "${^POSTMATCH}",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#$LAST_PAREN_MATCH,_$+",
    "category": "Heading",
    "value": "$LAST_PAREN_MATCH, $+"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$LAST_SUBMATCH_RESULT, $^N",
    "url": "/language/5to6-perlvar#$LAST_SUBMATCH_RESULT,_$^N",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "@LAST_MATCH_END, @+",
    "url": "/language/5to6-perlvar#@LAST_MATCH_END,_@+",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "%LAST_PAREN_MATCH, %+",
    "url": "/language/5to6-perlvar#%LAST_PAREN_MATCH,_%+"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading",
    "url": "/language/5to6-perlvar#@LAST_MATCH_START,_@-",
    "value": "@LAST_MATCH_START, @-"
  },
  {
    "url": "/language/5to6-perlvar#%LAST_MATCH_START,_%-",
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "%LAST_MATCH_START, %-"
  },
  {
    "value": "$LAST_REGEXP_CODE_RESULT, $^R",
    "url": "/language/5to6-perlvar#$LAST_REGEXP_CODE_RESULT,_$^R",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading"
  },
  {
    "value": "${^RE_DEBUG_FLAGS}",
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#${^RE_DEBUG_FLAGS}"
  },
  {
    "value": "${^RE_TRIE_MAXBUF}",
    "category": "Heading",
    "url": "/language/5to6-perlvar#${^RE_TRIE_MAXBUF}",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "value": "Variables related to filehandles",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading",
    "url": "/language/5to6-perlvar#Variables_related_to_filehandles"
  },
  {
    "value": "$ARGV",
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#$ARGV"
  },
  {
    "value": "@ARGV",
    "url": "/language/5to6-perlvar#@ARGV",
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "url": "/language/5to6-perlvar#ARGV",
    "value": "ARGV",
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading",
    "url": "/language/5to6-perlvar#ARGVOUT",
    "value": "ARGVOUT"
  },
  {
    "value": "$OUTPUT_FIELD_SEPARATOR, $OFS, $,",
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#$OUTPUT_FIELD_SEPARATOR,_$OFS,_$,"
  },
  {
    "category": "Heading",
    "url": "/language/5to6-perlvar#$INPUT_LINE_NUMBER",
    "value": "$INPUT_LINE_NUMBER",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "url": "/language/5to6-perlvar#$NR,_$.",
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$NR, $."
  },
  {
    "url": "/language/5to6-perlvar#$INPUT_RECORD_SEPARATOR,_$RS,_$/",
    "value": "$INPUT_RECORD_SEPARATOR, $RS, $/",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading"
  },
  {
    "url": "/language/5to6-perlvar#$OUTPUT_RECORD_SEPARATOR,_$ORS,_$%5C",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$OUTPUT_RECORD_SEPARATOR, $ORS, $\\",
    "category": "Heading"
  },
  {
    "url": "/language/5to6-perlvar#$OUTPUT_AUTOFLUSH,_$|",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "category": "Heading",
    "value": "$OUTPUT_AUTOFLUSH, $|"
  },
  {
    "category": "Heading",
    "url": "/language/5to6-perlvar#${^LAST_FH}",
    "value": "${^LAST_FH}",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "category": "Heading",
    "value": "Variables related to formats",
    "url": "/language/5to6-perlvar#Variables_related_to_formats",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "url": "/language/5to6-perlvar#Error_variables",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "Error variables",
    "category": "Heading"
  },
  {
    "value": "Variables related to the interpreter state",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#Variables_related_to_the_interpreter_state",
    "category": "Heading"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#$COMPILING,_$^C,_$^D,_${^ENCODING},_${^GLOBAL_PHASE}",
    "category": "Heading",
    "value": "$COMPILING, $^C, $^D, ${^ENCODING}, ${^GLOBAL_PHASE}"
  },
  {
    "value": "$^H, %^H, ${^OPEN}",
    "url": "/language/5to6-perlvar#$^H,_%^H,_${^OPEN}",
    "category": "Heading",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "value": "$PERLDB, $^P",
    "url": "/language/5to6-perlvar#$PERLDB,_$^P",
    "category": "Heading"
  },
  {
    "url": "/language/5to6-perlvar#${^TAINT}",
    "category": "Heading",
    "value": "${^TAINT}",
    "info": ": section in <b>Perl to Raku guide - special variables</b>"
  },
  {
    "category": "Heading",
    "value": "${^UNICODE}, ${^UTF8CACHE}, ${^UTF8LOCALE}",
    "info": ": section in <b>Perl to Raku guide - special variables</b>",
    "url": "/language/5to6-perlvar#${^UNICODE},_${^UTF8CACHE},_${^UTF8LOCALE}"
  },
  {
    "category": "Heading",
    "url": "/routine/..#language/operatorsroutineinfix",
    "info": ": section in <b>..</b>",
    "value": "In language/operators"
  },
  {
    "category": "Heading",
    "url": "/routine/%E2%8A%88#language/operatorsroutineinfix",
    "info": ": section in <b>⊈</b>",
    "value": "In language/operators"
  },
  {
    "value": "In type/Str",
    "info": ": section in <b>index</b>",
    "category": "Heading",
    "url": "/routine/index#type/Strroutinemethod"
  },
  {
    "value": "In type/Cool",
    "url": "/routine/index#type/Coolroutineroutine",
    "info": ": section in <b>index</b>",
    "category": "Heading"
  },
  {
    "url": "/syntax/%25#language/regexessyntax%",
    "category": "Heading",
    "info": ": section in <b>%</b>",
    "value": "In language/regexes"
  },
  {
    "url": "/routine/NFC#type/Strroutinemethod",
    "category": "Heading",
    "info": ": section in <b>NFC</b>",
    "value": "In type/Str"
  },
  {
    "url": "/routine/note#type/independent-routinesroutineroutine",
    "value": "In type/independent-routines",
    "info": ": section in <b>note</b>",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "In language/glossary",
    "info": ": section in <b>NQP</b>",
    "url": "/syntax/NQP#language/glossarysyntaxNQP"
  },
  {
    "category": "Heading",
    "info": ": section in <b>code</b>",
    "url": "/routine/code#type/CallFrameroutinemethod",
    "value": "In type/CallFrame"
  },
  {
    "category": "Heading",
    "url": "/routine/orelse#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>orelse</b>"
  },
  {
    "value": "In type/Parameter",
    "info": ": section in <b>constraints</b>",
    "url": "/routine/constraints#type/Parameterroutinemethod",
    "category": "Heading"
  },
  {
    "value": "In language/regexes",
    "category": "Heading",
    "info": ": section in <b>? (quantifier)</b>",
    "url": "/syntax/%3F%20%28quantifier%29#language/regexessyntax%3F (quantifier)"
  },
  {
    "value": "In language/glossary",
    "url": "/syntax/Adverbial%20Pair#language/glossarysyntaxAdverbial Pair",
    "category": "Heading",
    "info": ": section in <b>Adverbial Pair</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>round</b>",
    "value": "In type/Cool",
    "url": "/routine/round#type/Coolroutineroutine"
  },
  {
    "category": "Heading",
    "url": "/syntax/POD#language/glossarysyntaxPOD",
    "value": "In language/glossary",
    "info": ": section in <b>POD</b>"
  },
  {
    "info": ": section in <b>role Dateish</b>",
    "category": "Heading",
    "url": "/type/Dateish#Methods",
    "value": "Methods"
  },
  {
    "url": "/type/Dateish#method_year",
    "category": "Heading",
    "value": "method year",
    "info": ": section in <b>role Dateish</b>"
  },
  {
    "info": ": section in <b>role Dateish</b>",
    "value": "method month",
    "category": "Heading",
    "url": "/type/Dateish#method_month"
  },
  {
    "category": "Heading",
    "url": "/type/Dateish#method_day",
    "value": "method day",
    "info": ": section in <b>role Dateish</b>"
  },
  {
    "url": "/type/Dateish#method_formatter",
    "category": "Heading",
    "value": "method formatter",
    "info": ": section in <b>role Dateish</b>"
  },
  {
    "info": ": section in <b>role Dateish</b>",
    "url": "/type/Dateish#method_is-leap-year",
    "category": "Heading",
    "value": "method is-leap-year"
  },
  {
    "value": "method day-of-month",
    "category": "Heading",
    "url": "/type/Dateish#method_day-of-month",
    "info": ": section in <b>role Dateish</b>"
  },
  {
    "value": "method day-of-week",
    "info": ": section in <b>role Dateish</b>",
    "url": "/type/Dateish#method_day-of-week",
    "category": "Heading"
  },
  {
    "url": "/type/Dateish#method_day-of-year",
    "category": "Heading",
    "value": "method day-of-year",
    "info": ": section in <b>role Dateish</b>"
  },
  {
    "url": "/type/Dateish#method_days-in-year",
    "category": "Heading",
    "info": ": section in <b>role Dateish</b>",
    "value": "method days-in-year"
  },
  {
    "url": "/type/Dateish#method_days-in-month",
    "category": "Heading",
    "info": ": section in <b>role Dateish</b>",
    "value": "method days-in-month"
  },
  {
    "info": ": section in <b>role Dateish</b>",
    "url": "/type/Dateish#method_week",
    "value": "method week",
    "category": "Heading"
  },
  {
    "info": ": section in <b>role Dateish</b>",
    "category": "Heading",
    "url": "/type/Dateish#method_week-number",
    "value": "method week-number"
  },
  {
    "category": "Heading",
    "value": "method week-year",
    "info": ": section in <b>role Dateish</b>",
    "url": "/type/Dateish#method_week-year"
  },
  {
    "category": "Heading",
    "url": "/type/Dateish#method_weekday-of-month",
    "value": "method weekday-of-month",
    "info": ": section in <b>role Dateish</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>role Dateish</b>",
    "value": "method yyyy-mm-dd",
    "url": "/type/Dateish#method_yyyy-mm-dd"
  },
  {
    "value": "method mm-dd-yyyy",
    "info": ": section in <b>role Dateish</b>",
    "url": "/type/Dateish#method_mm-dd-yyyy",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "value": "method dd-mm-yyyy",
    "info": ": section in <b>role Dateish</b>",
    "url": "/type/Dateish#method_dd-mm-yyyy"
  },
  {
    "url": "/type/Dateish#method_daycount",
    "value": "method daycount",
    "category": "Heading",
    "info": ": section in <b>role Dateish</b>"
  },
  {
    "category": "Heading",
    "url": "/type/Dateish#method_IO",
    "value": "method IO",
    "info": ": section in <b>role Dateish</b>"
  },
  {
    "category": "Heading",
    "value": "method earlier",
    "url": "/type/Dateish#method_earlier",
    "info": ": section in <b>role Dateish</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>role Dateish</b>",
    "url": "/type/Dateish#method_later",
    "value": "method later"
  },
  {
    "category": "Heading",
    "value": "In type/Proc/Async",
    "url": "/routine/bind-stdin#type/Proc/Asyncroutinemethod",
    "info": ": section in <b>bind-stdin</b>"
  },
  {
    "info": ": section in <b>type_captures</b>",
    "value": "In type/Parameter",
    "category": "Heading",
    "url": "/routine/type_captures#type/Parameterroutinemethod"
  },
  {
    "value": "In language/regexes",
    "category": "Heading",
    "info": ": section in <b>^^</b>",
    "url": "/syntax/%5E%5E#language/regexessyntax^^"
  },
  {
    "info": ": section in <b>ceiling</b>",
    "value": "In type/Cool",
    "category": "Heading",
    "url": "/routine/ceiling#type/Coolroutineroutine"
  },
  {
    "info": ": section in <b>tc</b>",
    "value": "In type/Str",
    "category": "Heading",
    "url": "/routine/tc#type/Strroutineroutine"
  },
  {
    "info": ": section in <b>tc</b>",
    "url": "/routine/tc#type/Coolroutineroutine",
    "category": "Heading",
    "value": "In type/Cool"
  },
  {
    "info": ": section in <b>Version</b>",
    "value": "In type/Str",
    "category": "Heading",
    "url": "/routine/Version#type/Strroutinemethod"
  },
  {
    "url": "/syntax/binder#language/glossarysyntaxbinder",
    "value": "In language/glossary",
    "info": ": section in <b>binder</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>before</b>",
    "url": "/syntax/before#language/regexessyntaxbefore",
    "value": "In language/regexes",
    "category": "Heading"
  },
  {
    "url": "/routine/floor#type/Coolroutineroutine",
    "value": "In type/Cool",
    "info": ": section in <b>floor</b>",
    "category": "Heading"
  },
  {
    "url": "/routine/put#type/Proc/Asyncroutinemethod",
    "value": "In type/Proc/Async",
    "info": ": section in <b>put</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>put</b>",
    "category": "Heading",
    "value": "In type/independent-routines",
    "url": "/routine/put#type/independent-routinesroutinesub"
  },
  {
    "url": "/routine/optional#type/Parameterroutinemethod",
    "value": "In type/Parameter",
    "category": "Heading",
    "info": ": section in <b>optional</b>"
  },
  {
    "info": ": section in <b>cotan</b>",
    "url": "/routine/cotan#type/Coolroutineroutine",
    "value": "In type/Cool",
    "category": "Heading"
  },
  {
    "url": "/syntax/Handle#language/glossarysyntaxHandle",
    "info": ": section in <b>Handle</b>",
    "category": "Heading",
    "value": "In language/glossary"
  },
  {
    "category": "Heading",
    "url": "/routine/mm-dd-yyyy#type/Dateishroutinemethod",
    "value": "In type/Dateish",
    "info": ": section in <b>mm-dd-yyyy</b>"
  },
  {
    "url": "/syntax/bytecode#language/glossarysyntaxbytecode",
    "value": "In language/glossary",
    "category": "Heading",
    "info": ": section in <b>bytecode</b>"
  },
  {
    "url": "/routine/acosec#type/Coolroutineroutine",
    "info": ": section in <b>acosec</b>",
    "value": "In type/Cool",
    "category": "Heading"
  },
  {
    "url": "/routine/%2B%26lt%3B#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading",
    "info": ": section in <b>+<</b>"
  },
  {
    "info": ": section in <b>required</b>",
    "category": "Heading",
    "value": "In type/Attribute",
    "url": "/routine/required#type/Attributeroutinemethod"
  },
  {
    "value": "In language/101-basics",
    "info": ": section in <b>for (Basics)</b>",
    "url": "/syntax/for%20%28Basics%29#language/101-basicssyntaxfor (Basics)",
    "category": "Heading"
  },
  {
    "value": "In type/Int",
    "url": "/routine/lsb#type/Introutineroutine",
    "category": "Heading",
    "info": ": section in <b>lsb</b>"
  },
  {
    "url": "/routine/trim-trailing#type/Strroutinemethod",
    "category": "Heading",
    "info": ": section in <b>trim-trailing</b>",
    "value": "In type/Str"
  },
  {
    "category": "Heading",
    "info": ": section in <b>trim-trailing</b>",
    "value": "In type/Cool",
    "url": "/routine/trim-trailing#type/Coolroutineroutine"
  },
  {
    "info": ": section in <b>is tighter</b>",
    "url": "/syntax/is%20tighter#language/functionssyntaxis tighter",
    "category": "Heading",
    "value": "In language/functions"
  },
  {
    "url": "/routine/lastcall#type/independent-routinesroutinesub",
    "category": "Heading",
    "value": "In type/independent-routines",
    "info": ": section in <b>lastcall</b>"
  },
  {
    "category": "Heading",
    "url": "/routine/annotations#type/CallFrameroutinemethod",
    "info": ": section in <b>annotations</b>",
    "value": "In type/CallFrame"
  },
  {
    "value": "In type/Str",
    "category": "Heading",
    "info": ": section in <b>NFKC</b>",
    "url": "/routine/NFKC#type/Strroutinemethod"
  },
  {
    "url": "/routine/eq#language/operatorsroutineinfix",
    "info": ": section in <b>eq</b>",
    "category": "Heading",
    "value": "In language/operators"
  },
  {
    "url": "/routine/indent#type/Strroutinemethod",
    "info": ": section in <b>indent</b>",
    "category": "Heading",
    "value": "In type/Str"
  },
  {
    "info": ": section in <b>cis</b>",
    "value": "In type/Cool",
    "url": "/routine/cis#type/Coolroutineroutine",
    "category": "Heading"
  },
  {
    "url": "/syntax/DESTROY#language/classtutsyntaxDESTROY",
    "info": ": section in <b>DESTROY</b>",
    "category": "Heading",
    "value": "In language/classtut"
  },
  {
    "url": "/routine/%3F%26amp%3B#language/operatorsroutineinfix",
    "info": ": section in <b>?&</b>",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "url": "/routine/codes#type/Coolroutineroutine",
    "value": "In type/Cool",
    "info": ": section in <b>codes</b>",
    "category": "Heading"
  },
  {
    "info": ": section in <b>..^</b>",
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/..%5E#language/operatorsroutineinfix"
  },
  {
    "url": "/routine/%E2%8A%89#language/operatorsroutineinfix",
    "value": "In language/operators",
    "info": ": section in <b>⊉</b>",
    "category": "Heading"
  },
  {
    "value": "In language/glossary",
    "url": "/syntax/Semilist#language/glossarysyntaxSemilist",
    "category": "Heading",
    "info": ": section in <b>Semilist</b>"
  },
  {
    "value": "In language/operators",
    "info": ": section in <b>(<), infix ⊂</b>",
    "category": "Heading",
    "url": "/routine/%28%26lt%3B%29%2C%20infix%20%E2%8A%82#language/operatorsroutineinfix"
  },
  {
    "value": "In type/BagHash",
    "category": "Heading",
    "info": ": section in <b>remove</b>",
    "url": "/routine/remove#type/BagHashroutinemethod"
  },
  {
    "value": "In type/Attribute",
    "info": ": section in <b>gist</b>",
    "category": "Heading",
    "url": "/routine/gist#type/Attributeroutinemethod"
  },
  {
    "info": ": section in <b>minmax</b>",
    "url": "/routine/minmax#language/operatorsroutineinfix",
    "value": "In language/operators",
    "category": "Heading"
  },
  {
    "info": ": section in <b>fff</b>",
    "category": "Heading",
    "value": "In language/operators",
    "url": "/routine/fff#language/operatorsroutineinfix"
  },
  {
    "value": "In language/operators",
    "url": "/routine/%2F%2F#language/operatorsroutineprefix",
    "category": "Heading",
    "info": ": section in <b>//</b>"
  },
  {
    "info": ": section in <b>//</b>",
    "value": "In language/operators",
    "url": "/routine/%2F%2F#language/operatorsroutineinfix",
    "category": "Heading"
  },
  {
    "url": "/syntax/unless#language/controlsyntaxunless",
    "category": "Heading",
    "value": "In language/control",
    "info": ": section in <b>unless</b>"
  },
  {
    "info": ": section in <b>:</b>",
    "category": "Heading",
    "url": "/routine/%3A#language/operatorsroutineinfix",
    "value": "In language/operators"
  },
  {
    "url": "/routine/trim-leading#type/Strroutinemethod",
    "category": "Heading",
    "info": ": section in <b>trim-leading</b>",
    "value": "In type/Str"
  },
  {
    "category": "Heading",
    "value": "In type/Cool",
    "info": ": section in <b>trim-leading</b>",
    "url": "/routine/trim-leading#type/Coolroutineroutine"
  },
  {
    "url": "/syntax/is%20required%20%28Attribute%29#type/Attributesyntaxis required (Attribute)",
    "category": "Heading",
    "info": ": section in <b>is required (Attribute)</b>",
    "value": "In type/Attribute"
  },
  {
    "value": "Defining/Creating/Using functions",
    "url": "/language/functions#Defining/Creating/Using_functions",
    "category": "Heading",
    "info": ": section in <b>Functions</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Functions</b>",
    "value": "Subroutines",
    "url": "/language/functions#Subroutines"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Functions</b>",
    "url": "/language/functions#Blocks_and_lambdas",
    "value": "Blocks and lambdas"
  },
  {
    "info": ": section in <b>Functions</b>",
    "url": "/language/functions#Signatures",
    "category": "Heading",
    "value": "Signatures"
  },
  {
    "info": ": section in <b>Functions</b>",
    "value": "Automatic signatures",
    "url": "/language/functions#Automatic_signatures",
    "category": "Heading"
  },
  {
    "value": "Arguments",
    "category": "Heading",
    "url": "/language/functions#Arguments",
    "info": ": section in <b>Functions</b>"
  },
  {
    "info": ": section in <b>Functions</b>",
    "category": "Heading",
    "url": "/language/functions#Return_values",
    "value": "Return values"
  },
  {
    "url": "/language/functions#Return_type_constraints",
    "info": ": section in <b>Functions</b>",
    "value": "Return type constraints",
    "category": "Heading"
  },
  {
    "url": "/language/functions#Multi-dispatch",
    "value": "Multi-dispatch",
    "category": "Heading",
    "info": ": section in <b>Functions</b>"
  },
  {
    "info": ": section in <b>Functions</b>",
    "category": "Heading",
    "value": "proto",
    "url": "/language/functions#proto"
  },
  {
    "value": "only",
    "info": ": section in <b>Functions</b>",
    "url": "/language/functions#only",
    "category": "Heading"
  },
  {
    "url": "/language/functions#multi_resolution_by_order_of_definition",
    "category": "Heading",
    "info": ": section in <b>Functions</b>",
    "value": "multi resolution by order of definition"
  },
  {
    "info": ": section in <b>Functions</b>",
    "url": "/language/functions#Conventions_and_idioms",
    "category": "Heading",
    "value": "Conventions and idioms"
  },
  {
    "url": "/language/functions#Slurpy_conventions",
    "category": "Heading",
    "value": "Slurpy conventions",
    "info": ": section in <b>Functions</b>"
  },
  {
    "info": ": section in <b>Functions</b>",
    "category": "Heading",
    "url": "/language/functions#Functions_are_first-class_objects",
    "value": "Functions are first-class objects"
  },
  {
    "url": "/language/functions#Infix_form",
    "info": ": section in <b>Functions</b>",
    "category": "Heading",
    "value": "Infix form"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Functions</b>",
    "value": "Closures",
    "url": "/language/functions#Closures"
  },
  {
    "url": "/language/functions#Routines",
    "category": "Heading",
    "info": ": section in <b>Functions</b>",
    "value": "Routines"
  },
  {
    "url": "/language/functions#Defining_operators",
    "category": "Heading",
    "info": ": section in <b>Functions</b>",
    "value": "Defining operators"
  },
  {
    "info": ": section in <b>Functions</b>",
    "value": "Precedence",
    "category": "Heading",
    "url": "/language/functions#Precedence"
  },
  {
    "value": "Associativity",
    "info": ": section in <b>Functions</b>",
    "url": "/language/functions#Associativity",
    "category": "Heading"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Functions</b>",
    "url": "/language/functions#Traits",
    "value": "Traits"
  },
  {
    "category": "Heading",
    "value": "Re-dispatching",
    "url": "/language/functions#Re-dispatching",
    "info": ": section in <b>Functions</b>"
  },
  {
    "category": "Heading",
    "info": ": section in <b>Functions</b>",
    "url": "/language/functions#sub_callsame",
    "value": "sub callsame"
  },
  {
    "category": "Heading",
    "url": "/language/functions#sub_callwith",
    "value": "sub callwith",
    "info": ": section in <b>Functions</b>"
  },
  {
    "category": "Heading",
    "value": "sub nextsame",
    "info": ": section in <b>Functions</b>",
    "url": "/language/functions#sub_nextsame"
  },
  {
    "url": "/language/functions#sub_nextwith",
    "category": "Heading",
    "info": ": section in <b>Functions</b>",
    "value": "sub nextwith"
  },
  {
    "url": "/language/functions#sub_samewith",
    "value": "sub samewith",
    "category": "Heading",
    "info": ": section in <b>Functions</b>"
  },
  {
    "info": ": section in <b>Functions</b>",
    "url": "/language/functions#sub_nextcallee",
    "category": "Heading",
    "value": "sub nextcallee"
  },
  {
    "category": "Heading",
    "url": "/language/functions#Wrapped_routines",
    "value": "Wrapped routines",
    "info": ": section in <b>Functions</b>"
  },
  {
    "info": ": section in <b>Functions</b>",
    "category": "Heading",
    "value": "Routines of parent class",
    "url": "/language/functions#Routines_of_parent_class"
  },
  {
    "category": "Heading",
    "url": "/language/functions#Coercion_types",
    "value": "Coercion types",
    "info": ": section in <b>Functions</b>"
  },
  {
    "url": "/language/functions#sub_MAIN",
    "value": "sub MAIN",
    "info": ": section in <b>Functions</b>",
    "category": "Heading"
  },
  {
    "url": "/syntax/Apocalypse#language/glossarysyntaxApocalypse",
    "info": ": section in <b>Apocalypse</b>",
    "category": "Heading",
    "value": "In language/glossary"
  },
  {
    "url": "/routine/uniprop#type/Coolroutineroutine",
    "value": "In type/Cool",
    "category": "Heading",
    "info": ": section in <b>uniprop</b>"
  },
  {
    "info": ": section in <b>return</b>",
    "value": "In language/control",
    "category": "Heading",
    "url": "/syntax/return#language/controlsyntaxreturn"
  },
  {
    "category": "Heading",
    "info": ": section in <b>invert</b>",
    "value": "In type/Baggy",
    "url": "/routine/invert#type/Baggyroutinemethod"
  },
  {
    "category": "Heading",
    "url": "/routine/samecase#type/Strroutinemethod",
    "value": "In type/Str",
    "info": ": section in <b>samecase</b>"
  },
  {
    "value": "In type/Cool",
    "url": "/routine/samecase#type/Coolroutineroutine",
    "category": "Heading",
    "info": ": section in <b>samecase</b>"
  },
  {
    "url": "/syntax/Syntax%20Analysis#language/glossarysyntaxSyntax Analysis",
    "info": ": section in <b>Syntax Analysis</b>",
    "value": "In language/glossary",
    "category": "Heading"
  }
]
            ;
            //ITEMs to be added
let current_search = "";
let searchSite = window.location.hostname;
const category_search = (function() {
    const method_sign = new RegExp(/^(\.)(\w[\w\-]+)/);
    const routine_sign = new RegExp(/^(\&)(\w[\w-]+.*)/);
    const routineMethod_sign = new RegExp(/([^\(]+)(\(\)?)$/);
    const classPackageRole_sign = new RegExp(/^(\:\:)([A-Z][\w\:]*)/);
    return {
        filter_by_category: function(search_term, items) {
            let filteredItems = [];
            if (search_term.match(method_sign)) {
                filteredItems = items.filter(function(item) { return item.category.toLowerCase() === 'methods' ||  item.category.toLowerCase() === 'routines' });
            } else if (search_term.match(routine_sign)){
                filteredItems = items.filter(function(item) { return item.category.toLowerCase() === 'subroutines' || item.category.toLowerCase() === 'routines' });
            } else if (search_term.match(routineMethod_sign)) {
                filteredItems = items.filter(function(item) { return item.category.toLowerCase() === 'methods' || item.category.toLowerCase() === 'subroutines' || item.category.toLowerCase() === 'routines' });
            } else if (search_term.match(classPackageRole_sign)) {
                filteredItems = items.filter(function(item) { return item.category.toLowerCase() === 'types' });
            } else {
                filteredItems = items;
            }
            return filteredItems;
        },
        strip_sign: function(search_term) {
            let match;
            if (search_term.match(method_sign)) {
                // We matched `.`, strip it off
                search_term = search_term.substring(1);
            } else if (search_term.match(routine_sign)) {
                // We matched a &, strip it off
                search_term = search_term.replace('&', '');
            } else if (search_term.match(routineMethod_sign)) {
                // We matched (), strip it off
                search_term = search_term.replace(/[()]/g, '');
            } else if (search_term.match(classPackageRole_sign)) {
                // We matched ::, strip it off
                search_term = search_term.replace('::', '');
            }
            return search_term;
        }
    }
})();
$(function(){
  $.widget( "custom.catcomplete", $.ui.autocomplete, {
    _create: function() {
      this._super();
      this.widget().menu( "option", "items", "> :not(.ui-autocomplete-category)" );
    },
    _renderItem: function( ul, item) {
        const enter_text = $('<span>')
            .attr('class', 'enter-prompt')
            .css('display', 'none')
            .html('Enter to select');
        const info_element = $('<span>')
            .attr('class', 'item-info')
            .html( item.info );
        const regex = new RegExp('('
            + current_search.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&')
            + ')', 'ig');
        const text = item.label.replace(regex, '<b>$1</b>');
        const boldMatch = text.match(/^<b>.*?<\/b>$/);
        if (boldMatch && boldMatch[0].match(/<b>/g).length === 1) {
            $('#navbar-search').attr('data-default-url', item.url);
            enter_text.css('display', 'inline');
            enter_text.addClass('default-selection');
        } else if (item.category === 'Site Search') {
            $('#navbar-search').attr('data-search-url', item.url);
            enter_text.css('display', 'inline');
            enter_text.addClass('default-selection');
        }
        return $( "<li>" )
            .append( $( "<div>" ).html(text).append(info_element).append(enter_text) )
            .appendTo( ul )
            .hover(
                function() {
                $('#navbar-search .enter-prompt:visible').hide();
                $(this).find('.enter-prompt').show()
                },
                function() {
                    $(this).find('.enter-prompt').hide();
                    $('#navbar-search .default-selection').show();
                }
            )
    },
    _renderMenu: function( ul, items ) {
      const that = this;
      let currentCategory = "";
      $('#navbar-search').attr('data-default-url', '');
      $('#navbar-search').attr('data-search-url', '');
      function sortBy(a, b) {
        // We want to place 5to6 docs to the end of the list.
        // See if either a or b are in 5to6 category.
        const isp5a = false, isp5b = false;
        if ( a.category.substr(0,4) == '5to6' ) { isp5a = true; }
        if ( b.category.substr(0,4) == '5to6' ) { isp5b = true; }

        // If one of the categories is a 5to6 but other isn't,
        // move 5to6 to be last
        if ( isp5a  && !isp5b ) {return  1}
        if ( !isp5a && isp5b  ) {return -1}

        // Sort by category alphabetically; 5to6 items would both have
        // the same category if we reached this point and category sort
        // will happen only on non-5to6 items
        const a_cat = a.category.toLowerCase();
        const b_cat = b.category.toLowerCase();
       // put category Heading at the end
        if (a_cat == 'heading' && b_cat != 'heading') {return 1}
        if (a_cat != 'heading' && b_cat == 'heading') {return -1}
        // now sort normally
        if ( a_cat < b_cat ) {return -1}
        if ( a_cat > b_cat ) {return  1}

        // We reach this point when categories are the same; so
        // we sort items by value

        const a_val = a.value.toLowerCase();
        const b_val = b.value.toLowerCase();

        // exact matches preferred
        if ( a_val == current_search) {return -1}
        if ( b_val == current_search) {return  1}

        const a_sw = a_val.startsWith(current_search);
        const b_sw = b_val.startsWith(current_search);
        // initial matches preferred
        if (a_sw && !b_sw) { return -1}
        if (b_sw && !a_sw) { return  1}

        // default
        if ( a_val < b_val ) {return -1}
        if ( a_val > b_val ) {return  1}

        return 0;
      }
      const sortedItems = items.sort(sortBy);
      const keywords = category_search.strip_sign($("#query").val());
      sortedItems.push({
          category: 'Site Search',
          label: "Search the entire site for " + keywords,
          value: keywords,
          url: siteSearchUrl( keywords )
      });
      sortedItems.forEach(function(item, index) {
        let li;
        if ( item.category != currentCategory ) {
          ul.append( "<li class='ui-autocomplete-category'>" + item.category + "</li>" );
          currentCategory = item.category;
        }
        li = that._renderItemData( ul, item );
        if ( item.category ) {
          li.attr( "aria-label", item.category + " : " + item.label );
        }
      });
      if ($(ul).find('.default-selection').length > 1) {
        $(ul).find('.default-selection').not(":first")
            .removeClass('default-selection')
            .css({'display': 'none'});
      };
    }
  });

  // The catcomplete plugin doesn't handle unfocus, so hide the "no results" bar
  // manually in case the search is not used anymore
  $("#query").focusout(function(){
    setTimeout(() => {
        $('#navbar-search-empty').hide();
    }, 200);
  });

  $("#query").attr('placeholder', '🔍').catcomplete({
      appendTo: "#navbar-search",
      autoFocus: true,
      response: function(e, ui) {
        if (!ui.content.length) {
            $('#navbar-search-empty').show();
            $('#try-web-search').attr('href', siteSearchUrl($("#query").val()));
        }
        else {
            $('#navbar-search-empty').hide();
        }
      },
      open: function() {
        const ui_el = $('.ui-autocomplete');
        if ( ui_el.offset().left < 0 ) {
            ui_el.css({left: 0})
        }
        $('#navbar-search-empty').hide();
      },
      position: { my: "right top", at: "right bottom" },
      source: function(request, response) {
          const filteredItems = category_search.filter_by_category(request.term, items);
          const results = $.ui.autocomplete.filter(filteredItems, category_search.strip_sign(request.term));
          function trim_results(results, term) {
              const cutoff = 50;
              if (results.length < cutoff) {
                  return results;
              }
              // Prefer exact matches, then starting matches.
              const exacts = [];
              const prefixes = [];
              const rest = [];
              for (let ii = 0; ii <results.length; ii++) {
                  if (results[ii].value.toLowerCase() == term.toLowerCase()) {
                      exacts.push(ii);
                  } else if (results[ii].value.toLowerCase().startsWith(term.toLowerCase())) {
                  prefixes.push(ii);
                  } else {
                      rest.push(ii);
                  }
              }
              const keeps = [];
              let pos = 0;
              while (keeps.length <= cutoff && pos < exacts.length) {
                  keeps.push(exacts[pos++]);
              }
              pos = 0;
              while (keeps.length <= cutoff && pos < prefixes.length) {
                  keeps.push(prefixes[pos++]);
              }
              pos = 0;
              while (keeps.length <= cutoff && pos < rest.length) {
                  keeps.push(rest[pos++]);
              }
              const filtered = [];
              for (pos = 0; pos < results.length; pos++) {
                  if (keeps.indexOf(pos) != -1) {
                      filtered.push(results[pos]);
                  }
              }
              return filtered;
          };
          response(trim_results(results, request.term));
      },
      select: function (event, ui) {
        $('#navbar-search').attr('data-default-url', ui.item.url);
        followLink();
      },
  });

  $("#query").keydown(function(event, ui) {
    if (event.keyCode == 13) {
     followLink();
    }
  });
});

var followLink = function() {
    /* When using return key to select, the select event
    and keydown event are both activated and the second
    event should do nothing */
    let url;
    if ($('#navbar-search').attr('data-default-url')) {
        url = $('#navbar-search').attr('data-default-url');
        $('#navbar-search').attr('data-default-url', '');
        $('#navbar-search').attr('data-search-url', '');
        window.location.href = url;
    } else if ($('#navbar-search').attr('data-search-url')) {
        url = $('#navbar-search').attr('data-search-url');
        window.location.href = url;
    }
}

/*
 * allow for inexact searching via sift4
 * try to restrict usage, and always check the standard
 * search mechanism if sift4 doesn't match
 */
$.extend( $.ui.autocomplete, {
    escapeRegex: function( value ) {
        return value.replace( /[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&" );
    },
    filter: function( array, term ) {
        current_search = term.toLowerCase();

        var search_method = false;
        if (term.match(/^\s*\.[a-zA-Z][a-zA-Z0-9_-]+\s*$/)) {
            search_method = true;
            term = term.substr(1);
        }

        const len = term.length;
        const matcher = new RegExp( $.ui.autocomplete.escapeRegex( term ), "i" );
        const OK_distance = len > 9 ? 4 : len > 6 ? 3 : len > 4 ? 2 : 1;
        return $.grep( array, function( value ) {
            if (search_method && value.category != 'Method') {
                return false;
            }
            if (len >=2 ) {
                const result = sift4( value.value, term, 4, 0);
                if (result <= OK_distance) {
                    return true;
                }
            }

            // Try the old school match
            return matcher.test( value.label || value.value || value );
        } );
    }
} );

function siteSearchUrl( keywords ) {
    return 'https://www.google.com/search?q=site%3A' + searchSite + '+' + encodeURIComponent( keywords );
}

/*
 * Courtesy https://siderite.blogspot.com/2014/11/super-fast-and-accurate-string-distance.html
 */

// Sift4 - common version
// online algorithm to compute the distance between two strings in O(n)
// maxOffset is the number of characters to search for matching letters
// maxDistance is the distance at which the algorithm should stop computing the value and just exit (the strings are too different anyway)
function sift4(s1, s2, maxOffset, maxDistance) {
    if (!s1||!s1.length) {
        if (!s2) {
            return 0;
        }
        return s2.length;
    }

    if (!s2 || !s2.length) {
        return s1.length;
    }

    var l1=s1.length;
    var l2=s2.length;

    var c1 = 0;  //cursor for string 1
    var c2 = 0;  //cursor for string 2
    var lcss = 0;  //largest common subsequence
    var local_cs = 0; //local common substring
    var trans = 0;  //number of transpositions ('ab' vs 'ba')
    var offset_arr=[];  //offset pair array, for computing the transpositions

    while ((c1 < l1) && (c2 < l2)) {
        if (s1.charAt(c1) == s2.charAt(c2)) {
            local_cs++;
            let isTrans = false;
            //see if current match is a transposition
            let i=0;
            for(let i = 0; i < offset_arr.length; i++) {
                const ofs=offset_arr[i];
                if (c1<=ofs.c1 || c2 <= ofs.c2) {
                    // when two matches cross, the one considered a transposition is the one with the largest difference in offsets
                    isTrans = Math.abs(c2 - c1) >= Math.abs(ofs.c2 - ofs.c1);
                    if (isTrans)
                    {
                        trans++;
                    } else {
                        if (!ofs.trans) {
                            ofs.trans=true;
                            trans++;
                        }
                    }
                    break;
                } else {
                    if (c1 > ofs.c2 && c2 > ofs.c1) {
                        offset_arr.splice(i,1);
                    } else {
                        i++;
                    }
                }
            }
            offset_arr.push({
                c1:c1,
                c2:c2,
                trans:isTrans
            });
        } else {
            lcss += local_cs;
            local_cs = 0;
            if (c1!=c2) {
                c1 = c2=Math.min(c1,c2);  //using min allows the computation of transpositions
            }
            //if matching characters are found, remove 1 from both cursors (they get incremented at the end of the loop)
            //so that we can have only one code block handling matches
            for (let i = 0; i < maxOffset && (c1+i<l1 || c2+i<l2); i++) {
                if ((c1 + i < l1) && (s1.charAt(c1 + i) == s2.charAt(c2))) {
                    c1 += i-1;
                    c2--;
                    break;
                }
                if ((c2 + i < l2) && (s1.charAt(c1) == s2.charAt(c2 + i))) {
                    c1--;
                    c2+= i-1;
                    break;
                }
            }
        }
        c1++;
        c2++;
        if (maxDistance) {
            let temporaryDistance=Math.max(c1,c2)-lcss+trans;
            if (temporaryDistance>=maxDistance) return Math.round(temporaryDistance);
        }
        // this covers the case where the last match is on the last token in list, so that it can compute transpositions correctly
        if ((c1 >= l1) || (c2 >= l2)) {
            lcss+=local_cs;
            local_cs=0;
            c1=c2=Math.min(c1,c2);
        }
    }
    lcss+=local_cs;
    return Math.round(Math.max(l1,l2)- lcss +trans); //add the cost of transpositions to the final result
}
// Code to set up the search bar events
$(document).ready(function() {
    $('#query').focus(function () {
        if ($('.navbar-menu').css('display') == 'flex') {
            $("#query").stop(true);
            $('.navbar-start').hide();
            $("#query").animate({ width: "980px" }, 200, function () { $(".navbar-search-autocomplete").width("980px"); $('#navbar-search').show(); });
        } else {
            $('#navbar-search').show();
        }
        $('#navMenu').addClass('navbar-autocomplete-active');
    });
    $('#query').blur(function () {
        if ($('.navbar-menu').css('display') == 'flex') {
            $("#query").stop(true);
            $("#query").animate({ width: "200px" }, 400, function () { $('.navbar-start').show() });
        }
        $('#navbar-search').hide();
        $('#navMenu').removeClass('navbar-autocomplete-active');
    });
});

    