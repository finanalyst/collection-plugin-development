$(document).ready( function() {
    // trigger the highlighter
    hljs.highlightAll();
});